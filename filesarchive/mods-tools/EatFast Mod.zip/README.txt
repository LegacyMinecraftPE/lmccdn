Mod: EatFast
Mod Description: Make you eat any types of food more fast.
For Minecraft Pocket Edition 0.7.1

THIS MOD WAS MADE BY SYNCPIXEL.