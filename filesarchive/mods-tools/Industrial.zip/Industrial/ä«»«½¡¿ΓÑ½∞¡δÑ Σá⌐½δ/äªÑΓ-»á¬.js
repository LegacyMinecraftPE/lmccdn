// tocaunt
var PlayerX;
var PlayerY;
var PlayerZ;

var btnWindow;
var progressWindow;
var ctx;
var progressBar;
var currProgress;
var text;
var buttonOn;

var power = 0.03;
var jp = 347;
var lim = false;
var oldY;
var curr;
var PlayerId = getPlayerEnt();
var soundtick = 1;

var active = false;

ModPE.setItem(498, "book_writable", 1, "Kvant Benzin");
ModPE.setItem(jp, "ghast_tear", 1, "JetPack");

function useItem(x,y,z,itemId,blockId,side)
{
if(itemId==jp&&blockId==189)
    {
    ctx.runOnUiThread(new java.lang.Runnable({run:function(){try
     {
     explode(x,y,z,0);
     setTile(x,y,z,188);
     progressBar.setProgress(2500);
     clientMessage("Топливо загружено !");
     }catch(err){
     print(err);
     }
     }
     }))
    }
}

function modTick()
{
soundtick--;
if(soundtick==0)
{
soundtick = 5;
}
PlayerX = Player.getX();
PlayerY = Player.getY();
PlayerZ = Player.getZ();
curr = getCarriedItem();
if(active==true)
    {
    fly();
    }
ctx.runOnUiThread(new java.lang.Runnable({run:function(){try
     {
     currProgress = progressBar.getProgress();
     text.setText("           "+currProgress+" / 2500");
     if(text.getText()=="           3 / 2500")
     {
     text.setText("           Нет топлива!");
     }
     }catch(err){
     print(err);
     }
     }
     }))
}

function newLevel()
{
	ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
	ctx.runOnUiThread(new java.lang.Runnable(
	{
	run:
	function()
	{
		try{
		    //gui form
			var layout = new android.widget.RelativeLayout(ctx);
			buttonOn = new android.widget.Button(ctx);
			var progressLayout = new android.widget.RelativeLayout(ctx);
			progressBar = new android.widget.ProgressBar(ctx,null,android.R.attr.progressBarStyleHorizontal);
			var dp = ctx.getResources().getDisplayMetrics().density;
			text = new android.widget.TextView(ctx);
            
			
			//setting for form
			buttonOn.setText("Вкл.°");
			progressBar.setLayoutParams(new android.widget.LinearLayout.LayoutParams(160*dp,-2));
            progressBar.setVisibility(1);
			progressBar.setMax(2500);
			progressBar.setProgress(2500);
			if(ModPE.readData(1024)!=null)
			{
			progressBar.setProgress(ModPE.readData(1024));
			}
			text.setTextColor(android.graphics.Color.RED);
			text.setText("     "+currProgress);
			text.getPaint().setFakeBoldText(true)
            text.setTextSize(15);
			
			//on-click function
			buttonOn.setOnClickListener(new android.view.View.OnClickListener(
			{
				onClick:
				function(viewarg)
				{    
				     if(active==false)
				     {
				     active = true;
				     buttonOn.setText("Выкл.");
				     }else{
				     active = false;
				     buttonOn.setText("Вкл.°");
				     }
				}
			}));
			
			//coord for layout form
		    var bx = dip2px(ctx, 4000);
		    var by = dip2px(ctx, 0);
		    var flags = android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM;
		    var nx = dip2px(ctx, 4000);
		    var ny = dip2px(ctx, 0);
		    var nflags = android.view.Gravity.RIGHT | android.view.Gravity.TOP;
			
			//show form
			layout.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE));
	        progressLayout.addView(progressBar);
		    layout.addView(buttonOn);
		    progressLayout.addView(text);
		    
		    //setting for layout
		    btnWindow = new android.widget.PopupWindow(layout, dip2px(ctx, 60), dip2px(ctx, 38));
			btnWindow.showAtLocation(ctx.getWindow().getDecorView(), flags, bx, by);
			btnWindow.setWidth(dip2px(ctx, 41));
			btnWindow.setHeight(dip2px(ctx, 35));
			btnWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE));
			progressWindow = new android.widget.PopupWindow(progressLayout, dip2px(ctx, 200), dip2px(ctx, 38));
			progressWindow.showAtLocation(ctx.getWindow().getDecorView(), nflags, nx, ny);
			progressWindow.setWidth(dip2px(ctx, 300));
			progressWindow.setHeight(dip2px(ctx, 38));
			progressWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE));
			
			
			}catch(err){
			print(err);
			}
	    }
	}
))}

function fly()
{

if(curr==jp)
{
if(currProgress > 3)
{
setVelY(getPlayerEnt(),power);
if(soundtick==1|soundtick==3)
{
Level.playSoundEnt(getPlayerEnt(),"random.pop",1000,15);
}
}
upLim(PlayerY);

if(oldY + 64 > PlayerY && currProgress > 3)
{
power = 0.03;
ctx.runOnUiThread(new java.lang.Runnable({run:function(){try
     {
     var p = progressBar.getProgress();
     progressBar.setProgress(p-1);
     
     }catch(err){
     print(err);
     }
}
}))
if(oldY + 64 < PlayerY)
{
power = -0.03;
clientMessage(ChatColor.RED+"Достигнут лимит!");
}
}
}
}

function getP()
{
var num;
if(oldY+64 > PlayerY)
{
num=oldY+64/1024;
}
if(oldY+64 < PlayerY){return 0}
return num;
}

function upLim(y)
{
if(lim==false)
{
lim = true;
oldY = y;
}
}

function leaveGame()
{
ModPE.saveData(1024,currProgress)
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
	ctx.runOnUiThread(new java.lang.Runnable(
	{ run: function()
    	{
    	btnWindow.dismiss();
    	btnWindow = null;
    	progressWindow.dismiss();
    	progressWindow = null;
	    }
	}
))}

function dip2px(ctx, dips)
{
 return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
}