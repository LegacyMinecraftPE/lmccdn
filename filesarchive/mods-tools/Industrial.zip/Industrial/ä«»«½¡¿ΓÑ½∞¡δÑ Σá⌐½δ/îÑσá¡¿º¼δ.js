var engineLoadingProgress = 0;
var engineLoadingDataSize = 0;

function newLevel(){
   defineBlocks()
   preLoadAllTubeItems();
   engineLoadingProgress = 0;
   initEngineLoading();
}

function leaveGame(){
  saveAllTubeItems();
  saveAllEngines();
  preventDefault();
}

function modTick(){
  updateAllTubeItems()
  loadNextEngine()
  if(isEngineDataLoaded()){updateAllEngines();}
}



function defineBlocks(){
  Block.defineBlock(200, "electric furnance", [["redstone_block", 0]], 3,0,4);
  Block.setShape(200,0,0,0,1,.8,1)
  Block.setRenderLayer(200,3)
  Block.setDestroyTime(200,2)
  
  Block.defineBlock(201, "electric furnance", [["iron_block", 0]], 3,0,4);
  Block.setShape(201,0,0,0,1,.8,1)
  Block.setRenderLayer(201,3)
  Block.setDestroyTime(201,2)
  
   Block.defineBlock(192, "macerator", [["redstone_block", 0]], 3,0,4);
  Block.setShape(192,0,0,0,1,.8,1)
  Block.setRenderLayer(192,3)
  Block.setDestroyTime(192,2)
  
  Block.defineBlock(193, "macerator", [["iron_block", 0]], 3,0,4);
  Block.setShape(193,0,0,0,1,.8,1)
  Block.setRenderLayer(193,3)
  Block.setDestroyTime(193,2)
  
   
  Block.defineBlock(204, "item tube", [["glass", 0]], 3,0,13);
  Block.setRenderLayer(204,2)
  Block.setDestroyTime(204,0)
  
  Block.defineBlock(205, "entrance tube", [["glass", 0]], 3,0,13);
  Block.setRenderLayer(205,2)
  Block.setDestroyTime(205,0)
  Block.setColor(205, [0x00ff00])
  
  Block.defineBlock(207, "vacum tube", [["glass", 0]], 3,0,13);
  Block.setRenderLayer(207,2)
  Block.setDestroyTime(207,0)
  Block.setColor(207, [0xffff00])
   
  Block.defineBlock(202, "generator", [["gold_block", 0]], 3,0,0);
  Block.setRenderLayer(202,3)
  Block.setDestroyTime(202,2)
  
  Block.defineBlock(199, "solar pannel", [ ["iron_block", 0], ["mob_spawner", 0], ["iron_block", 0], ["iron_block", 0], ["iron_block", 0], ["iron_block", 0] ], 3,0,0);
  Block.setDestroyTime(199,2)
  
  Block.defineBlock(195, "nuclear reactor", [["diamond_block", 0]], 3,0,0);
  Block.defineBlock(196, "uranium cell", [["coal_block", 0]], 3,0,0);
  Block.setExplosionResistance (195,2.5);
  Block.setExplosionResistance (196,2.5);
  
  Block.defineBlock(197, "bat box", [["redstone_block", 0]], 3,0,0);
  Block.defineBlock(194, "quarry", [["command_block", 0]], 3,0,0);
  
  ModPE.setItem(488, "slimeball", 1, "energy cell");
  ModPE.setItem(487, "dye_powder", 1," gold dust");
  ModPE.setItem(486, "dye_powder", 1, "iron dust");
}



var efrm = 0;

function useItem(x,y,z,id, b){
 if(b == 205){
   var item = Level.dropItem(x + 0.5,y - 0.1,z + 0.5,1, id, Player.getCarriedItemCount(), Player.getCarriedItemData());
   var addedItem = addToTubeItems(item, id, Player.getCarriedItemCount(), Player.getCarriedItemData() )
   addedItem.x = x + 0.5;
   addedItem.y = y + 0.5;
   addedItem.z = z + 0.5;
   addedItem.respawn()
   preventDefault();
Entity.setCarriedItem(getPlayerEnt(), 0);
 }
 

if(isEngine(b) && id == 331){
  addEngine(x,y,z).animate();
addItemInventory (331, -1);
}

if(b == 202 && id == 263){
  addEngineFuel(x,y,z, 24)
addItemInventory (263, -1);
}

if(b == 195 && id == 347){
  var r= getEngine(x,y,z);
  if(r){r.displayData()}
}

if(b == 197 && id == 331){
  var bb = new BatBox(x,y,z);
  addEngineObj(bb).animate();
addItemInventory (331, -1);
}
if(b == 194 && id == 331){
  var bb = new Quarry(x,y,z);
  addEngineObj(bb).animate();
addItemInventory (331, -1);
}
 if(b == 197 && id == 347){
  var r= getEngine(x,y,z);
  if(r){r.displayData()}
}
 if(b == 194 && id == 347){
  var r= getEngine(x,y,z);
  if(r){r.displayData()}
}

}




























































function Quarry(x,y,z){
   this.x = parseInt(x);
   this.y = parseInt(y);
   this.z = parseInt(z);
   this.age = 0;
   this.fuel = 0;
   this.engineType = "quarry";
   this.blockId = 0;
   this.progress = 0;
   
   this.updateTileData = function(){
     this.blockId = getTile(parseInt(this.x),parseInt(this.y), parseInt(this.z));
     if(this.blockId != 194){this.blockId = -1}
   }
   this.updateTileData();
   
   this.saveSelf = function(name){
      saveFloat(name + "$X", this.x);
      saveFloat(name + "$Y", this.y);
      saveFloat(name + "$Z", this.z);
      saveFloat(name + "$fuel", this.fuel);
      saveFloat(name + "$progress", this.progress);
      
   }
   
   this.readSelf = function(name){
      this.x = readFloat(name + "$X");
      this.y = readFloat(name + "$Y");
      this.z = readFloat(name + "$Z");
      this.fuel = readFloat(name + "$fuel");
      this.progress = readFloat(name + "$progress");
      this.progress -= 24;
      if(this.progress < 0){this.progress =0;}
   }
   
   this.onUpdate = function(){
      this.age++;
      if(this.age % 4== 0 && this.fuel > 0){
        var digx = this.x-8 + this.progress % 16;
        var digz = this.z-8+parseInt(this.progress / 16)% 16
        var digy = this.y - 2- parseInt(this.progress / 256);
        if(digy < 1){return}
        var lastfuel = this.fuel;var digged = true;
        digged = this.digBlock(digx, digy, digz);
      }
   }
   
   this.digBlock = function(x,y,z){
   //  clientMessage(" dig block " + x + " " + y+ " " + z + " progress " + this.progress)
     var drop = this.getBlockConvertedData(x,y,z);
     if(!drop){this.progress++;return false}
     Level.destroyBlock(x,y,z);
     chestData.x = this.x;
     chestData.y = this.y+1;
     chestData.z = this.z;
     if(drop[0] != 0){
     this.fuel -= .35;
     addItemToChestWithDrop(drop[0],drop[1],drop[2])
     }
     this.progress++;
     return true;
   }
   
   this.getBlockConvertedData = function(x,y,z){
     var id = getTile(x,y,z);
     var data = Level.getData(x,y,z);
     var multi = parseInt(4 + Math.random() * 2)
     if(id == 1){return [4,1,0]}
     if(id == 7 || id == 95){return null}
     if(id == 8 || id == 9 || id == 10 || id == 11 || id == 79 || id == 80 || id == 18 || id == 78 || id == 20){return [0,0,0]}
     if(id == 16){return [263,1,0]}
     if(id == 73 || id == 74){return [331,multi, 0]}
     if(id == 56){return [264,1,0]}
     if(id == 21){return [351,multi, 4]}
     return[id,1,data]
   }
   
   this.isExist = function(){
     return ( parseInt(this.x),parseInt(this.y), parseInt(this.z) == 194)
   }
   this.animate = function(){
      setTile(this.x, this.y, this.z, 35,14);
      Level.destroyBlock(this.x, this.y, this.z, 0);
      setTile(this.x, this.y, this.z, 194);
   }
   
   this.displayData = function(){
     clientMessage(ChatColor.GREEN + "QUARRY\nenergy: " + this.fuel)
   }
  this.isExist = function(){
     return (this.blockId == getTile(this.x,this.y, this.z))
   }
  
}







































































function BatBox(x,y,z){
   this.x = parseInt(x);
   this.y = parseInt(y);
   this.z = parseInt(z);
   this.age = 0;
   this.fuel = 0;
   this.engineType = "batBox";
   this.blockId = 0;
   
   this.updateTileData = function(){
     this.blockId = getTile(parseInt(this.x),parseInt(this.y), parseInt(this.z));
     if(this.blockId != 197){this.blockId = -1}
   }
   this.updateTileData();
   
   this.saveSelf = function(name){
      saveFloat(name + "$X", this.x);
      saveFloat(name + "$Y", this.y);
      saveFloat(name + "$Z", this.z);
      saveFloat(name + "$fuel", this.fuel);
      
   }
   
   this.readSelf = function(name){
      this.x = readFloat(name + "$X");
      this.y = readFloat(name + "$Y");
      this.z = readFloat(name + "$Z");
      this.fuel = readFloat(name + "$fuel");
      
   }
   
   this.onUpdate = function(){
      this.age++;
      if(this.age % 50 == 0){
        this.throwEnergyIfHasFuel(32,32)
      }
   }
   
   this.isExist = function(){
     return ( parseInt(this.x),parseInt(this.y), parseInt(this.z) == 197)
   }
   
   
   
   
   
   this.throwEnergyIfHasFuel = function(size, fuel){
     if(this.fuel < fuel){return false}
     this.fuel -= fuel;
     if(Math.random() < .2){this.animate();}
     return this.throwEnergy(size)
   }
   
   this.throwEnergy = function(stacksize){
     var possibleTubePath = [];
     var enItem = new Item(-1, 488, stacksize, 0);
     enItem.x = this.x + .5;
     enItem.y = this.y + .5;
     enItem.z = this.z + .5;
     for(var i in allTubePath){
        var p = allTubePath[i];
        if(canTransportIn(p[0] + enItem.x, p[1] + enItem.y, p[2] + enItem.z, enItem )){possibleTubePath.push(p)}
     }
    
    if(possibleTubePath.length == 0){return false;}
    var i = parseInt(Math.random() * possibleTubePath.length)
    var currentVector = possibleTubePath[i];
    
    enItem.movex = currentVector[0];
    enItem.movey = currentVector[1];
    enItem.movez = currentVector[2];
    enItem.respawn();
    enItem.pushSelfToMove();
    tubeItems.push(enItem);
    return true;
   }
   
   this.logString = function(){
      return ("engine at " + this.x + " " + this.y + " " + this.z + " id = " + this.blockId + " fuel " + this.fuel)
   }
   
   this.animate = function(){
      setTile(this.x, this.y, this.z, 35,14);
      Level.destroyBlock(this.x, this.y, this.z, 0);
      setTile(this.x, this.y, this.z, this.blockId);
   }
   
   this.displayData = function(){
     clientMessage(ChatColor.GREEN + "BAT-BOX\nenergy saved: " + this.fuel)
   }
  this.isExist = function(){
     return (this.blockId == getTile(this.x,this.y, this.z))
   }
    
}


















































































































function Engine(x,y,z){
   this.x = parseInt(x);
   this.y = parseInt(y);
   this.z = parseInt(z);
   this.age = 0;
   this.fuel = 0;
   this.temp = 0;
   this.engineType = "generator"
   
   this.updateTileData = function(){
     this.blockId = getTile(parseInt(x),parseInt(y), parseInt(z));
     if(!isEngine(this.blockId)){this.blockId = -1}
   }
   this.updateTileData();
   
   this.saveSelf = function(name){
      saveFloat(name + "$X", this.x);
      saveFloat(name + "$Y", this.y);
      saveFloat(name + "$Z", this.z);
      saveFloat(name + "$fuel", this.fuel);
      saveFloat(name + "$temp", this.temp);
   }
   
   this.readSelf = function(name){
      this.x = readFloat(name + "$X");
      this.y = readFloat(name + "$Y");
      this.z = readFloat(name + "$Z");
      this.fuel = readFloat(name + "$fuel");
      this.temp = readFloat(name + "$temp");
   }
   
   this.onUpdate = function(){
      this.age++;
      if(this.blockId == 195){
        this.updateReactor(); return;
      }
      
      if(this.age % 100 == 0 && this.blockId == 202){
        this.generateEnergy();
      }
      if(this.blockId == 199 && Level.getBrightness(this.x, this.y + 1,this.z) == 15){
         this.fuel+= .25;
         if(this.age % 20 == 0){this.generateEnergy()}
      }
   }
   
   this.isExist = function(){
     return (this.blockId == getTile(this.x,this.y, this.z))
   }
   
   
   
   this.generateEnergy = function(){
     switch(this.blockId){
       case 202: this.throwEnergyIfHasFuel(10,10);
       case 199: this.throwEnergyIfHasFuel(5,100);
     }
   }
   
   this.throwEnergyIfHasFuel = function(size, fuel){
     if(this.fuel < fuel){return false}
     this.fuel -= fuel;
     this.animate();
     return this.throwEnergy(size)
   }
   
   this.throwEnergy = function(stacksize){
     var possibleTubePath = [];
     var enItem = new Item(-1, 488, stacksize, 0);
     enItem.x = this.x + .5;
     enItem.y = this.y + .5;
     enItem.z = this.z + .5;
     for(var i in allTubePath){
        var p = allTubePath[i];
        if(canTransportIn(p[0] + enItem.x, p[1] + enItem.y, p[2] + enItem.z, enItem )){possibleTubePath.push(p)}
     }
    
    if(possibleTubePath.length == 0){return false;}
    var i = parseInt(Math.random() * possibleTubePath.length)
    var currentVector = possibleTubePath[i];
    
    enItem.movex = currentVector[0];
    enItem.movey = currentVector[1];
    enItem.movez = currentVector[2];
    enItem.respawn();
    enItem.pushSelfToMove();
    tubeItems.push(enItem);
    return true;
   }
   
   this.logString = function(){
      return ("engine at " + this.x + " " + this.y + " " + this.z + " id = " + this.blockId + " fuel " + this.fuel)
   }
   
   this.animate = function(){
      setTile(this.x, this.y, this.z, 35,14);
      Level.destroyBlock(this.x, this.y, this.z, 0);
      setTile(this.x, this.y, this.z, this.blockId);
   }
   
   
   
   
   
   









   this.reactorMap = [];
   this.waterAround = 0;
   this.uraniumAround = 0;
   this.heating = 0;
   
   this.updateReactor = function(){
     if(this.reactorMap.length == 0){
        this.scanMap();
     }
     else{
        this.scanRandomMapElement();
     }
     this.displayWarningIfNeeded();
     
     this.heating = 0;
     this.heating += this.uraniumAround / 1.978236 ;
     this.heating -= this.waterAround / 7.82725 + 0.1172914;
     this.temp += this.heating;
     if(this.temp < 0){this.temp = 0}
     if(this.temp > 8192){this.explodeReacor()}
     
     this.fuel += this.temp / 25000;
     if(this.fuel > 128){
       this.throwEnergyIfHasFuel(128,128);
     }
   }
   
   this.explodeReacor = function(){
      Level.explode(this.x, this.y, this.z, 20);
   }
   
   this.scanMap = function(){
     for(var x = 0; x < 3; x++){
       for(var y = 0; y < 3; y++){
         for(var z = 0; z < 3; z++){
           this.reactorMap[(x * 3 + y) * 3 + z] = getTile(this.x - 1 + x, this.y - 1 + y, this.z - 1 + z)
         }
       }
     }
     this.analyseReactorMap();
   }
   
   
   this.scanRandomMapElement = function(){
     var x = parseInt(Math.random() * 3);
     var y = parseInt(Math.random() * 3);
     var z = parseInt(Math.random() * 3);
     this.reactorMap[(x * 3 + y) * 3 + z] = getTile(this.x - 1 + x, this.y - 1 + y, this.z - 1 + z)
      this.analyseReactorMap()
   }
   
   this.analyseReactorMap = function(){
    this.waterAround = 0;
    this.uraniumAround = 0;
    for(var x = 0; x < 3; x++){
       for(var y = 0; y < 3; y++){
         for(var z = 0; z < 3; z++){
           var tId = this.reactorMap[(x * 3 + y) * 3 + z];
           if(tId == 9){this.waterAround++}
           if(tId == 196){this.uraniumAround++}
         }
       }
     }
   }
  
   this.debugReactor = function(){
     if(this.age % 200 != 0){return}
     this.displayData();
   }
   
   
   this.displayData = function(){
     clientMessage(ChatColor.GREEN + "Nuclear reactor:\ntemperatute: " + ChatColor.YELLOW + parseInt(this.temp) + "F"+ ChatColor.WHITE + "\nheating: " + ChatColor.YELLOW + (parseInt(this.heating * 100) / 100) + ChatColor.WHITE + "\nuranium cells: " + ChatColor.YELLOW + this.uraniumAround + "\nenergy: " + parseInt(this.fuel));
   }
   
   this.displayWarningIfNeeded = function(){
     if(this.temp > 5000 && this.temp - this.heating < 5000){ 
        clientMessage(ChatColor.RED + "WARNING!\n" + ChatColor.RED + "The temperature of the nuclear reactor is " + ChatColor.YELLOW + parseInt(this.temp) + "F" + ChatColor.RED + " and it's\nheating is going on!" + ChatColor.WHITE + "\nheating: " + ChatColor.YELLOW + (parseInt(this.heating * 100) / 100) + ChatColor.WHITE + "\nuranium cells: " + ChatColor.YELLOW + this.uraniumAround );
      }
   }
}










var engineList = [];


function isEngine(id){
  return (id == 202 || id == 199 || id == 195)
}



function saveAllEngines(){
  saveFloat("buildscript#engines$length", engineList.length)
  for(var i in engineList){
    var engine = engineList[i];
    saveString("buildscript#engine" + i + "$type", engine.engineType);
    engine.saveSelf("buildscript#engine" + i);
  }
}

function isEngineDataLoaded(){
return ( engineLoadingProgress > engineLoadingDataSize + 1)
}

function loadNextEngine(){
  if(isEngineDataLoaded()){return}
   var i = engineLoadingProgress;
   var type = readString("buildscript#engine" + i + "$type");
     if(type == "" || type == "generator") { var engine = new Engine()}
     if(type == "batBox"){ var engine = new BatBox()}
     if(type == "quarry") {var engine = new Quarry()}
    engine.readSelf("buildscript#engine" + i);
    engine.updateTileData();
    engine.blockId =getTile(engine.x, engine.y, engine.z)
    addEngineObj(engine);
    
    engineLoadingProgress++;
}

function initEngineLoading(){
  engineList = []
  engineLoadingDataSize = readFloat("buildscript#engines$length")
}





function loadAllEngines(){
  engineList = []
  var length = readFloat("buildscript#engines$length")
  clientMessage("loaded engine data size " + length)
  for(var i = 0; i < length;i++){
    var type = readString("buildscript#engine" + i + "$type");
   
     if(type == "" || type == "generator") { var engine = new Engine()}
     if(type == "batBox"){ var engine = new BatBox()}
     if(type == "quarry") {var engine = new Quarry()}
    engine.readSelf("buildscript#engine" + i);
    engine.updateTileData();
    engine.blockId =getTile(engine.x, engine.y, engine.z)
    addEngineObj(engine);
    setTile(0,0,0,7)
  }
}

function updateAllEngines(){
   for(var i = 0; i < engineList.length;i++){
    var engine = engineList[i];
    var isEx = true;
    if(Math.random() <.2){var isEx = engine.isExist()}
    if(!isEx){engineList.splice(i,1); i--; continue;}
    engine.onUpdate();
  }
}

function addEngine(x,y,z){
  var ae = new Engine(x,y,z);
  for(var i = 0; i < engineList.length;i++){
    var engine = engineList[i];
    if(engine.x == x && engine.y == y && engine.z == z){return engine}
  }
  engineList.push(ae);
  return ae;
}

function addEngineObj(ae){
  for(var i = 0; i < engineList.length;i++){
    var engine = engineList[i];
    if(engine.x == ae.x && engine.y == ae.y && engine.z == ae.z){return engine}
  }
  engineList.push(ae);
  return ae;
}

function getEngine(x,y,z){
  for(var i = 0; i < engineList.length;i++){
    var engine = engineList[i];
    if(engine.x == x && engine.y == y && engine.z == z){return engine}
  }
  return null;
}

function addEngineFuel(x,y,z,fuel){
  var ge = getEngine(x,y,z);
  if(ge != null){ge.fuel += fuel}
}




































































































function Item(entity, id, count, data){
  this.entity = entity;
  this.id = id;
  this.count = count;
  this.data = data;
  this.x = Entity.getX(entity);
  this.y = Entity.getY(entity);
  this.z = Entity.getZ(entity);
  
  this.movex = 0;
  this.movey = 0;
  this.movez = 0;
  
  this.remove = function(){Entity.remove(this.entity)}
  this.isExist = function(){
     return(Entity.getY(this.entity) != 0)
  }
  
  this.respawn = function(){
     var nd=Level.dropItem(this.x,this.y, this.z, 1, this.id, this.count, this.data)
     setVelX(nd,0); setVelY(nd,0); setVelZ(nd,0)
     setPosition(nd, this.x,this.y, this.z)
     this.remove();
     this.entity = nd;
  }
  
  this.updatePosition = function(){
    if(!this.isExist()){return false;}
    this.x = Entity.getX(this.entity);
    this.y = Entity.getY(this.entity);
    this.z = Entity.getZ(this.entity);
    return true;
  }
  this.turnBack = function(){
    this.movey *= -1;
    this.movex *= -1;
    this.movez *= -1;
  }
  
  this.logString = function(){
    return( "item object: id " + this.id + " count " + this.count + " data " + this.data)
  }
  
  this.saveSelf = function(name){
    saveFloat(name + "$X", this.x)
    saveFloat(name + "$Y", this.y)
    saveFloat(name + "$Z", this.z)
    saveFloat(name + "$id", this.id)
    saveFloat(name + "$count", this.count)
    saveFloat(name + "$data", this.data)
  }
  
  this.readSelf = function(name){
    this.x = readFloat(name + "$X");
    this.y = readFloat(name + "$Y");
    this.z = readFloat(name + "$Z");
    this.id = readFloat(name + "$id");
    this.count = readFloat(name + "$count");
    this.data = readFloat(name + "$data");
  }
  
  this.isSelfEntity = function(ent){
    var xdis = Entity.getX(ent) - this.x;
    var ydis = Entity.getY(ent) - this.y;
    var zdis = Entity.getZ(ent) - this.z;
    var dis=Math.sqrt(xdis*xdis+ydis*ydis+zdis*zdis)
    return (dis < .7)
  }
  
  this.pushSelfToMove = function(){
    this.x += this.movex;
    this.y += this.movey;
    this.z += this.movez;
    setPosition(this.entity, this.x,this.y, this.z)
  } 
}

function readItemByName(name){
  var readedItem = new Item(-1,0,0,0)
  readedItem.readSelf(name)
  return readedItem;
}

function saveAllTubeItems(){
  saveFloat("buildscript#items$length", tubeItems.length)
  for(var i in tubeItems){
    var item = tubeItems[i];
    item.saveSelf("buildscript#item" + i);
  }
}

function preLoadAllTubeItems(){
  tubeItemsRawLoad = [];
  tubeItems = [];
  var length = readFloat("buildscript#items$length")
  clientMessage("loaded raw data size " + length)
  for(var i = 0; i < length;i++){
    var item = readItemByName("buildscript#item"+i)
    tubeItemsRawLoad.push(item)
  }
}

function updateAllTubeItems(){
  //if(getPlayerY() == 0){return}
  for(var i = 0; i < tubeItems.length;i++){
    var item = tubeItems[i]
    currentItemInBlock = getTile(item.x, item.y, item.z)
    updateItemInTube(item)
    
    var isEx = item.updatePosition();
    if(!isEx){tubeItems.splice(i,1); i--; continue;}
    updateItemInFurnance(item)
    updateItemInChest(item)
    updateItemInBatBox(item)
    currentItemInBlock = -1;
  }
}

















var tubeItems = []
var tubeItemsRawLoad = []
var currentItemInBlock = -1;


function entityAddedHook(ent){
   if(isDrop(ent) && isDroppedByPlayer(ent)){
     
   }
   
   if(isDrop(ent)){
     for(var i in tubeItemsRawLoad){
       var item = tubeItemsRawLoad[i]
       if(item.isSelfEntity(ent)){
         item.entity = ent;
         item.respawn();
         tubeItems.push(item);
         tubeItemsRawLoad.splice(i,1)
         
       }
     }
   }
}


function addToTubeItems(ent, id, count, data){
  setVelX(ent, 0); setVelY(ent,0); setVelZ(ent,0)
  var itemToAdd = new Item(ent,id,count,data);
  tubeItems.push(itemToAdd)
  return itemToAdd;
}

function isDroppedByPlayer(ent){
  return (getDistance(ent, getPlayerEnt()) < .5)
}

function getDistance(e1,e2){
  var xdis = Entity.getX(e1) - Entity.getX(e2)
  var ydis = Entity.getY(e1) - Entity.getY(e2)
  var zdis = Entity.getZ(e1) - Entity.getZ(e2)
  return Math.sqrt(xdis*xdis + ydis*ydis + zdis*zdis)
}

function isDrop(e){
  return (Entity.getEntityTypeId(e) == 64)
}



function saveFloat(name, value){
  ModPE.saveData(Level.getWorldDir()+name,value)
}

function readFloat(name){
  var floatNumber = parseFloat(ModPE.readData( Level.getWorldDir() + name));
  if(floatNumber + "" == "NaN") {
   // clientMessage("missing data /" + name + " set to 0");
    floatNumber = 0;
  }
  return floatNumber;
}

function saveString(name, value){
  saveFloat(name, value);
}

function readString(name){
   return ModPE.readData( Level.getWorldDir() + name)
}
























































































function updateItemInFurnance(item){
  if(!isInFurnance(item)){
    if(!isInIdleFurnance(item)){return}
    else if(isEnergy(item)){
      makeFActive(item)
      item.count--;
      if(item.count > 0){item.respawn()}
      else{item.remove()}
    }
    else{item.turnBack(); item.pushSelfToMove();}
    return;
  }
  var re = getEFurnanceRecipeResult(item);
  if(re == -1){
    item.turnBack();
    if(item.y > parseInt(item.y) + 0.8){item.y += 0.3;}
    item.pushSelfToMove();
    return;
  }
  
  if(item.y > parseInt(item.y) + 0.3){
    setPosition(item.entity, item.x, item.y - 0.02, item.z);
  }
  else{
     item.id = re[0];
     item.count = re[1];
     item.data = re[2];
     makeFIdle(item)
     item.y += 1;
    // clientMessage(item.logString())
     item.respawn();
  }
  
}

function isInFurnance(itemObj){
  return (currentItemInBlock== 200 || currentItemInBlock == 192)
}

function isInIdleFurnance(itemObj){
  return (currentItemInBlock == 201 || currentItemInBlock == 193)
}

function getEFurnanceRecipeResult(itemObj){
  var id = itemObj.id;
  var count = itemObj.count;
  if(currentItemInBlock == 200){
    switch(id){
      case 15: return [265, count, 0]
      case 14: return [266, count, 0]
    }
  }
  if(currentItemInBlock == 192){
    switch (id){
      case 15: return [487, count * 2, 0]
      case 14: return [486, count * 2, 0]
    }
  }
  return -1;
}

function makeFActive(item){
  if( currentItemInBlock == 201) {setTile(item.x, item.y, item.z, 200);}
  if( currentItemInBlock == 193) {setTile(item.x, item.y, item.z, 192);}
}




function makeFIdle(item){
  if( currentItemInBlock == 200) {setTile(item.x, item.y, item.z, 201);}
  if( currentItemInBlock == 192) {setTile(item.x, item.y, item.z, 193);}
} 







































function updateItemInBatBox(item){
   if((currentItemInBlock != 197 && currentItemInBlock != 194) || !isEnergy(item)){return}
   var batbox = getEngine(parseInt(item.x), parseInt(item.y), parseInt(item.z))
   if(batbox == null){
      if(currentItemInBlock == 194){ batbox = new Quarry(parseInt(item.x), parseInt(item.y), parseInt(item.z)) }
      else{batbox = new BatBox(parseInt(item.x), parseInt(item.y), parseInt(item.z))}
      addEngineObj(batbox).animate();
   }
   
   batbox.fuel += item.count;
   item.remove();
}
























































































var tubeId = 204;

function updateItemInTube(item){
  if(!isItemInTube(item)){return}
  holdItemInTube(item);
  findMovingVectorForItemAndMove(item)
}

var allTubePath = [[1,0,0], [-1,0,0], [0,1,0], [0,-1,0], [0,0,1], [0,0,-1]]

function findMovingVectorForItemAndMove(item){
  var lmx = item.movex;
  var lmy = item.movey;
  var lmz = item.movez;
  var lastStay = isItemStaying(item);
  var isMoveComplete = moveItem(item); 
  if(!isMoveComplete){return}
  var lastVector = [nom(lmx),nom(lmy),nom(lmz)]
  var currentVector = [nom(item.movex), nom(item.movey), nom(item.movez)]
   var div = 20;
   if(isEnergy(item)){div = 2.5}
  
  /*
  if(canTransportIn(item.x + lastVector[0], item.y + lastVector[1], item.z + lastVector[2], item) && !lastStay){
    item.movex = lastVector[0] / div
    item.movey = lastVector[1] / div
    item.movez = lastVector[2] / div
    item.pushSelfToMove()
    return;
  }*/
  
// if(lastStay){
    var possibleTubePath = [];
    var possibleChests = [];
    for(var i in allTubePath){
      var p = allTubePath[i];
      if(canTransportIn(p[0] + item.x, p[1] + item.y, p[2] + item.z, item)){possibleTubePath.push(p)}
      if(isEnergy(item) && currentItemInBlock == 207 && getTile( p[0] + item.x, p[1] + item.y, p[2] + item.z) == 54 ){
         possibleChests.push(p)
      }
    }
    var c = 0;
    if( possibleTubePath.length == 0)return
    var i = parseInt(Math.random() * possibleTubePath.length)
      currentVector = possibleTubePath[i];
      var impossibleVector = [lastVector[0] * -1, lastVector[1] * -1, lastVector[2] * -1]
    while(c < 32 && currentVector[0] == impossibleVector[0] && currentVector[1] == impossibleVector[1] && currentVector[2] == impossibleVector[2] ){
      var i = parseInt(Math.random() * possibleTubePath.length)
      currentVector = possibleTubePath[i];
      c++;
    }
    item.movex = currentVector[0] / div
    item.movey = currentVector[1] / div
    item.movez = currentVector[2] / div
   
   
   if(possibleChests.length > 0){
    var j = parseInt(possibleChests.length * Math.random())
     var itemData = getFirstItemFromChest( possibleChests[j][0] + item.x, possibleChests[j][1] + item.y, possibleChests[j][2] + item.z)
     if(itemData){
      var itemDrop = Level.dropItem(item.x, item.y, item.z, 1, itemData[0], itemData[1], itemData[2]);
   var addedItem = addToTubeItems(itemDrop, itemData[0], itemData[1], itemData[2] )
   addedItem.x = item.x;
   addedItem.y = item.y
   addedItem.z = item.z
   addedItem.movex = item.movex;
   addedItem.movey = item.movey;
   addedItem.movez = item.movez;
   addedItem.pushSelfToMove();
   addedItem.respawn()
   item.count--;
   if(item.count > 0){item.respawn()}
   else{item.remove()}
    //clientMessage(addedItem.logString())
     }
   }
    
    
//  }
  item.pushSelfToMove()
}


function holdItemInTube(item){
//setVelX(item.entity,item.x-Entity.getX(item.entity))
  setVelY(item.entity,item.y-Entity.getY(item.entity))
//setVelZ(item.entity,item.z-Entity.getZ(item.entity))
}

function isItemInTube(itemObj){
return (currentItemInBlock == 204 || currentItemInBlock == 205 || currentItemInBlock == 207 )
}

function isItemStaying(itemObj){
  return (itemObj.movex == 0 && itemObj.movey == 0 && itemObj.movez == 0)
}

function moveToDirection(item){
  
}

function moveItem(item){
  var xt1 = parseInt(item.x) + .5
  var yt1 = parseInt(item.y) + .5
  var zt1 = parseInt(item.z) + .5
  var xt2 = parseInt(item.x)+(.5+nom(item.movex))
  var yt2 = parseInt(item.y)+(.5+nom(item.movey))
  var zt2 = parseInt(item.z)+(.5+nom(item.movez))
  var xt = xt1; var yt = yt1; var zt = zt1;
if(item.x>min(xt1,xt2)&&item.x<max(xt1,xt2))xt=xt2
if(item.y>min(yt1,yt2)&&item.y<max(yt1,yt2))yt=yt2
if(item.z>min(zt1,zt2)&&item.z<max(zt1,zt2))zt=zt2
  
  var nx = addToTarget(item.x, xt, item.movex)
  var ny = addToTarget(item.y, yt, item.movey)
  var nz = addToTarget(item.z, zt, item.movez)
  item.movex = nx - item.x;
  item.movey = ny - item.y;
  item.movez = nz - item.z;
  //clientMessage(xt + " " + yt + " " + zt)
  setPosition(item.entity, nx,ny,nz);
  item.x = nx; item.y = ny; item.z = nz;
  return isItemStaying(item)
}

function addToTarget(num, target, speed){
  speed = Math.abs(speed)
  var var1 = target - num;
  if(var1 > speed){var1 = speed}
  if(var1 <-speed){var1 =-speed}
  return num + var1;
}

function abs(x){return Math.abs(x)}
function nom(x){
  var var2 = x / abs(x)
  if(var2 + "" == "NaN") {var2 = 0}
  return var2;
}

function max(a,b){return Math.max(a,b)}
function min(a,b){return Math.min(a,b)}

function canTransportIn(x,y,z, item){
  var block = getTile(x,y,z);
  if(block == 204 || block == 205 || block == 207 || block == 200 || block == 192 || ((block == 201 || block == 193) && isEnergy(item))){return true}
  if(block == 54 && !isEnergy(item)){
    return true;
  }
  if((block == 197 || block == 194)&& isEnergy(item)){return true}
  return false;
}

function isEnergy(item){
  return (item.id == 488)
}








































































function isItemInChest(item){
  return currentItemInBlock == 54;
}

function updateItemInChest(item){
  if(!isItemInChest(item)){return}
  chestData.x = item.x;
  chestData.y = item.y;
  chestData.z = item.z;
  addItemToChestWithDrop(item.id, item.count, item.data)
  item.remove();
}

var chestData = new Object();
chestData.x = 0;
chestData.y = 0;
chestData.z = 0;


function addItemToChest(id, count, data){
   if(getTile(chestData.x, chestData.y, chestData.z) != 54)return count;
   for(var slot = 0; slot < 27; slot++){
      var sid = Level.getChestSlot(chestData.x, chestData.y, chestData.z, slot);
      var scount = Level.getChestSlotCount(chestData.x, chestData.y, chestData.z, slot);
      var sdata = Level.getChestSlotData(chestData.x, chestData.y, chestData.z, slot);
       var countleft = 64 - scount;
       if(sid == id && sdata == data || sid == 0){
          var addcount = count;
          if(addcount > countleft)addcount = countleft
          Level.setChestSlot(chestData.x, chestData.y, chestData.z, slot, id, data,scount + addcount);
          count -= addcount;
          if(count < 1)return 0;
       }
   }
   return count;
}

function addItemToChestWithDrop(id, count, data){
   var nc = addItemToChest(id, count, data);
   if(nc == 0)return
   Level.dropItem(chestData.x, chestData.y, chestData.z, 1, id, nc, data);
}

function getFirstItemFromChest(x,y,z){
if(getTile(x, y, z) != 54){return null;}
   for(var slot = 0; slot < 27; slot++){
      var sid = Level.getChestSlot(x, y, z, slot);
      var scount = Level.getChestSlotCount(x, y, z,slot)
      var sdata = Level.getChestSlotData(x,y, z, slot);
      if(sid != 0){
       Level.setChestSlot(x,y,z,slot, 0,0,0)
       return [sid,scount,sdata]
     }
   }
   return null;
}
