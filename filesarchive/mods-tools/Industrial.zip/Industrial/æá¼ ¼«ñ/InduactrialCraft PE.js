//Разработчик: Alex Fack, и Александр Харламов, Губка Боб (Слава), Евгений Смирнов. Использован скрипт на автодом от Vans22*//

var armor302 = false;
var armor303 = false;
var armor304 = false;
var armor305 = false;
var Xpos=0;
var Ypos=0;
var Zpos=0;
var i=1;
var u=1;
var Xdiff=0;
var Ydiff=0;
var Zdiff=0;
//Броня

var diamondpixage = 5000;
var kvantsword = 1000;
var rpggun = 25;
var onion = 100;

ModPE.setItem(505, "ender_eye", 0, "Uranium");
ModPE.setItem(506, "ender_pearl", 1, "Energetic Diamond");
ModPE.setItem(507, "item_frame", 1, "CPU");
ModPE.setItem(508, "fireworks", 1, "Nano Sword");
ModPE.setItem(509, "experience_bottle", 1, "Diamond Drill");
ModPE.setItem(510, "fireworks", 1, "Nano Sword");
ModPE.setItem(499, "iron_horse_armor", 1,  "Benzin Formul");
ModPE.setItem(498, "book_writable", 1, "Benzin");
ModPE.setItem (496, "fireworks_charge", 1, "Matter");
ModPE.setItem (495, "gold_nugget", 1, "Modern Iron");
ModPE.setItem (494, "gold_horse_armor", 1, "Wrench");
ModPE.setItem (504, "record_13", 1, "Steel");
ModPE.setItem (503, "skull_zombie", 1, "Induactrial RPG");
ModPE.setItem (502, "skull_creeper", 1, "Avto Bow");
ModPE.setItem (501, "skull_skeleton", 1, "Housing");
ModPE.setItem (500, "skull_steve", 1, "Sight");
ModPE.setItem (493, "skull_wither", 1, "Rocket");
ModPE.setItem (492, "record_mellohi", 1, "Nano Chestplate");
ModPE.setItem (491, "record_stal", 1, "Nano Helmet");
ModPE.setItem (490, "record_strad", 1, "Nano Leggings");
ModPE.setItem (489, "record_wait", 1, "Nano Boots");
ModPE.setItem (488, "fireball", 1, "Rubber");

function attackHook(attacker, victim)
{
if(getCarriedItem()==508)
{
var hit = kvantsword--
print ("" + kvantsword + "");
}
  if(getCarriedItem()==508)
  {
var hit = Entity.getHealth(victim) -15;
Entity.setHealth(victim, hit);
}
if (getCarriedItem()==492)
{
var hit = kvantsword--
print ("" + kvantsword + "");
}
}
//Меч

function procCmd(_0x81ddxf)
{
var cmd1 = _0x81ddxf.split(" ");
if(cmd1[0]=="ore")
{
for(var i = 0; i < 512; i++)
{
    var x = nextInt(256);
    var z = nextInt(256);
    var y = nextInt(32);
    var id = 187; var count = 10;
    genMinable(x,y,z, id, count);
clientMessage(ChatColor.GREEN +"Квантовая руда сгенерирована !");
}
}
}

function useItem (x, y, z, itemId, blockId)
{
if (itemId==505&&blockId==42)
{
setTile(x, y, z, 249);
}
if (itemId==302&&blockId==189) //*Зарядка брони*//
{
setTile (x, y, z, 188);
Entity.setCarriedItem(getPlayerEnt(), 0);
clientMessage (" <InduastrialCraft PE> Квантовый шлем заряжен !");
addItemInventory (499, -1);
Player.setArmorSlot (0, 302, 1);
explode (x, y, z, 0);
}
if (itemId==303&&blockId==189)
{
setTile (x, y, z, 188);
Entity.setCarriedItem(getPlayerEnt(), 0);
clientMessage (" <InduastrialCraft PE> Квантовый нагрудник заряжен !");
addItemInventory (499, -1);
Player.setArmorSlot (1, 303, 1);
explode (x, y, z, 0);
}
if (itemId==304&&blockId==189)
{
setTile (x, y, z,188);
Entity.setCarriedItem(getPlayerEnt(), 0);
clientMessage (" <InduastrialCraft PE> Квантовые поножи заряжены !");
addItemInventory (499, -1);
Player.setArmorSlot (2, 304, 1);
explode (x, y, z, 0);
}
if (itemId==305&&blockId==189)
{
setTile (x, y, z, 188);
Entity.setCarriedItem(getPlayerEnt(), 0);
clientMessage (" <InduastrialCraft PE> Квантовые ботинки заряжены !");
addItemInventory (499, -1);
Player.setArmorSlot (3, 305, 1);
explode (x, y, z, 0);
}
if (itemId==508&&blockId==189)
{
kvantsword = 1000;
explode (x, y, z, 0);
clientMessage (" <InduastrialCraft PE> Наносабя заряжена !");
setTile (x, y, z, 188);
}
if (itemId==509&&blockId==189)
{
diamondpixage = 5000;
setTile (x, y, z, 188);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Алмазный бур заряжен !");
}
if (itemId==503&&blockId==189)
{
rpggun = 25;
setTile (x, y, z, 188);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Гранатомет заряжен !");
}
if (itemId==502&&blockId==189)
{
onion = 100;
setTile (x, y, z, 188);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Автолук заряжен !");
}
if (itemId==496&&blockId==249)
{
var random = Math.floor((Math.random()*9)+1);
if(random==1)
{
addItemInventory (506, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !"); //Материя
}
else if(random==2)
{
addItemInventory (496, 2);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==3)
{
addItemInventory (331, 10);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==4)
{
addItemInvemtory (499, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==5)
{
addItemInventory (264, 2);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==6)
{
addItemInventory (496, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==7)
{
addItemInventory (42, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==8)
{
addItemInventory (264, 1);
addItemInventory (266, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==9)
{
addItemInventory (496, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==10)
{
addItemInventory (496, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==11)
{
addItemInventory (496, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==12)
{
addItemInventory (505, 32);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==13)
{
addItemInventory (3, 64);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==14)
{
addItemInventory (302, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==15)
{
addItemInventory (303, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==16)
{
addItemInventory (304, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==17)
{
addItemInventory (305, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==18)
{
addItemInventory (3, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==19)
{
addItemInventory (2, 1);
setTile (x, y, z, 0);
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
else if(random==20)
{
setTile (x, y, z, 0)
Level.spawnMob(x, y + 1, z, 35, "mob/Robot.png");
clientMessage("Robbi Joined The Game");
addItemInventory (496, -1);
explode (x, y, z, 0);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
}
if(itemId==496&&blockId==4)
{
playerX = getPlayerX();
playerY = getPlayerY();
playerZ = getPlayerZ();
setTile(playerX, playerY, playerZ, 4);
setTile(playerX+1, playerY, playerZ, 4);
setTile(playerX, playerY, playerZ+1, 4);
setTile(playerX+1, playerY, playerZ+1, 4);
setTile(playerX+2, playerY, playerZ, 4);
setTile(playerX+3, playerY, playerZ, 4);
setTile(playerX, playerY, playerZ+2, 4);
setTile(playerX, playerY, playerZ+3, 4);
setTile(playerX+3, playerY, playerZ+3, 4);
setTile(playerX+2, playerY, playerZ+1, 4);
setTile(playerX+3, playerY, playerZ+1, 4);
setTile(playerX+2, playerY, playerZ+2, 4);
setTile(playerX+3, playerY, playerZ+2, 4);
setTile(playerX+2, playerY, playerZ+3, 4);
setTile(playerX+3, playerY, playerZ+3, 4);
setTile(playerX+1, playerY, playerZ+2, 4);
setTile(playerX+1, playerY, playerZ+3, 4);
setTile(playerX, playerY+1, playerZ, 4);
setTile(playerX+3, playerY+1, playerZ+3, 4);
setTile(playerX+3, playerY+1, playerZ, 4);
setTile(playerX, playerY+1, playerZ+3, 4);
setTile(playerX, playerY+2, playerZ, 4);
setTile(playerX+3, playerY+2, playerZ+3, 4);
setTile(playerX+3, playerY+2, playerZ, 4);
setTile(playerX, playerY+2, playerZ+3, 4);
setTile(playerX, playerY+3, playerZ, 4);
setTile(playerX+3, playerY+3, playerZ+3, 4);
setTile(playerX+3, playerY+3, playerZ, 4);
setTile(playerX, playerY+3, playerZ+3, 4);
setTile(playerX, playerY+4, playerZ, 4);
setTile(playerX+1, playerY+4, playerZ, 4);
setTile(playerX, playerY+4, playerZ+1, 4);
setTile(playerX+1, playerY+4, playerZ+1, 4);
setTile(playerX+2, playerY+4, playerZ, 4);
setTile(playerX+3, playerY+4, playerZ, 4);
setTile(playerX, playerY+4, playerZ+2, 4);
setTile(playerX, playerY+4, playerZ+3, 4);
setTile(playerX+3, playerY+4, playerZ+3, 4);
setTile(playerX+2, playerY+4, playerZ+1, 4);
setTile(playerX+3, playerY+4, playerZ+1, 4);
setTile(playerX+2, playerY+4, playerZ+2, 4);
setTile(playerX+3, playerY+4, playerZ+2, 4);
setTile(playerX+2, playerY+4, playerZ+3, 4);
setTile(playerX+3, playerY+4, playerZ+3, 4);
setTile(playerX+1, playerY+4, playerZ+2, 4);
setTile(playerX+1, playerY+4, playerZ+3, 4);
setTile(playerX+1, playerY+1, playerZ, 20);
setTile(playerX+2, playerY+1, playerZ, 20);
setTile(playerX+1, playerY+2, playerZ, 20);
setTile(playerX+2, playerY+2, playerZ, 20);
setTile(playerX+1, playerY+3, playerZ, 20);
setTile(playerX+2, playerY+3, playerZ, 20);
setTile(playerX, playerY+3, playerZ+1, 20);
setTile(playerX, playerY+3, playerZ+2, 20);
setTile(playerX+3, playerY+1, playerZ+1, 20);
setTile(playerX+3, playerY+1, playerZ+2, 20);
setTile(playerX+3, playerY+2, playerZ+1, 20);
setTile(playerX+3, playerY+2, playerZ+2, 20);
setTile(playerX+3, playerY+3, playerZ+1, 20);
setTile(playerX+3, playerY+3, playerZ+2, 20);
setTile(playerX+1, playerY+1, playerZ+3, 20);
setTile(playerX+2, playerY+1, playerZ+3, 20);
setTile(playerX+1, playerY+2, playerZ+3, 20);
setTile(playerX+2, playerY+2, playerZ+3, 20);
setTile(playerX+1, playerY+3, playerZ+3, 20);
setTile(playerX+2, playerY+3, playerZ+3, 20);
setTile(playerX-1, playerY-1, playerZ+1, 53);
setTile(playerX-1, playerY-1, playerZ+2, 53);
setTile(playerX+2, playerY+1, playerZ+1, 54);
setTile(playerX+2, playerY+1, playerZ+2, 61);
setTile(playerX+2, playerY+2, playerZ+2, 50);
setTile(playerX-1, playerY+2, playerZ, 50);
setTile(playerX-1, playerY+2, playerZ+3, 50);
setTile(playerX, playerY+1, playerZ+1, 64);
setTile(playerX, playerY+1, playerZ+2, 64);
}
if(itemId==496&&blockId==4)
{
addItemInventory (496, -1);
clientMessage ("<InduactrialCraft PE> Материя использована !");
}
if (itemId==509&&blockId==1)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,4, 1);
}
if (itemId==509&&blockId==2)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,3, 1);
}
if (itemId==509&&blockId==3)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,3, 1);
}
if (itemId==509&&blockId==4)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,4, 1);
}
if (itemId==509&&blockId==5)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,5, 1);
}
if (itemId==509&&blockId==12)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,12, 1);
}
if (itemId==509&&blockId==13)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,13, 1);
}
if (itemId==509&&blockId==14)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,14, 1);
}
if (itemId==509&&blockId==15)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,15, 1);
}
if (itemId==509&&blockId==16)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,263, 1);
}
if (itemId==509&&blockId==17)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,17, 1);
}
if (itemId==509&&blockId==20)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,20, 1);
}
if (itemId==509&&blockId==21)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,21, 1);
}
if (itemId==509&&blockId==22)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,22, 1);
}
if (itemId==509&&blockId==24)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,24, 1);
}
if (itemId==509&&blockId==35)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,35, 1);
}
if (itemId==509&&blockId==41)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,41, 1);
}
if (itemId==509&&blockId==42)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,42, 1);
}
if (itemId==509&&blockId==43)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,43, 1);
}
if (itemId==509&&blockId==44)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,44, 1);
}
if (itemId==509&&blockId==45)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,45, 1);
}
if (itemId==509&&blockId==46)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,46, 1);
}
if (itemId==509&&blockId==47)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,47, 1);
}
if (itemId==509&&blockId==48)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,48, 1);
}
if (itemId==509&&blockId==49)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,49, 1);
}
if (itemId==509&&blockId==56)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,264, 1);
}
if (itemId==509&&blockId==57)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,57, 1);
}
if (itemId==509&&blockId==61)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,61, 1);
}
if (itemId==509&&blockId==62)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,62, 1);
}
if (itemId==509&&blockId==67)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,67, 1);
}
if (itemId==509&&blockId==73)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,331, 5);
}
if (itemId==509&&blockId==74)
{
setTile (x, y, z, 0);
Level.dropItem(x,y,z,1,331, 5);
}
if (itemId==509&&blockId==18)
{
setTile (x, y, z, 0);
}
if (itemId==509)
{
diamondpixage--;
print ("" + diamondpixage + "");
}
if (itemId==498&&blockId==188)
{
setTile (x, y, z, 189);
addItemInventory (498, -1);
explode (x, y, z, 0);
}
if (itemId==498)
{
addItemInventory (498, -1);
setTile (x, y+1, z, 186);
addItemInventory (325, 1);
}
else if(itemId==498&&blockId==188)
{
addItemInventory (498, -1);
setTile (x, y+1, z, 0);
addItemInventory (325, 1);
}
if (itemId==325&&blockId==186)
{
addItemInventory (325, -1);
setTile (x, y, z, 0);
addItemInventory (498, 1);
}
if (itemId==494&&blockId==20)
{
setTile (x, y, z, 204);
}
if (itemId==494&&blockId==204)
{
setTile (x, y, z, 205);
}
if (itemId==494&&blockId==61)
{
setTile (x, y, z, 201);
}
if (itemId==494&&blockId==247)
{
setTile (x, y, z, 195);
}
if (itemId==494&&blockId==173)
{
setTile (x, y, z, 202);
}
if (itemId==494&&blockId==49)
{
setTile (x, y, z, 194);
}
if(itemId==498&&blockId==188)
{
addItemInventory (498, -1);
setTile (x, y, z, 189);
setTile (x, y+1, z, 0);
addItemInventory (325, 1);
}
if (itemId==505&&blockId==87)
{
setTile (x, y, z, 196);
addItemInventory (505, -1);
}
if (itemId==494&&blockId==245)
{
setTile (x, y, z, 193);
}
}

function checkArmor() //Проверка брони 
{ 
if(Player.getArmorSlot(0) == 302) 
{ 
armor302 = true; 
} 
if(Player.getArmorSlot(1) == 303) 
{ 
armor303 = true; 
} 
if(Player.getArmorSlot(2) == 304) 
{ 
armor304 = true; 
} 
if(Player.getArmorSlot(3) == 305) 
{ 
armor305 = true; 
} 
if(Player.getArmorSlot(0) !== 302) 
{ 
armor302 = false; 
} 
if(Player.getArmorSlot(1) !== 303) 
{ 
armor303 = false; 
} 
if(Player.getArmorSlot(2) !== 304) 
{ 
armor304 = false; 
} 
if(Player.getArmorSlot(3) !== 305) 
{ 
armor305 = false; 
} 
}

function modTick()
{
if(onion == 1)
{
removeOnion()
}
if(rpggun == 1)
{
removeGun()
}
if(diamondpixage == 1)
{
pixageRemove()
}
if(kvantsword == 1)
{
swordRemove()
}
checkArmor();
  if (armor303 == true)
   {
    Player.setHealth (20);
    }
  if(armor304 == true)
  {
      if(i==1)
      {
        Xpos=getPlayerX();
        Zpos=getPlayerZ();
        i = i + 1;
      }
      else if(i==3)
      {
        i=1;
        Xdiff=getPlayerX()-Xpos;
        Zdiff=getPlayerZ()-Zpos;
        setVelX(getPlayerEnt(),Xdiff);
        setVelZ(getPlayerEnt(),Zdiff);
        Xdiff=0;
        Zdiff=0;
      }
  if(i!=1)
  {
  i = i + 1;
  }
}
if(armor305 == true)
 {
  if(u==1)
   {
    Ypos=getPlayerY();
     u = u + 1;
   }
   else if(u==3)
    {
     u=1;
     Ydiff=getPlayerY()-Ypos;
     setVelY(getPlayerEnt(),Ydiff);
     Ydiff=0;
    }
   if(u!=1)
    {
    u = u +1;
    }
}
}

function genMinable(par3, par4, par5, bId, blockNum)
    {
       var log = "MINABLE AT " + par3 + " " + par4 + " " + par5 + "\n"
      // blockNum = blockNum || 20;
        var var6 = Math.random() * Math.PI;
        var var7 = ((par3 + 8) + Math.sin(var6) * blockNum / 8.0);
        var var9 = ((par3 + 8) - Math.sin(var6) * blockNum / 8.0);
        var var11 = ((par5 + 8) + Math.cos(var6) * blockNum / 8.0);
        var var13 = ((par5 + 8) - Math.cos(var6) * blockNum / 8.0);
        var var15 = (par4 + nextInt(3) - 2);
        var var17 = (par4 + nextInt(3) - 2);

        for (var var19 = 0; var19 <= blockNum; ++var19)
        {
            var var20 = var7 + (var9 - var7) * var19 / blockNum;
            var var22 = var15 + (var17 - var15) * var19 / blockNum;
            var var24 = var11 + (var13 - var11) * var19 / blockNum;
            var var26 = Math.random() * blockNum / 16.0;
            var var28 = (Math.sin(var19 * Math.PI / blockNum) + 1.0) * var26 + 1.0;
            var var30 = (Math.sin(var19 * Math.PI / blockNum) + 1.0) * var26 + 1.0;
            var var32 = floor_double(var20 - var28 / 2.0);
            var var33 = floor_double(var22 - var30 / 2.0);
            var var34 = floor_double(var24 - var28 / 2.0);
            var var35 = floor_double(var20 + var28 / 2.0);
            var var36 = floor_double(var22 + var30 / 2.0);
            var var37 = floor_double(var24 + var28 / 2.0);

            for (var var38 = var32; var38 <= var35; ++var38)
            {
                var var39 = (var38 + 0.5 - var20) / (var28 / 2.0);

                if (var39 * var39 < 1.0)
                {
                    for (var var41 = var33; var41 <= var36; ++var41)
                    {
                        var var42 = (var41 + 0.5 - var22) / (var30 / 2.0);

                        if (var39 * var39 + var42 * var42 < 1.0)
                        {
                            for (var var44 = var34; var44 <= var37; ++var44)
                            {
                                var var45 = (var44 + 0.5 - var24) / (var28 / 2.0);

                                if (var39 * var39 + var42 * var42 + var45 * var45 < 1.0 && getTile(parseInt(var38), parseInt(var41), parseInt(var44)) == 1)
                                {
                                     log += "(" + var38 + "," + var41 + "," + var44 + ")";
                                    setTile(parseInt(var38), parseInt(var41), parseInt(var44), 187);
                                }
                            }
                        }
                    }
                }
            }
        }
    //  print(log)
        return true;
    }

function nextInt(x){
   return parseInt(Math.random() * x)
}

function floor_double(par0)
    {
        var var2 = parseInt(par0)
        if(par0 < var2){return var2 - 1} 
        return var2;
    }

function pixageRemove()
{
addItemInventory (509, -1);
}

function swordRemove()
{
addItemInventory (508, -1);
}

function removeOnion()
{
addItemInventory (502, -1);
}

function removeGun()
{
addItemInventory (503, -1);
}

function newLevel()
{
clientMessage ("Скрипт разработан Alex'ом Fack'ом");
clientMessage ("Спасибо Александру Белому");
clientMessage ("И ZIP'у");
}
{
Block.defineBlock(187, "Uranium Ore" , [["emerald_ore", 0], ["emerald_ore", 0], ["emerald_ore", 0], ["emerald_ore", 0], ["emerald_ore", 0], ["emerald_ore", 0]], 0, false, 0);
Block.setDestroyTime (187, 4);
}
{
Block.defineBlock(188, "Genetator" , [["command_block", 0], ["command_block", 0], ["command_block", 0], ["command_block", 0], ["command_block", 0], ["command_block", 0]], 0, false, 0);
}
{
Block.defineBlock(189, "Charged Generator" , [["redstone_lamp_off", 0]], 0, false, 0);
}
{
Block.defineBlock (185, "Redstone Block", [["redstone_block", 0]], 1, false, 0);
}
{
Block.defineBlock (186, "Neft", [["coal_block", 0]], 3, 0, 4);
Block.setDestroyTime (186, 1000);
}
{
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); ctx.runOnUiThread(new java.lang.Runnable({ run: function(){ try{ var layout = new android.widget.LinearLayout(ctx); layout.setOrientation(1); var button = new android.widget.Button(ctx); button.setText("Shot"); button.setOnClickListener(new android.view.View.OnClickListener({ onClick: function(viewarg){ shotGun(); } })); layout.addView(button); GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT); GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)); GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 4000); }catch(err){ print("An error occured: " + err); } }})); }

function shotGun()
{
var playerYaw = Entity.getYaw(Player.getEntity()); 
var playerPitch = Entity.getPitch(Player.getEntity());
if(Player.getCarriedItem()==503)
{
            velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var tnt = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY()+1,Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,65);
rpggun--;
print ("" + rpggun + "");
            setVelX(tnt,velX); 
            setVelY(tnt,velY); 
            setVelZ(tnt,velZ);  
            }
else if(getCarriedItem()==502)
{
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
            velX = 3.5 * (Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
            velZ = 3.5 * (-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI)); 
           var arrow = Level.spawnMob(Player.getX() + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,Player.getY()+1,Player.getZ() + -1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
onion--;
print ("" + onion + "");
            setVelX(arrow,velX); 
            setVelY(arrow,velY); 
            setVelZ(arrow,velZ);
            
          }
}