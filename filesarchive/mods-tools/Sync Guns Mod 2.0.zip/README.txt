Sync Guns Mod
Mod Version: 2.0
Minecraft Pocket Edition 0.7.1

CopyRights:
This mod is made by SyncPixel and will not be aloud to be posted by anyone else but SyncPixel.
Reposting of the mod without permission is against the copyright and not official.