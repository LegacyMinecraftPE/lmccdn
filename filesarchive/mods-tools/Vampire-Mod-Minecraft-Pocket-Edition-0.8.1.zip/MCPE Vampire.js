//Vampire Mod ~ Kioni.

ModPE.setItem(367, "rotten_flesh", 0, "Rotten Flesh");

ModPE.setItem(388, "emerald", 0, "Emerald");

ModPE.setItem(375, "spider_eye", 0, "Spider Eye");

ModPE.setItem(385, "fireball", 0, "Fire Charge");

ModPE.setItem(473, "ender_eye", 0, "Vampire Eye");

ModPE.setItem(474, "magma_cream", 0, "Sun Lotion");

ModPE.setItem(471, "potion_bottle_drinkable", 0, "Vampire Bottle");

ModPE.setItem(472, "ruby", 0, "Blood");

ModPE.setItem(475, "book_enchanted", 0, "Necronomicon");

Item.addCraftRecipe(475,1,0,[472,2,0,367,4,0,339,3,0]);// Necronomicon

Item.addCraftRecipe(471,6,0,[20,3,0,331,1,0]);// Vampire Bottles

Item.addCraftRecipe(474,3,0,[337,1,0,348,1,0]);// Sun Lotion

Item.addCraftRecipe(385,2,0,[263,1,0,289,1,0,50,1,0]);// Fire Charge

Item.addCraftRecipe(82,1,0,[12,1,0,289,1,0]);// Clay 

Item.addCraftRecipe(472,1,0,[471,1,0,363,1,0]);// Blood

Item.addFurnaceRecipe(263, 264, 0);
var co = 1;
var mo = 1;
var mistcount = 8;
var mist = 1;
var mistX;
var mistY;
var mistZ;
var mistY1;
var mDoor;
var mDoor1;
var mistAb = 1;
var cash = 0;
var menu;
var exitUI;
var dream = 0;
var Px; 
var Py; 
var Pz;
var Pxs;
var Pys;
var Pzs;
var room = 0;
var rsc = 0;
var shelf = 0;
var sprintTick = 1;
var gb1 = 0;
var gb2 = 0;
var gb3 = 0;
var gb4 = 0;
var gb5 = 0;
var trap = 0;
var Vampire = 1;
var check = 1;
var soul = 9999;
var cur9 = 0;
var cur8 = 0;
var cur7 = 0;
var cur6 = 0;
var cur5 = 0;
var cur4 = 0;
var cur3 = 0;
var cur2 = 0;
var cur1 = 0;
var cur0 = 0;
var power = 0;
var rocket = 0;
var tp = 0;
var grav = 0;
var exp = 0;
var ride = 0;
var chopper = 0;
var mine = 0;
var regen = 0;
var countdown = 30;
var prime = false;
var pig = false;
var sunblock = 0;
var hung = 0;
var countdownh = 600;
var flesh = 0;
var possessed = 0;
var sunclock = 120;
var ALS = 0;
var focus = 0;
var TPX = 0;
var TPY = 0;
var TPZ = 0;
var Tel = 0;
var feedtic = 1;

function newLevel(x,y,z,ent)
{
cash = ModPE.readData("cash");
possessed = ModPE.readData("possessed");
flesh = ModPE.readData("flesh");
rsc = ModPE.readData("rsc");
shelf = ModPE.readData("shelf");
gb1 = ModPE.readData("gb1");
gb2 = ModPE.readData("gb2");
gb3 = ModPE.readData("gb3");
gb4 = ModPE.readData("gb4");
gb5 = ModPE.readData("gb5");
trap = ModPE.readData("trap");
Tel = ModPE.readData("Tel");
TPX = ModPE.readData("TPX");
TPY = ModPE.readData("TPY");
TPZ = ModPE.readData("TPZ");
clientMessage(ChatColor.RED + "MCPE Vampire Mod");

check = ModPE.readData("check");
if(check == 2)
{
   Vampire = ModPE.readData("Vampire");
   soul = ModPE.readData("soul");
   cur9 = ModPE.readData("cur9");
   cur8 = ModPE.readData("cur8");
   cur7 = ModPE.readData("cur7");
   cur6 = ModPE.readData("cur6");
   cur5 = ModPE.readData("cur5");
   cur4 = ModPE.readData("cur4");
   cur3 = ModPE.readData("cur3");
   cur2 = ModPE.readData("cur2");
   cur1 = ModPE.readData("cur1");
   cur0 = ModPE.readData("cur0");
   mistAb = ModPE.readData("mistAb");
}

Block.defineBlock(69,"Altar", 
			[["reactor_core_stage_x", 2], ["redstone_block", 0]]);
		Block.setShape(69, 0, 0, 0, 1, 4/4, 1);

Block.defineBlock(70,"Mort's Shop", 
			[["chest_inventory", 0], ["endframe_top", 0]]);

if(soul < 9999)
{
soul--;
}
  var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
              
  activity.runOnUiThread(new java.lang.Runnable({ run: function() {
    
        try { 
          buttonWindow = new android.widget.PopupWindow();
          
          var layout = new android.widget.RelativeLayout(activity);
          
          var button = new android.widget.Button(activity);
          
          button.setText("*crypt*");
          
          button.setOnClickListener(new android.view.View.OnClickListener({
                
                onClick: function(viewarg) {
                if(co == 1)
                {
                co = 2;
                cryptMenu();
                clientMessage(ChatColor.GREEN + "CRYPT");
                if(Vampire == 2)
                {
                   clientMessage(ChatColor.RED + "Vampire");
                }
                if(sunblock==1)
                {
                clientMessage(ChatColor.YELLOW + "SPF" + ChatColor.RED + "Vitae");
                }
                if(mistAb==2)
                {
                clientMessage(ChatColor.BLUE + "*Myst*");
                }
                }
                }
          }));
          layout.addView(button);
          buttonWindow.setContentView(layout);
          buttonWindow.setWidth(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
          buttonWindow.setHeight(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
          
          buttonWindow.setBackgroundDrawable(new
android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
          
          buttonWindow.showAtLocation(activity.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 0, 0);
          
        }catch(problem){
          print("Button could not be displayed: " + problem); 
        }
  }}));
}

function cryptMenu(){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        try{
            var menuLayout = new android.widget.LinearLayout(ctx);
            var menuScroll = new android.widget.ScrollView(ctx);
            var menuLayout1 = new android.widget.LinearLayout(ctx);
            menuLayout.setOrientation(1);
            menuLayout1.setOrientation(1);

            menuScroll.addView(menuLayout);
            menuLayout1.addView(menuScroll);
            if(Vampire==2)
            {
            var buttonIQ = new android.widget.Button(ctx);
            buttonIQ.setText("IQ:" + shelf);
            buttonIQ.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){}
            }));
            menuLayout.addView(buttonIQ);

            var buttonBL = new android.widget.Button(ctx);
            buttonBL.setText("Blood:" + Entity.getHealth(getPlayerEnt()));
            buttonBL.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){}
            }));
            menuLayout.addView(buttonBL);
            }
            
            var buttonPW = new android.widget.Button(ctx);
            buttonPW.setText("Power:" + rocket + tp + grav + exp + ride + chopper + mine);
            buttonPW.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                   if(rocket == 1)
                {
                     clientMessage(ChatColor.BLUE + "Leviosa");
                }
                if(tp == 1)
                {
                     clientMessage(ChatColor.YELLOW + "Fira");
                }
                if(grav == 1)
                {
                     clientMessage(ChatColor.RED + "Avada Kadava");
                }
                if(exp == 1)
                {
                     clientMessage(ChatColor.RED + "Incindio");
                }
                if(ride == 1)
                {
                     clientMessage(ChatColor.YELLOW + "Raido");
                }
                if(chopper == 1)
                {
                     clientMessage(ChatColor.BLUE + "Loggsman");
                }
                if(mine == 1)
                {
                     clientMessage(ChatColor.GREEN + "Mining");
                }
}
            }));
            menuLayout.addView(buttonPW);

            var buttonSL = new android.widget.Button(ctx);
            buttonSL.setText("**" + soul + "**");
            buttonSL.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){}
            }));
            menuLayout.addView(buttonSL);
            
                
                if(Vampire == 2 && shelf > 899)
                {
                var buttonCB = new android.widget.Button(ctx);
            buttonCB.setText("Mobs in Ether:" + trap);
            buttonCB.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){}
            }));
            menuLayout.addView(buttonCB);
                }
                if(Vampire == 2 && Entity.getHealth(getPlayerEnt()) < 40 && feedtic == 1)
            {
            var buttonfeed = new android.widget.Button(ctx);
            buttonfeed.setText("FEED");
            buttonfeed.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    feedtic = 2;
                    clientMessage(ChatColor.RED + "FEED" + ChatColor.BLACK + "and Live...");
                    co = 1;
                    menu.dismiss();
                }
            }));
            menuLayout.addView(buttonfeed);
            }
                if(Vampire == 2 && shelf > 999)
                {
                var buttonH = new android.widget.Button(ctx);
            buttonH.setText("Heal");
            buttonH.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){ 
                  regen = 1;
                  clientMessage(ChatColor.BLACK + "Crypt Returning Lifeforce...."); 
                }
            }));
            menuLayout.addView(buttonH);
                }
                if(Vampire == 2)
                {
                if(pig== true)
                {
                var buttonPG = new android.widget.Button(ctx);
            buttonPG.setText("Shift Back");
            buttonPG.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                     Entity.setRenderType(Player.getEntity(), 3);
                Entity.setMobSkin(Player.getEntity(), "mob/char.png");
                pig = false;
}
            }));
            menuLayout.addView(buttonPG);
                }
                }
                
                if(shelf > 1299)
                {
                var buttonflesh = new android.widget.Button(ctx);
            buttonflesh.setText("Flesh:" + flesh);
            buttonflesh.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){}
            }));
            menuLayout.addView(buttonflesh);
                }
            var buttoncash = new android.widget.Button(ctx);
            buttoncash.setText("$:" + cash);
            buttoncash.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){}
            }));
            menuLayout.addView(buttoncash);
            if(Vampire==2)
            {
            var buttonskl = new android.widget.Button(ctx);
            buttonskl.setText("Acquired Skills");
            buttonskl.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
if(shelf > 399)
{
clientMessage(ChatColor.RED + "Botany Mastered");
}
if(shelf > 499)
{
clientMessage(ChatColor.RED + "Riding the Wind");
}
if(shelf > 599)
{
clientMessage(ChatColor.RED + "Observer Platforms and Teleporter Compass");
}
if(shelf > 699)
{
clientMessage(ChatColor.RED + "Alchemy");
}
if(shelf > 799)
{
clientMessage(ChatColor.RED + "Mind Reader");
}
if(shelf > 899)
{
clientMessage(ChatColor.RED + "Glass Ether Trap");
}
if(shelf > 999)
{
clientMessage(ChatColor.RED + "Vampiric Maturity");
}
if(shelf > 1099)
{
clientMessage(ChatColor.RED + "Zombie Pigman Summon");
}
if(shelf > 1199)
{
clientMessage(ChatColor.RED + "Harden");
}
if(shelf > 1299)
{
clientMessage(ChatColor.RED + "Necromancy");
}
if(shelf > 1399)
{
clientMessage(ChatColor.RED + "Focus");
}
                }
            }));
            menuLayout.addView(buttonskl);
            }

            var buttonend = new android.widget.Button(ctx);
            buttonend.setText("Leave Crypt");
            buttonend.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    co = 1;
                    menu.dismiss();
                }
            }));
            menuLayout.addView(buttonend);

            menu = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
            menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
            menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
        }catch(error){
            print("An error occured: " + error);
        }
    }}));
}

function attackHook(attacker,victim,x,y,z)
{

if(getCarriedItem()==471 && Player.getCarriedItemCount()>1 && Player.getCarriedItemCount()<64 && Entity.getEntityTypeId(victim)!=34 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
{
var botfeed = Entity.getHealth(victim);
preventDefault();
addItemInventory(471,-1);
Entity.setHealth(victim, botfeed - 5);
addItemInventory(472,1);
}

if(getCarriedItem()==471 && Player.getCarriedItemCount()<2 && Entity.getEntityTypeId(victim)!=34 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
{
preventDefault();
addItemInventory(471,-1);
clientMessage(ChatColor.BLUE + "Glass Bottle Broke");

var xxg = Entity.getX(victim);
var yyg = Entity.getY(victim);
var zzg = Entity.getZ(victim);

setTile(xxg, yyg, zzg, 20);
{

Level.destroyBlock(xxg, yyg, zzg, false)
}

}

if(getCarriedItem()==388 && Player.getCarriedItemCount()<64)
{
Entity.setMobSkin(victim,"mob/char.png");
Entity.setRenderType(victim, 3);
addItemInventory(388,-1);
soul--;
}

if(Entity.getEntityTypeId(victim)!=34 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
{

var xx = Entity.getX(victim);
var yy = Entity.getY(victim);
var zz = Entity.getZ(victim);

setTile(xx, yy, zz, 11);
{

Level.destroyBlock(xx, yy, zz, false)
}

}


     if(Vampire == 2 && Entity.getEntityTypeId(victim)!=34 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84 && feedtic == 2 && Entity.getHealth(victim) > 1)
     {
preventDefault();

var xxt = Player.getX();
var yyt = Player.getY();
var zzt = Player.getZ();

setTile(xxt, yyt, zzt, 11);
setTile(xxt, yyt+1, zzt, 11);
{

Level.destroyBlock(xxt, yyt, zzt, false)
Level.destroyBlock(xxt, yyt+1, zzt, false)
}

         var feedplay = Entity.getHealth(getPlayerEnt());
         var feedmon = Entity.getHealth(victim);

Entity.setHealth(getPlayerEnt(), feedplay + 2);
Entity.setHealth(victim, feedmon - 2);
soul++;
clientMessage(ChatColor.RED + feedplay + "/" + feedmon + ChatColor.BLUE + ":" + ChatColor.GREEN + soul);
     }

     if(Vampire == 2 && getCarriedItem()==406 && Player.getCarriedItemCount()<64 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
     {
         Player.setHealth(20);
         Level.setTime(0);
         addItemInventory(406,-1);
         Entity.setHealth(victim,0);
         soul++;
     }
     if(Vampire == 2 && getCarriedItem()==260 && shelf > 999 && Entity.getEntityTypeId(victim)!=34 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84 && Entity.getHealth(victim) < 100)
     {
         clientMessage(ChatColor.RED + "gave a little blood...");
         var feed = Entity.getHealth(getPlayerEnt());
         Player.setHealth(feed - 6);
         Entity.setHealth(victim,100);
         soul--;
     }

if(getCarriedItem()==280 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
	{
		if(rocket == 1)
		{
			preventDefault();
			setVelY(victim,1.5);
		}   
		else
		if(tp == 1)
		{
			preventDefault();
		   Entity.setFireTicks(victim,3.5);
		}
		else
		if(grav == 1)
		{
			preventDefault();
			Entity.setHealth(victim,0);
         soul--;
		}
		else
		if(exp == 1)
		{
			preventDefault();
		   clientMessage(ChatColor.BLACK + "****");
		}
      		else
		if(ride == 1)
		{
			preventDefault();
			rideAnimal(attacker,victim); 
		}
 }

 if(getCarriedItem() == 340 && shelf > 799 && Vampire == 2 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
{
preventDefault();
clientMessage(ChatColor.BLUE + "Age:" + Entity.getAnimalAge(victim));
clientMessage(ChatColor.BLUE + "Type:" + Entity.getEntityTypeId(victim));
clientMessage(ChatColor.BLUE + "Health:" + Entity.getHealth(victim));
clientMessage(ChatColor.BLUE + "Coords: X" + Entity.getX(victim) + "Y" +  Entity.getY(victim) + "Z" + Entity.getZ(victim));
}
if(getCarriedItem() == 20 && shelf > 899 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83)
{
  if(trap == 0)
  {
     gb1 = Entity.getEntityTypeId(victim);
     Entity.remove(victim);
     trap = 1;
     clientMessage("Mob Trapped in Ether");
  }
  else if(trap == 1)
  {
     gb2 = Entity.getEntityTypeId(victim);
     Entity.remove(victim);
     trap = 2;
     clientMessage("Mob Trapped in Ether");
  }
  else if(trap == 2)
  {
     gb3 = Entity.getEntityTypeId(victim);
     Entity.remove(victim);
     trap = 3;
     clientMessage("Mob Trapped in Ether");
  }
  else if(trap == 3)
  {
     gb4 = Entity.getEntityTypeId(victim);
     Entity.remove(victim);
     trap = 4;
     clientMessage("Mob Trapped in Ether");
  }
  else if(trap == 4)
  {
     gb5 = Entity.getEntityTypeId(victim);
     Entity.remove(victim);
     trap = 5;
     clientMessage("Mob Trapped in Ether");
  }
  else if(trap == 5)
  {
     clientMessage(ChatColor.BLUE + "Glass Ethers Full!");
  }
}
if(getCarriedItem() == 341 && Entity.getEntityTypeId(victim) == 12 && shelf > 1099 && Vampire == 2 &&Player.getCarriedItemCount()<64)
{
     var PZx = Entity.getX(victim);
     var PZy = Entity.getY(victim);
     var PZz = Entity.getZ(victim);
     addItemInventory(341,-1);
     Entity.remove(victim);
     Level.spawnMob(PZx,PZy,PZz,36);
     soul--;
}
}

function deathHook(murderer, victim, x, y, z)
{ 
     var mx = Entity.getX(victim);
     var my = Entity.getY(victim);
     var mz = Entity.getZ(victim);

     cash++;

     if(shelf > 399 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
     {
     var moneydeath = Math.floor((Math.random()*3)+1);
if(moneydeath == 3) {
         Level.dropItem(mx, my, mz, 1, 388, 1, 0);
     }
     }

     if(Vampire == 2 && Entity.getEntityTypeId(victim)!=34 && Entity.getEntityTypeId(victim)!=64 && Entity.getEntityTypeId(victim)!=65 && Entity.getEntityTypeId(victim)!=66 && Entity.getEntityTypeId(victim)!=80 && Entity.getEntityTypeId(victim)!=81 && Entity.getEntityTypeId(victim)!=82 && Entity.getEntityTypeId(victim)!=83 && Entity.getEntityTypeId(victim)!=84)
     {
     var fleshdeath = Math.floor((Math.random()*3)+1);
if(fleshdeath == 3) {
         Level.dropItem(mx, my, mz, 1, 367, 1, 0);
     }
     }

     if(Entity.getEntityTypeId(victim)==35)
{
Level.dropItem(mx, my, mz, 1, 375, 1, 0);
}
}

function useItem(x, y, z, itemId, blockId) {

var feedtab = Entity.getHealth(getPlayerEnt());

if(itemId==474 && Player.getCarriedItemCount()<64)
{
addItemInventory(474,-1);
sunblock = 1;
}

if(itemId == 375 && blockId == 26 && Player.getCarriedItemCount()<64)
{
addItemInventory(375,-1);

var bite = Math.floor((Math.random()*6)+1);
if(bite == 3) {
clientMessage(ChatColor.RED + "You Feel Bloody....");
Vampire = 2;
check = 2;
soul--;
}
}

if(itemId==475 && blockId==47)
{
setTile(x, y, z, 70);
}

if(itemId!= 388 && itemId!= 280 && itemId!= 473 && blockId==70 && mo == 1)
{
mo = 2;
mainMenu();
}

if(itemId== 388 && blockId==70 && Player.getCarriedItemCount()<64)
{
cash++;
addItemInventory(388, -1);
}

if (blockId == 26 && dream == 0) {

Level.setSpawn(Player.getX(),Player.getY(),Player.getZ());
sunblock = 0;
var random = Math.floor((Math.random()*6)+1);
if(random == 1) {
	 preventDefault();
Px = getPlayerX(); 
Py = getPlayerY(); 
Pz = getPlayerZ(); 
setTile (1, 1, 1, 173); 
setTile (1, 1, 2, 173); 
setTile (2, 1, 1, 173); 
setTile (2, 1, 2, 173); 
setTile (3, 1, 1, 173); 
setTile (1, 1, 3, 173); 
setTile (2, 1, 3, 173); 
setTile (3, 1, 2, 173); 
setTile (3, 1, 3, 173); 
setTile (4, 1, 1, 173); 
setTile (1, 1, 4, 173); 
setTile (2, 1, 4, 173); 
setTile (4, 1, 2, 173); 
setTile (3, 1, 4, 173); 
setTile (4, 1, 3, 173); 
setTile (4, 1, 4, 173); 
setTile (5, 1, 1, 173); 
setTile (1, 1, 5, 173); 
setTile (2, 1, 5, 173); 
setTile (5, 1, 2, 173); 
setTile (3, 1, 5, 173); 
setTile (5, 1, 3, 173); 
setTile (4, 1, 5, 173); 
setTile (5, 1, 4, 173); 
setTile (5, 1, 5, 173); 
setTile (7, 1, 7, 173); 
setTile (7, 1, 1, 173); 
setTile (1, 1, 7, 173); 
setTile (7, 1, 2, 173); 
setTile (2, 1, 7, 173); 
setTile (3, 1, 7, 173); 
setTile (7, 1, 3, 173); 
setTile (4, 1, 7, 173); 
setTile (7, 1, 4, 173); 
setTile (5, 1, 7, 173); 
setTile (7, 1, 5, 173); 
setTile (6, 1, 7, 173); 
setTile (7, 1, 6, 173); 
setTile (6, 1, 5, 173); 
setTile (5, 1, 6, 173); 
setTile (4, 1, 6, 173); 
setTile (6, 1, 4, 173); 
setTile (3, 1, 6, 173); 
setTile (6, 1, 3, 173); 
setTile (6, 1, 2, 173); 
setTile (2, 1, 6, 173); 
setTile (1, 1, 6, 173); 
setTile (6, 1, 1, 173); 
setTile (6, 1, 6, 173); 
setTile (1, 2, 1, 173); 
setTile (1, 2, 2, 173); 
setTile (2, 2, 1, 173); 
setTile (2, 2, 2, 0); 
setTile (3, 2, 1, 173); 
setTile (1, 2, 3, 173); 
setTile (2, 2, 3, 0); 
setTile (3, 2, 2, 0); 
setTile (3, 2, 3, 0); 
setTile (4, 2, 1, 173); 
setTile (1, 2, 4, 173); 
setTile (2, 2, 4, 0); 
setTile (3, 2, 4, 0); 
setTile (4, 2, 3, 0); 
setTile (4, 2, 4, 0); 
setTile (5, 2, 1, 173); 
setTile (1, 2, 5, 173); 
setTile (2, 2, 5, 0); 
setTile (5, 2, 2, 0); 
setTile (3, 2, 5, 0); 
setTile (5, 2, 3, 0); 
setTile (4, 2, 5, 0); 
setTile (5, 2, 4, 0); 
setTile (5, 2, 5, 0); 
setTile (7, 2, 7, 173); 
setTile (7, 2, 1, 173); 
setTile (1, 2, 7, 173); 
setTile (7, 2, 2, 173); 
setTile (2, 2, 7, 173); 
setTile (3, 2, 7, 173); 
setTile (7, 2, 3, 173); 
setTile (4, 2, 7, 173); 
setTile (7, 2, 4, 173); 
setTile (5, 2, 7, 173); 
setTile (7, 2, 5, 173); 
setTile (6, 2, 7, 173); 
setTile (7, 2, 6, 173); 
setTile (6, 2, 5, 0); 
setTile (5, 2, 6, 0); 
setTile (4, 2, 6, 0); 
setTile (6, 2, 4, 0); 
setTile (3, 2, 6, 0); 
setTile (6, 2, 3, 0); 
setTile (6, 2, 2, 0); 
setTile (2, 2, 6, 0); 
setTile (1, 2, 6, 173); 
setTile (6, 2, 1, 173); 
setTile (6, 2, 6, 0); 
setTile (1, 3, 1, 173); 
setTile (1, 3, 2, 173); 
setTile (2, 3, 1, 173); 
setTile (2, 3, 2, 0); 
setTile (3, 3, 1, 173); 
setTile (1, 3, 3, 173); 
setTile (2, 3, 3, 0); 
setTile (3, 3, 2, 0); 
setTile (3, 3, 3, 0); 
setTile (4, 3, 1, 173); 
setTile (1, 3, 4, 173); 
setTile (2, 3, 4, 0); 
setTile (4, 3, 2, 0); 
setTile (3, 3, 4, 0); 
setTile (4, 3, 3, 0); 
setTile (4, 3, 4, 0); 
setTile (5, 3, 1, 173); 
setTile (1, 3, 5, 173); 
setTile (2, 3, 5, 0); 
setTile (5, 3, 2, 0); 
setTile (3, 3, 5, 0); 
setTile (5, 3, 3, 0); 
setTile (4, 3, 5, 0); 
setTile (5, 3, 4, 0); 
setTile (5, 3, 5, 0); 
setTile (7, 3, 7, 173); 
setTile (7, 3, 1, 173); 
setTile (1, 3, 7, 173); 
setTile (7, 3, 2, 173); 
setTile (2, 3, 7, 173); 
setTile (3, 3, 7, 173); 
setTile (7, 3, 3, 173); 
setTile (4, 3, 7, 173); 
setTile (7, 3, 4, 173); 
setTile (5, 3, 7, 173); 
setTile (7, 3, 5, 173); 
setTile (6, 3, 7, 173); 
setTile (7, 3, 6, 173); 
setTile (6, 3, 5, 0); 
setTile (5, 3, 6, 0); 
setTile (4, 3, 6, 0); 
setTile (6, 3, 4, 0); 
setTile (3, 3, 6, 0); 
setTile (6, 3, 3, 0); 
setTile (6, 3, 2, 0); 
setTile (2, 3, 6, 0); 
setTile (1, 3, 6, 173); 
setTile (6, 3, 1, 173); 
setTile (6, 3, 6, 0); 
setTile (1, 4, 1, 173); 
setTile (1, 4, 2, 173); 
setTile (2, 4, 1, 173); 
setTile (2, 4, 2, 0); 
setTile (3, 4, 1, 173); 
setTile (1, 4, 3, 173); 
setTile (2, 4, 3, 0); 
setTile (3, 4, 2, 0); 
setTile (3, 4, 3, 0); 
setTile (4, 4, 1, 173); 
setTile (1, 4, 4, 173); 
setTile (2, 4, 4, 0); 
setTile (4, 4, 2, 0); 
setTile (3, 4, 4, 0); 
setTile (4, 4, 3, 0); 
setTile (4, 4, 4, 0); 
setTile (5, 4, 1, 173); 
setTile (1, 4, 5, 173); 
setTile (2, 4, 5, 0); 
setTile (5, 4, 2, 0); 
setTile (3, 4, 5, 0); 
setTile (5, 4, 3, 0); 
setTile (4, 4, 5, 0); 
setTile (5, 4, 4, 0); 
setTile (5, 4, 5, 0); 
setTile (7, 4, 7, 173); 
setTile (7, 4, 1, 173); 
setTile (1, 4, 7, 173); 
setTile (7, 4, 2, 173); 
setTile (2, 4, 7, 173); 
setTile (3, 4, 7, 173); 
setTile (7, 4, 3, 173); 
setTile (4, 4, 7, 173); 
setTile (7, 4, 4, 173); 
setTile (5, 4, 7, 173); 
setTile (7, 4, 5, 173); 
setTile (6, 4, 7, 173); 
setTile (7, 4, 6, 173); 
setTile (6, 4, 5, 0); 
setTile (5, 4, 6, 0); 
setTile (4, 4, 6, 0); 
setTile (6, 4, 4, 0); 
setTile (3, 4, 6, 0); 
setTile (6, 4, 3, 0); 
setTile (6, 4, 2, 0); 
setTile (2, 4, 6, 0); 
setTile (1, 4, 6, 173); 
setTile (6, 4, 1, 173); 
setTile (6, 4, 6, 0); 
setTile (1, 5, 1, 173); 
setTile (1, 5, 2, 173); 
setTile (2, 5, 1, 173); 
setTile (2, 5, 2, 0); 
setTile (3, 5, 1, 173); 
setTile (1, 5, 3, 173); 
setTile (2, 5, 3, 0); 
setTile (3, 5, 2, 0); 
setTile (3, 5, 3, 0); 
setTile (4, 5, 1, 173); 
setTile (1, 5, 4, 173); 
setTile (2, 5, 4, 0); 
setTile (4, 5, 2, 0); 
setTile (3, 5, 4, 0); 
setTile (4, 5, 3, 0); 
setTile (4, 5, 4, 0); 
setTile (5, 5, 1, 173); 
setTile (1, 5, 5, 173); 
setTile (2, 5, 5, 0); 
setTile (5, 5, 2, 0); 
setTile (3, 5, 5, 0); 
setTile (5, 5, 3, 0); 
setTile (4, 5, 5, 0); 
setTile (5, 5, 4, 0); 
setTile (5, 5, 5, 0); 
setTile (7, 5, 7, 173); 
setTile (7, 5, 1, 173); 
setTile (1, 5, 7, 173); 
setTile (7, 5, 2, 173); 
setTile (2, 5, 7, 173); 
setTile (3, 5, 7, 173); 
setTile (7, 5, 3, 173); 
setTile (4, 5, 7, 173); 
setTile (7, 5, 4, 173); 
setTile (5, 5, 7, 173); 
setTile (7, 5, 5, 173); 
setTile (6, 5, 7, 173); 
setTile (7, 5, 6, 173); 
setTile (6, 5, 5, 0); 
setTile (5, 5, 6, 0); 
setTile (4, 5, 6, 0); 
setTile (6, 5, 4, 0); 
setTile (3, 5, 6, 0); 
setTile (6, 5, 3, 0); 
setTile (6, 5, 2, 0); 
setTile (2, 5, 6, 0); 
setTile (1, 5, 6, 173); 
setTile (6, 5, 1, 173); 
setTile (6, 5, 6, 173);
setTile (1, 6, 1, 173); 
setTile (1, 6, 2, 173); 
setTile (2, 6, 1, 173); 
setTile (2, 6, 2, 173); 
setTile (3, 6, 1, 173); 
setTile (1, 6, 3, 173); 
setTile (2, 6, 3, 173); 
setTile (3, 6, 2, 173); 
setTile (3, 6, 3, 173); 
setTile (4, 6, 1, 173); 
setTile (1, 6, 4, 173); 
setTile (2, 6, 4, 173); 
setTile (4, 6, 2, 173); 
setTile (3, 6, 4, 173); 
setTile (4, 6, 3, 173); 
setTile (4, 6, 4, 173); 
setTile (5, 6, 1, 173); 
setTile (1, 6, 5, 173); 
setTile (2, 6, 5, 173); 
setTile (5, 6, 2, 173); 
setTile (3, 6, 5, 173); 
setTile (5, 6, 3, 173); 
setTile (4, 6, 5, 173); 
setTile (5, 6, 4, 173); 
setTile (5, 6, 5, 173); 
setTile (7, 6, 7, 173); 
setTile (7, 6, 1, 173); 
setTile (1, 6, 7, 173); 
setTile (7, 6, 2, 173); 
setTile (2, 6, 7, 173); 
setTile (3, 6, 7, 173); 
setTile (7, 6, 3, 173); 
setTile (4, 6, 7, 173); 
setTile (7, 6, 4, 173); 
setTile (5, 6, 7, 173); 
setTile (7, 6, 5, 173); 
setTile (6, 6, 7, 173); 
setTile (7, 6, 6, 173); 
setTile (6, 6, 5, 173); 
setTile (5, 6, 6, 173); 
setTile (4, 6, 6, 173); 
setTile (6, 6, 4, 173); 
setTile (3, 6, 6, 173); 
setTile (6, 6, 3, 173); 
setTile (6, 6, 2, 173); 
setTile (2, 6, 6, 173); 
setTile (1, 6, 6, 173); 
setTile (6, 6, 1, 173); 
setTile (6, 6, 6, 173); 
setPosition(getPlayerEnt(), 5, 4, 5); 
dream = 1; 
setTile(4, 2, 2, 246);
clientMessage(ChatColor.BLUE + "am i dreaming....");
Player.setHealth(20);
return; 
} else if (random == 2) {
	 clientMessage(ChatColor.BLACK + ".. .  ..... .  ..  .  ...  .  .... ....");
   if(Vampire==2)
{
preventDefault();
clientMessage(ChatColor.BLACK + ".. .  ..... .  ..  .  ...  .  .... ....");
}
} else if (random == 3) {
	 preventDefault();
Px = getPlayerX(); 
Py = getPlayerY(); 
Pz = getPlayerZ(); 
setTile (1, 1, 1, 173); 
setTile (1, 1, 2, 173); 
setTile (2, 1, 1, 173); 
setTile (2, 1, 2, 173); 
setTile (3, 1, 1, 173); 
setTile (1, 1, 3, 173); 
setTile (2, 1, 3, 173); 
setTile (3, 1, 2, 173); 
setTile (3, 1, 3, 173); 
setTile (4, 1, 1, 173); 
setTile (1, 1, 4, 173); 
setTile (2, 1, 4, 173); 
setTile (4, 1, 2, 173); 
setTile (3, 1, 4, 173); 
setTile (4, 1, 3, 173); 
setTile (4, 1, 4, 173); 
setTile (5, 1, 1, 173); 
setTile (1, 1, 5, 173); 
setTile (2, 1, 5, 173); 
setTile (5, 1, 2, 173); 
setTile (3, 1, 5, 173); 
setTile (5, 1, 3, 173); 
setTile (4, 1, 5, 173); 
setTile (5, 1, 4, 173); 
setTile (5, 1, 5, 173); 
setTile (7, 1, 7, 173); 
setTile (7, 1, 1, 173); 
setTile (1, 1, 7, 173); 
setTile (7, 1, 2, 173); 
setTile (2, 1, 7, 173); 
setTile (3, 1, 7, 173); 
setTile (7, 1, 3, 173); 
setTile (4, 1, 7, 173); 
setTile (7, 1, 4, 173); 
setTile (5, 1, 7, 173); 
setTile (7, 1, 5, 173); 
setTile (6, 1, 7, 173); 
setTile (7, 1, 6, 173); 
setTile (6, 1, 5, 173); 
setTile (5, 1, 6, 173); 
setTile (4, 1, 6, 173); 
setTile (6, 1, 4, 173); 
setTile (3, 1, 6, 173); 
setTile (6, 1, 3, 173); 
setTile (6, 1, 2, 173); 
setTile (2, 1, 6, 173); 
setTile (1, 1, 6, 173); 
setTile (6, 1, 1, 173); 
setTile (6, 1, 6, 173); 
setTile (1, 2, 1, 173); 
setTile (1, 2, 2, 173); 
setTile (2, 2, 1, 173); 
setTile (2, 2, 2, 0); 
setTile (3, 2, 1, 173); 
setTile (1, 2, 3, 173); 
setTile (2, 2, 3, 0); 
setTile (3, 2, 2, 0); 
setTile (3, 2, 3, 0); 
setTile (4, 2, 1, 173); 
setTile (1, 2, 4, 173); 
setTile (2, 2, 4, 0); 
setTile (3, 2, 4, 0); 
setTile (4, 2, 3, 0); 
setTile (4, 2, 4, 0); 
setTile (5, 2, 1, 173); 
setTile (1, 2, 5, 173); 
setTile (2, 2, 5, 0); 
setTile (5, 2, 2, 0); 
setTile (3, 2, 5, 0); 
setTile (5, 2, 3, 0); 
setTile (4, 2, 5, 0); 
setTile (5, 2, 4, 0); 
setTile (5, 2, 5, 0); 
setTile (7, 2, 7, 173); 
setTile (7, 2, 1, 173); 
setTile (1, 2, 7, 173); 
setTile (7, 2, 2, 173); 
setTile (2, 2, 7, 173); 
setTile (3, 2, 7, 173); 
setTile (7, 2, 3, 173); 
setTile (4, 2, 7, 173); 
setTile (7, 2, 4, 173); 
setTile (5, 2, 7, 173); 
setTile (7, 2, 5, 173); 
setTile (6, 2, 7, 173); 
setTile (7, 2, 6, 173); 
setTile (6, 2, 5, 0); 
setTile (5, 2, 6, 0); 
setTile (4, 2, 6, 0); 
setTile (6, 2, 4, 0); 
setTile (3, 2, 6, 0); 
setTile (6, 2, 3, 0); 
setTile (6, 2, 2, 0); 
setTile (2, 2, 6, 0); 
setTile (1, 2, 6, 173); 
setTile (6, 2, 1, 173); 
setTile (6, 2, 6, 0); 
setTile (1, 3, 1, 173); 
setTile (1, 3, 2, 173); 
setTile (2, 3, 1, 173); 
setTile (2, 3, 2, 0); 
setTile (3, 3, 1, 173); 
setTile (1, 3, 3, 173); 
setTile (2, 3, 3, 0); 
setTile (3, 3, 2, 0); 
setTile (3, 3, 3, 0); 
setTile (4, 3, 1, 173); 
setTile (1, 3, 4, 173); 
setTile (2, 3, 4, 0); 
setTile (4, 3, 2, 0); 
setTile (3, 3, 4, 0); 
setTile (4, 3, 3, 0); 
setTile (4, 3, 4, 0); 
setTile (5, 3, 1, 173); 
setTile (1, 3, 5, 173); 
setTile (2, 3, 5, 0); 
setTile (5, 3, 2, 0); 
setTile (3, 3, 5, 0); 
setTile (5, 3, 3, 0); 
setTile (4, 3, 5, 0); 
setTile (5, 3, 4, 0); 
setTile (5, 3, 5, 0); 
setTile (7, 3, 7, 173); 
setTile (7, 3, 1, 173); 
setTile (1, 3, 7, 173); 
setTile (7, 3, 2, 173); 
setTile (2, 3, 7, 173); 
setTile (3, 3, 7, 173); 
setTile (7, 3, 3, 173); 
setTile (4, 3, 7, 173); 
setTile (7, 3, 4, 173); 
setTile (5, 3, 7, 173); 
setTile (7, 3, 5, 173); 
setTile (6, 3, 7, 173); 
setTile (7, 3, 6, 173); 
setTile (6, 3, 5, 0); 
setTile (5, 3, 6, 0); 
setTile (4, 3, 6, 0); 
setTile (6, 3, 4, 0); 
setTile (3, 3, 6, 0); 
setTile (6, 3, 3, 0); 
setTile (6, 3, 2, 0); 
setTile (2, 3, 6, 0); 
setTile (1, 3, 6, 173); 
setTile (6, 3, 1, 173); 
setTile (6, 3, 6, 0); 
setTile (1, 4, 1, 173); 
setTile (1, 4, 2, 173); 
setTile (2, 4, 1, 173); 
setTile (2, 4, 2, 0); 
setTile (3, 4, 1, 173); 
setTile (1, 4, 3, 173); 
setTile (2, 4, 3, 0); 
setTile (3, 4, 2, 0); 
setTile (3, 4, 3, 0); 
setTile (4, 4, 1, 173); 
setTile (1, 4, 4, 173); 
setTile (2, 4, 4, 0); 
setTile (4, 4, 2, 0); 
setTile (3, 4, 4, 0); 
setTile (4, 4, 3, 0); 
setTile (4, 4, 4, 0); 
setTile (5, 4, 1, 173); 
setTile (1, 4, 5, 173); 
setTile (2, 4, 5, 0); 
setTile (5, 4, 2, 0); 
setTile (3, 4, 5, 0); 
setTile (5, 4, 3, 0); 
setTile (4, 4, 5, 0); 
setTile (5, 4, 4, 0); 
setTile (5, 4, 5, 0); 
setTile (7, 4, 7, 173); 
setTile (7, 4, 1, 173); 
setTile (1, 4, 7, 173); 
setTile (7, 4, 2, 173); 
setTile (2, 4, 7, 173); 
setTile (3, 4, 7, 173); 
setTile (7, 4, 3, 173); 
setTile (4, 4, 7, 173); 
setTile (7, 4, 4, 173); 
setTile (5, 4, 7, 173); 
setTile (7, 4, 5, 173); 
setTile (6, 4, 7, 173); 
setTile (7, 4, 6, 173); 
setTile (6, 4, 5, 0); 
setTile (5, 4, 6, 0); 
setTile (4, 4, 6, 0); 
setTile (6, 4, 4, 0); 
setTile (3, 4, 6, 0); 
setTile (6, 4, 3, 0); 
setTile (6, 4, 2, 0); 
setTile (2, 4, 6, 0); 
setTile (1, 4, 6, 173); 
setTile (6, 4, 1, 173); 
setTile (6, 4, 6, 0); 
setTile (1, 5, 1, 173); 
setTile (1, 5, 2, 173); 
setTile (2, 5, 1, 173); 
setTile (2, 5, 2, 0); 
setTile (3, 5, 1, 173); 
setTile (1, 5, 3, 173); 
setTile (2, 5, 3, 0); 
setTile (3, 5, 2, 0); 
setTile (3, 5, 3, 0); 
setTile (4, 5, 1, 173); 
setTile (1, 5, 4, 173); 
setTile (2, 5, 4, 0); 
setTile (4, 5, 2, 0); 
setTile (3, 5, 4, 0); 
setTile (4, 5, 3, 0); 
setTile (4, 5, 4, 0); 
setTile (5, 5, 1, 173); 
setTile (1, 5, 5, 173); 
setTile (2, 5, 5, 0); 
setTile (5, 5, 2, 0); 
setTile (3, 5, 5, 0); 
setTile (5, 5, 3, 0); 
setTile (4, 5, 5, 0); 
setTile (5, 5, 4, 0); 
setTile (5, 5, 5, 0); 
setTile (7, 5, 7, 173); 
setTile (7, 5, 1, 173); 
setTile (1, 5, 7, 173); 
setTile (7, 5, 2, 173); 
setTile (2, 5, 7, 173); 
setTile (3, 5, 7, 173); 
setTile (7, 5, 3, 173); 
setTile (4, 5, 7, 173); 
setTile (7, 5, 4, 173); 
setTile (5, 5, 7, 173); 
setTile (7, 5, 5, 173); 
setTile (6, 5, 7, 173); 
setTile (7, 5, 6, 173); 
setTile (6, 5, 5, 0); 
setTile (5, 5, 6, 0); 
setTile (4, 5, 6, 0); 
setTile (6, 5, 4, 0); 
setTile (3, 5, 6, 0); 
setTile (6, 5, 3, 0); 
setTile (6, 5, 2, 0); 
setTile (2, 5, 6, 0); 
setTile (1, 5, 6, 173); 
setTile (6, 5, 1, 173); 
setTile (6, 5, 6, 173);
setTile (1, 6, 1, 173); 
setTile (1, 6, 2, 173); 
setTile (2, 6, 1, 173); 
setTile (2, 6, 2, 173); 
setTile (3, 6, 1, 173); 
setTile (1, 6, 3, 173); 
setTile (2, 6, 3, 173); 
setTile (3, 6, 2, 173); 
setTile (3, 6, 3, 173); 
setTile (4, 6, 1, 173); 
setTile (1, 6, 4, 173); 
setTile (2, 6, 4, 173); 
setTile (4, 6, 2, 173); 
setTile (3, 6, 4, 173); 
setTile (4, 6, 3, 173); 
setTile (4, 6, 4, 173); 
setTile (5, 6, 1, 173); 
setTile (1, 6, 5, 173); 
setTile (2, 6, 5, 173); 
setTile (5, 6, 2, 173); 
setTile (3, 6, 5, 173); 
setTile (5, 6, 3, 173); 
setTile (4, 6, 5, 173); 
setTile (5, 6, 4, 173); 
setTile (5, 6, 5, 173); 
setTile (7, 6, 7, 173); 
setTile (7, 6, 1, 173); 
setTile (1, 6, 7, 173); 
setTile (7, 6, 2, 173); 
setTile (2, 6, 7, 173); 
setTile (3, 6, 7, 173); 
setTile (7, 6, 3, 173); 
setTile (4, 6, 7, 173); 
setTile (7, 6, 4, 173); 
setTile (5, 6, 7, 173); 
setTile (7, 6, 5, 173); 
setTile (6, 6, 7, 173); 
setTile (7, 6, 6, 173); 
setTile (6, 6, 5, 173); 
setTile (5, 6, 6, 173); 
setTile (4, 6, 6, 173); 
setTile (6, 6, 4, 173); 
setTile (3, 6, 6, 173); 
setTile (6, 6, 3, 173); 
setTile (6, 6, 2, 173); 
setTile (2, 6, 6, 173); 
setTile (1, 6, 6, 173); 
setTile (6, 6, 1, 173); 
setTile (6, 6, 6, 173); 
setPosition(getPlayerEnt(), 5, 4, 5); 
dream = 1; 
setTile(4, 2, 2, 245);
Level.dropItem(4, 3, 2, 1, 49, 1, 0);
clientMessage(ChatColor.BLUE + "am i dreaming....");
Player.setHealth(20);
return; 
} else if (random == 4) {
	 clientMessage(ChatColor.BLACK + ".. .  ..... .  ..  .  ...  .  .... ....");
    if(Vampire==2)
{
preventDefault();
clientMessage(ChatColor.BLACK + "...  .... ..  ..  ..  ..  ..  ....");
}
} else if (random == 5) {
	 preventDefault();
Px = getPlayerX(); 
Py = getPlayerY(); 
Pz = getPlayerZ(); 
setTile (1, 1, 1, 173); 
setTile (1, 1, 2, 173); 
setTile (2, 1, 1, 173); 
setTile (2, 1, 2, 173); 
setTile (3, 1, 1, 173); 
setTile (1, 1, 3, 173); 
setTile (2, 1, 3, 173); 
setTile (3, 1, 2, 173); 
setTile (3, 1, 3, 173); 
setTile (4, 1, 1, 173); 
setTile (1, 1, 4, 173); 
setTile (2, 1, 4, 173); 
setTile (4, 1, 2, 173); 
setTile (3, 1, 4, 173); 
setTile (4, 1, 3, 173); 
setTile (4, 1, 4, 173); 
setTile (5, 1, 1, 173); 
setTile (1, 1, 5, 173); 
setTile (2, 1, 5, 173); 
setTile (5, 1, 2, 173); 
setTile (3, 1, 5, 173); 
setTile (5, 1, 3, 173); 
setTile (4, 1, 5, 173); 
setTile (5, 1, 4, 173); 
setTile (5, 1, 5, 173); 
setTile (7, 1, 7, 173); 
setTile (7, 1, 1, 173); 
setTile (1, 1, 7, 173); 
setTile (7, 1, 2, 173); 
setTile (2, 1, 7, 173); 
setTile (3, 1, 7, 173); 
setTile (7, 1, 3, 173); 
setTile (4, 1, 7, 173); 
setTile (7, 1, 4, 173); 
setTile (5, 1, 7, 173); 
setTile (7, 1, 5, 173); 
setTile (6, 1, 7, 173); 
setTile (7, 1, 6, 173); 
setTile (6, 1, 5, 173); 
setTile (5, 1, 6, 173); 
setTile (4, 1, 6, 173); 
setTile (6, 1, 4, 173); 
setTile (3, 1, 6, 173); 
setTile (6, 1, 3, 173); 
setTile (6, 1, 2, 173); 
setTile (2, 1, 6, 173); 
setTile (1, 1, 6, 173); 
setTile (6, 1, 1, 173); 
setTile (6, 1, 6, 173); 
setTile (1, 2, 1, 173); 
setTile (1, 2, 2, 173); 
setTile (2, 2, 1, 173); 
setTile (2, 2, 2, 0); 
setTile (3, 2, 1, 173); 
setTile (1, 2, 3, 173); 
setTile (2, 2, 3, 0); 
setTile (3, 2, 2, 0); 
setTile (3, 2, 3, 0); 
setTile (4, 2, 1, 173); 
setTile (1, 2, 4, 173); 
setTile (2, 2, 4, 0); 
setTile (3, 2, 4, 0); 
setTile (4, 2, 3, 0); 
setTile (4, 2, 4, 0); 
setTile (5, 2, 1, 173); 
setTile (1, 2, 5, 173); 
setTile (2, 2, 5, 0); 
setTile (5, 2, 2, 0); 
setTile (3, 2, 5, 0); 
setTile (5, 2, 3, 0); 
setTile (4, 2, 5, 0); 
setTile (5, 2, 4, 0); 
setTile (5, 2, 5, 0); 
setTile (7, 2, 7, 173); 
setTile (7, 2, 1, 173); 
setTile (1, 2, 7, 173); 
setTile (7, 2, 2, 173); 
setTile (2, 2, 7, 173); 
setTile (3, 2, 7, 173); 
setTile (7, 2, 3, 173); 
setTile (4, 2, 7, 173); 
setTile (7, 2, 4, 173); 
setTile (5, 2, 7, 173); 
setTile (7, 2, 5, 173); 
setTile (6, 2, 7, 173); 
setTile (7, 2, 6, 173); 
setTile (6, 2, 5, 0); 
setTile (5, 2, 6, 0); 
setTile (4, 2, 6, 0); 
setTile (6, 2, 4, 0); 
setTile (3, 2, 6, 0); 
setTile (6, 2, 3, 0); 
setTile (6, 2, 2, 0); 
setTile (2, 2, 6, 0); 
setTile (1, 2, 6, 173); 
setTile (6, 2, 1, 173); 
setTile (6, 2, 6, 0); 
setTile (1, 3, 1, 173); 
setTile (1, 3, 2, 173); 
setTile (2, 3, 1, 173); 
setTile (2, 3, 2, 0); 
setTile (3, 3, 1, 173); 
setTile (1, 3, 3, 173); 
setTile (2, 3, 3, 0); 
setTile (3, 3, 2, 0); 
setTile (3, 3, 3, 0); 
setTile (4, 3, 1, 173); 
setTile (1, 3, 4, 173); 
setTile (2, 3, 4, 0); 
setTile (4, 3, 2, 0); 
setTile (3, 3, 4, 0); 
setTile (4, 3, 3, 0); 
setTile (4, 3, 4, 0); 
setTile (5, 3, 1, 173); 
setTile (1, 3, 5, 173); 
setTile (2, 3, 5, 0); 
setTile (5, 3, 2, 0); 
setTile (3, 3, 5, 0); 
setTile (5, 3, 3, 0); 
setTile (4, 3, 5, 0); 
setTile (5, 3, 4, 0); 
setTile (5, 3, 5, 0); 
setTile (7, 3, 7, 173); 
setTile (7, 3, 1, 173); 
setTile (1, 3, 7, 173); 
setTile (7, 3, 2, 173); 
setTile (2, 3, 7, 173); 
setTile (3, 3, 7, 173); 
setTile (7, 3, 3, 173); 
setTile (4, 3, 7, 173); 
setTile (7, 3, 4, 173); 
setTile (5, 3, 7, 173); 
setTile (7, 3, 5, 173); 
setTile (6, 3, 7, 173); 
setTile (7, 3, 6, 173); 
setTile (6, 3, 5, 0); 
setTile (5, 3, 6, 0); 
setTile (4, 3, 6, 0); 
setTile (6, 3, 4, 0); 
setTile (3, 3, 6, 0); 
setTile (6, 3, 3, 0); 
setTile (6, 3, 2, 0); 
setTile (2, 3, 6, 0); 
setTile (1, 3, 6, 173); 
setTile (6, 3, 1, 173); 
setTile (6, 3, 6, 0); 
setTile (1, 4, 1, 173); 
setTile (1, 4, 2, 173); 
setTile (2, 4, 1, 173); 
setTile (2, 4, 2, 0); 
setTile (3, 4, 1, 173); 
setTile (1, 4, 3, 173); 
setTile (2, 4, 3, 0); 
setTile (3, 4, 2, 0); 
setTile (3, 4, 3, 0); 
setTile (4, 4, 1, 173); 
setTile (1, 4, 4, 173); 
setTile (2, 4, 4, 0); 
setTile (4, 4, 2, 0); 
setTile (3, 4, 4, 0); 
setTile (4, 4, 3, 0); 
setTile (4, 4, 4, 0); 
setTile (5, 4, 1, 173); 
setTile (1, 4, 5, 173); 
setTile (2, 4, 5, 0); 
setTile (5, 4, 2, 0); 
setTile (3, 4, 5, 0); 
setTile (5, 4, 3, 0); 
setTile (4, 4, 5, 0); 
setTile (5, 4, 4, 0); 
setTile (5, 4, 5, 0); 
setTile (7, 4, 7, 173); 
setTile (7, 4, 1, 173); 
setTile (1, 4, 7, 173); 
setTile (7, 4, 2, 173); 
setTile (2, 4, 7, 173); 
setTile (3, 4, 7, 173); 
setTile (7, 4, 3, 173); 
setTile (4, 4, 7, 173); 
setTile (7, 4, 4, 173); 
setTile (5, 4, 7, 173); 
setTile (7, 4, 5, 173); 
setTile (6, 4, 7, 173); 
setTile (7, 4, 6, 173); 
setTile (6, 4, 5, 0); 
setTile (5, 4, 6, 0); 
setTile (4, 4, 6, 0); 
setTile (6, 4, 4, 0); 
setTile (3, 4, 6, 0); 
setTile (6, 4, 3, 0); 
setTile (6, 4, 2, 0); 
setTile (2, 4, 6, 0); 
setTile (1, 4, 6, 173); 
setTile (6, 4, 1, 173); 
setTile (6, 4, 6, 0); 
setTile (1, 5, 1, 173); 
setTile (1, 5, 2, 173); 
setTile (2, 5, 1, 173); 
setTile (2, 5, 2, 0); 
setTile (3, 5, 1, 173); 
setTile (1, 5, 3, 173); 
setTile (2, 5, 3, 0); 
setTile (3, 5, 2, 0); 
setTile (3, 5, 3, 0); 
setTile (4, 5, 1, 173); 
setTile (1, 5, 4, 173); 
setTile (2, 5, 4, 0); 
setTile (4, 5, 2, 0); 
setTile (3, 5, 4, 0); 
setTile (4, 5, 3, 0); 
setTile (4, 5, 4, 0); 
setTile (5, 5, 1, 173); 
setTile (1, 5, 5, 173); 
setTile (2, 5, 5, 0); 
setTile (5, 5, 2, 0); 
setTile (3, 5, 5, 0); 
setTile (5, 5, 3, 0); 
setTile (4, 5, 5, 0); 
setTile (5, 5, 4, 0); 
setTile (5, 5, 5, 0); 
setTile (7, 5, 7, 173); 
setTile (7, 5, 1, 173); 
setTile (1, 5, 7, 173); 
setTile (7, 5, 2, 173); 
setTile (2, 5, 7, 173); 
setTile (3, 5, 7, 173); 
setTile (7, 5, 3, 173); 
setTile (4, 5, 7, 173); 
setTile (7, 5, 4, 173); 
setTile (5, 5, 7, 173); 
setTile (7, 5, 5, 173); 
setTile (6, 5, 7, 173); 
setTile (7, 5, 6, 173); 
setTile (6, 5, 5, 0); 
setTile (5, 5, 6, 0); 
setTile (4, 5, 6, 0); 
setTile (6, 5, 4, 0); 
setTile (3, 5, 6, 0); 
setTile (6, 5, 3, 0); 
setTile (6, 5, 2, 0); 
setTile (2, 5, 6, 0); 
setTile (1, 5, 6, 173); 
setTile (6, 5, 1, 173); 
setTile (6, 5, 6, 173);
setTile (1, 6, 1, 173); 
setTile (1, 6, 2, 173); 
setTile (2, 6, 1, 173); 
setTile (2, 6, 2, 173); 
setTile (3, 6, 1, 173); 
setTile (1, 6, 3, 173); 
setTile (2, 6, 3, 173); 
setTile (3, 6, 2, 173); 
setTile (3, 6, 3, 173); 
setTile (4, 6, 1, 173); 
setTile (1, 6, 4, 173); 
setTile (2, 6, 4, 173); 
setTile (4, 6, 2, 173); 
setTile (3, 6, 4, 173); 
setTile (4, 6, 3, 173); 
setTile (4, 6, 4, 173); 
setTile (5, 6, 1, 173); 
setTile (1, 6, 5, 173); 
setTile (2, 6, 5, 173); 
setTile (5, 6, 2, 173); 
setTile (3, 6, 5, 173); 
setTile (5, 6, 3, 173); 
setTile (4, 6, 5, 173); 
setTile (5, 6, 4, 173); 
setTile (5, 6, 5, 173); 
setTile (7, 6, 7, 173); 
setTile (7, 6, 1, 173); 
setTile (1, 6, 7, 173); 
setTile (7, 6, 2, 173); 
setTile (2, 6, 7, 173); 
setTile (3, 6, 7, 173); 
setTile (7, 6, 3, 173); 
setTile (4, 6, 7, 173); 
setTile (7, 6, 4, 173); 
setTile (5, 6, 7, 173); 
setTile (7, 6, 5, 173); 
setTile (6, 6, 7, 173); 
setTile (7, 6, 6, 173); 
setTile (6, 6, 5, 173); 
setTile (5, 6, 6, 173); 
setTile (4, 6, 6, 173); 
setTile (6, 6, 4, 173); 
setTile (3, 6, 6, 173); 
setTile (6, 6, 3, 173); 
setTile (6, 6, 2, 173); 
setTile (2, 6, 6, 173); 
setTile (1, 6, 6, 173); 
setTile (6, 6, 1, 173); 
setTile (6, 6, 6, 173); 
setPosition(getPlayerEnt(), 5, 4, 5); 
dream = 1; 
setTile(4, 2, 2, 54);
clientMessage(ChatColor.BLUE + "am i dreaming....");
Player.setHealth(20);
return;
} else if (random == 6) {
	 clientMessage(ChatColor.BLACK + ".. .  ..... .  ..  .  ...  .  .... ....");
    if(Vampire==2)
{
preventDefault();
clientMessage(ChatColor.BLACK + "... ..   ..  nichtoe.  ... .. .   .   .");
}
}
}
if(blockId == 246 && dream == 1)
{
setTile(x,y,z,0);
Level.dropItem(x, y, z, 1, 260, 1, 0); 
}
if(itemId == 260 && dream == 1)
{
dream = 0;
setPosition(getPlayerEnt(), Px, Py, Pz);
Player.setHealth(20);
Level.setTime(0);
if(Vampire==2)
{
Level.setTime(29388);
var randomCA = Math.floor((Math.random()*10)+1);
if(randomCA == 5) {
soul++;
}
}
}

if(itemId == 49 && blockId == 245 && dream == 1 && Player.getCarriedItemCount()<64)
{
preventDefault();
dream = 0;
addItemInventory(49,-1);
setPosition(getPlayerEnt(), Px, Py, Pz);
Player.setHealth(20);
Level.setTime(0);
if(Vampire==2)
{
Level.setTime(29388);
var randomCO = Math.floor((Math.random()*10)+1);
if(randomCO == 5) {
soul++;
}
}
}
if(blockId == 54 && dream == 1)
{
preventDefault();
setTile(x,y,z,0);
Level.spawnMob(x, y+1, z, 35);
Level.spawnMob(x, y+1, z, 35);
clientMessage("AAAAAAAAHHHHH!!!!!");
soul--;
}
if(itemId == 287 && dream == 1)
{
dream = 0;
Player.setHealth(20);
setPosition(getPlayerEnt(), Px, Py, Pz);
Player.setHealth(20);
Level.setTime(0);
if(Vampire==2)
{
Level.setTime(29388);
var randomCS = Math.floor((Math.random()*10)+1);
if(randomCS == 5) {
soul++;
}
}
}
if (blockId == 26 && dream == 1)
{
dream = 0;
clientMessage("that was eerie...");
soul--;
}
if(blockId == 1 && dream == 1)
{
dream = 0;
Player.setHealth(20);
setPosition(getPlayerEnt(), Px, Py, Pz);
Player.setHealth(20);
Level.setTime(0);
if(Vampire==2)
{
Level.setTime(29388);
soul--;
}
}

if(itemId == 473 && blockId == 246 && getTile(x+1, y+1, z) == 50 && getTile(x-1, y+1, z) == 50 && getTile(x, y+1, z+1) == 50 && getTile(x, y+1, z-1) == 50 && Vampire == 2 && shelf > 999)
{
clientMessage(ChatColor.BLACK + "Rituale SpideWick Hound");
Entity.setRenderType(Player.getEntity(), 8);
Entity.setMobSkin(Player.getEntity(), "mob/spider.png");
pig = true;
soul--;
}

if(itemId == 385 && blockId == 64 && getTile(x,y+2,z) == 173 && getTile(x,y-1,z) == 173 && prime == false && Vampire == 2 && Player.getCarriedItemCount()<64)
{
clientMessage("the door creaks.....");
addItemInventory(385,-1);
prime = true;
soul--;
}

if(itemId == 263 && blockId == 64 && getTile(x,y+2,z) == 173 && getTile(x,y-1,z) == 173 && Player.getCarriedItemCount()<64)
{
     prime = false;
     addItemInventory(263,-1);
     preventDefault();
Px = getPlayerX(); 
Py = getPlayerY(); 
Pz = getPlayerZ(); 
setTile (1, 1, 1, 173); 
setTile (1, 1, 2, 173); 
setTile (2, 1, 1, 173); 
setTile (2, 1, 2, 173); 
setTile (3, 1, 1, 173); 
setTile (1, 1, 3, 173); 
setTile (2, 1, 3, 173); 
setTile (3, 1, 2, 173); 
setTile (3, 1, 3, 173); 
setTile (4, 1, 1, 173); 
setTile (1, 1, 4, 173); 
setTile (2, 1, 4, 173); 
setTile (4, 1, 2, 173); 
setTile (3, 1, 4, 173); 
setTile (4, 1, 3, 173); 
setTile (4, 1, 4, 173); 
setTile (5, 1, 1, 173); 
setTile (1, 1, 5, 173); 
setTile (2, 1, 5, 173); 
setTile (5, 1, 2, 173); 
setTile (3, 1, 5, 173); 
setTile (5, 1, 3, 173); 
setTile (4, 1, 5, 173); 
setTile (5, 1, 4, 173); 
setTile (5, 1, 5, 173); 
setTile (7, 1, 7, 173); 
setTile (7, 1, 1, 173); 
setTile (1, 1, 7, 173); 
setTile (7, 1, 2, 173); 
setTile (2, 1, 7, 173); 
setTile (3, 1, 7, 173); 
setTile (7, 1, 3, 173); 
setTile (4, 1, 7, 173); 
setTile (7, 1, 4, 173); 
setTile (5, 1, 7, 173); 
setTile (7, 1, 5, 173); 
setTile (6, 1, 7, 173); 
setTile (7, 1, 6, 173); 
setTile (6, 1, 5, 173); 
setTile (5, 1, 6, 173); 
setTile (4, 1, 6, 173); 
setTile (6, 1, 4, 173); 
setTile (3, 1, 6, 173); 
setTile (6, 1, 3, 173); 
setTile (6, 1, 2, 173); 
setTile (2, 1, 6, 173); 
setTile (1, 1, 6, 173); 
setTile (6, 1, 1, 173); 
setTile (6, 1, 6, 173); 
setTile (1, 2, 1, 173); 
setTile (1, 2, 2, 173); 
setTile (2, 2, 1, 173); 
setTile (2, 2, 2, 0); 
setTile (3, 2, 1, 173); 
setTile (1, 2, 3, 173); 
setTile (2, 2, 3, 0); 
setTile (3, 2, 2, 0); 
setTile (3, 2, 3, 0); 
setTile (4, 2, 1, 173); 
setTile (1, 2, 4, 173); 
setTile (2, 2, 4, 0); 
setTile (3, 2, 4, 0); 
setTile (4, 2, 3, 0); 
setTile (4, 2, 4, 0); 
setTile (5, 2, 1, 173); 
setTile (1, 2, 5, 173); 
setTile (2, 2, 5, 0); 
setTile (5, 2, 2, 0); 
setTile (3, 2, 5, 0); 
setTile (5, 2, 3, 0); 
setTile (4, 2, 5, 0); 
setTile (5, 2, 4, 0); 
setTile (5, 2, 5, 0); 
setTile (7, 2, 7, 173); 
setTile (7, 2, 1, 173); 
setTile (1, 2, 7, 173); 
setTile (7, 2, 2, 173); 
setTile (2, 2, 7, 173); 
setTile (3, 2, 7, 173); 
setTile (7, 2, 3, 173); 
setTile (4, 2, 7, 173); 
setTile (7, 2, 4, 173); 
setTile (5, 2, 7, 173); 
setTile (7, 2, 5, 173); 
setTile (6, 2, 7, 173); 
setTile (7, 2, 6, 173); 
setTile (6, 2, 5, 0); 
setTile (5, 2, 6, 0); 
setTile (4, 2, 6, 0); 
setTile (6, 2, 4, 0); 
setTile (3, 2, 6, 0); 
setTile (6, 2, 3, 0); 
setTile (6, 2, 2, 0); 
setTile (2, 2, 6, 0); 
setTile (1, 2, 6, 173); 
setTile (6, 2, 1, 173); 
setTile (6, 2, 6, 0); 
setTile (1, 3, 1, 173); 
setTile (1, 3, 2, 173); 
setTile (2, 3, 1, 173); 
setTile (2, 3, 2, 0); 
setTile (3, 3, 1, 173); 
setTile (1, 3, 3, 173); 
setTile (2, 3, 3, 0); 
setTile (3, 3, 2, 0); 
setTile (3, 3, 3, 0); 
setTile (4, 3, 1, 173); 
setTile (1, 3, 4, 173); 
setTile (2, 3, 4, 0); 
setTile (4, 3, 2, 0); 
setTile (3, 3, 4, 0); 
setTile (4, 3, 3, 0); 
setTile (4, 3, 4, 0); 
setTile (5, 3, 1, 173); 
setTile (1, 3, 5, 173); 
setTile (2, 3, 5, 0); 
setTile (5, 3, 2, 0); 
setTile (3, 3, 5, 0); 
setTile (5, 3, 3, 0); 
setTile (4, 3, 5, 0); 
setTile (5, 3, 4, 0); 
setTile (5, 3, 5, 0); 
setTile (7, 3, 7, 173); 
setTile (7, 3, 1, 173); 
setTile (1, 3, 7, 173); 
setTile (7, 3, 2, 173); 
setTile (2, 3, 7, 173); 
setTile (3, 3, 7, 173); 
setTile (7, 3, 3, 173); 
setTile (4, 3, 7, 173); 
setTile (7, 3, 4, 173); 
setTile (5, 3, 7, 173); 
setTile (7, 3, 5, 173); 
setTile (6, 3, 7, 173); 
setTile (7, 3, 6, 173); 
setTile (6, 3, 5, 0); 
setTile (5, 3, 6, 0); 
setTile (4, 3, 6, 0); 
setTile (6, 3, 4, 0); 
setTile (3, 3, 6, 0); 
setTile (6, 3, 3, 0); 
setTile (6, 3, 2, 0); 
setTile (2, 3, 6, 0); 
setTile (1, 3, 6, 173); 
setTile (6, 3, 1, 173); 
setTile (6, 3, 6, 0); 
setTile (1, 4, 1, 173); 
setTile (1, 4, 2, 173); 
setTile (2, 4, 1, 173); 
setTile (2, 4, 2, 0); 
setTile (3, 4, 1, 173); 
setTile (1, 4, 3, 173); 
setTile (2, 4, 3, 0); 
setTile (3, 4, 2, 0); 
setTile (3, 4, 3, 0); 
setTile (4, 4, 1, 173); 
setTile (1, 4, 4, 173); 
setTile (2, 4, 4, 0); 
setTile (4, 4, 2, 0); 
setTile (3, 4, 4, 0); 
setTile (4, 4, 3, 0); 
setTile (4, 4, 4, 0); 
setTile (5, 4, 1, 173); 
setTile (1, 4, 5, 173); 
setTile (2, 4, 5, 0); 
setTile (5, 4, 2, 0); 
setTile (3, 4, 5, 0); 
setTile (5, 4, 3, 0); 
setTile (4, 4, 5, 0); 
setTile (5, 4, 4, 0); 
setTile (5, 4, 5, 0); 
setTile (7, 4, 7, 173); 
setTile (7, 4, 1, 173); 
setTile (1, 4, 7, 173); 
setTile (7, 4, 2, 173); 
setTile (2, 4, 7, 173); 
setTile (3, 4, 7, 173); 
setTile (7, 4, 3, 173); 
setTile (4, 4, 7, 173); 
setTile (7, 4, 4, 173); 
setTile (5, 4, 7, 173); 
setTile (7, 4, 5, 173); 
setTile (6, 4, 7, 173); 
setTile (7, 4, 6, 173); 
setTile (6, 4, 5, 0); 
setTile (5, 4, 6, 0); 
setTile (4, 4, 6, 0); 
setTile (6, 4, 4, 0); 
setTile (3, 4, 6, 0); 
setTile (6, 4, 3, 0); 
setTile (6, 4, 2, 0); 
setTile (2, 4, 6, 0); 
setTile (1, 4, 6, 173); 
setTile (6, 4, 1, 173); 
setTile (6, 4, 6, 0); 
setTile (1, 5, 1, 173); 
setTile (1, 5, 2, 173); 
setTile (2, 5, 1, 173); 
setTile (2, 5, 2, 0); 
setTile (3, 5, 1, 173); 
setTile (1, 5, 3, 173); 
setTile (2, 5, 3, 0); 
setTile (3, 5, 2, 0); 
setTile (3, 5, 3, 0); 
setTile (4, 5, 1, 173); 
setTile (1, 5, 4, 173); 
setTile (2, 5, 4, 0); 
setTile (4, 5, 2, 0); 
setTile (3, 5, 4, 0); 
setTile (4, 5, 3, 0); 
setTile (4, 5, 4, 0); 
setTile (5, 5, 1, 173); 
setTile (1, 5, 5, 173); 
setTile (2, 5, 5, 0); 
setTile (5, 5, 2, 0); 
setTile (3, 5, 5, 0); 
setTile (5, 5, 3, 0); 
setTile (4, 5, 5, 0); 
setTile (5, 5, 4, 0); 
setTile (5, 5, 5, 0); 
setTile (7, 5, 7, 173); 
setTile (7, 5, 1, 173); 
setTile (1, 5, 7, 173); 
setTile (7, 5, 2, 173); 
setTile (2, 5, 7, 173); 
setTile (3, 5, 7, 173); 
setTile (7, 5, 3, 173); 
setTile (4, 5, 7, 173); 
setTile (7, 5, 4, 173); 
setTile (5, 5, 7, 173); 
setTile (7, 5, 5, 173); 
setTile (6, 5, 7, 173); 
setTile (7, 5, 6, 173); 
setTile (6, 5, 5, 0); 
setTile (5, 5, 6, 0); 
setTile (4, 5, 6, 0); 
setTile (6, 5, 4, 0); 
setTile (3, 5, 6, 0); 
setTile (6, 5, 3, 0); 
setTile (6, 5, 2, 0); 
setTile (2, 5, 6, 0); 
setTile (1, 5, 6, 173); 
setTile (6, 5, 1, 173); 
setTile (6, 5, 6, 173);
setTile (1, 6, 1, 173); 
setTile (1, 6, 2, 173); 
setTile (2, 6, 1, 173); 
setTile (2, 6, 2, 173); 
setTile (3, 6, 1, 173); 
setTile (1, 6, 3, 173); 
setTile (2, 6, 3, 173); 
setTile (3, 6, 2, 173); 
setTile (3, 6, 3, 173); 
setTile (4, 6, 1, 173); 
setTile (1, 6, 4, 173); 
setTile (2, 6, 4, 173); 
setTile (4, 6, 2, 173); 
setTile (3, 6, 4, 173); 
setTile (4, 6, 3, 173); 
setTile (4, 6, 4, 173); 
setTile (5, 6, 1, 173); 
setTile (1, 6, 5, 173); 
setTile (2, 6, 5, 173); 
setTile (5, 6, 2, 173); 
setTile (3, 6, 5, 173); 
setTile (5, 6, 3, 173); 
setTile (4, 6, 5, 173); 
setTile (5, 6, 4, 173); 
setTile (5, 6, 5, 173); 
setTile (7, 6, 7, 173); 
setTile (7, 6, 1, 173); 
setTile (1, 6, 7, 173); 
setTile (7, 6, 2, 173); 
setTile (2, 6, 7, 173); 
setTile (3, 6, 7, 173); 
setTile (7, 6, 3, 173); 
setTile (4, 6, 7, 173); 
setTile (7, 6, 4, 173); 
setTile (5, 6, 7, 173); 
setTile (7, 6, 5, 173); 
setTile (6, 6, 7, 173); 
setTile (7, 6, 6, 173); 
setTile (6, 6, 5, 173); 
setTile (5, 6, 6, 173); 
setTile (4, 6, 6, 173); 
setTile (6, 6, 4, 173); 
setTile (3, 6, 6, 173); 
setTile (6, 6, 3, 173); 
setTile (6, 6, 2, 173); 
setTile (2, 6, 6, 173); 
setTile (1, 6, 6, 173); 
setTile (6, 6, 1, 173); 
setTile (6, 6, 6, 173); 
setPosition(getPlayerEnt(), 5, 4, 5); 
room = 1; 
setTile(3, 2, 2, 245);
setTile(4, 2, 2, 58);
setTile(5, 2, 2, 47);
setTile(0, 0, 0, 54);
setTile(0, 1, 0, 0);
setTile(1, 0, 0, 0);
setTile(0, 0, 1, 0);
setTile(1, 1, 0, 0);
setTile(0, 1, 1, 0);
addItemInventory(50,4);
addItemInventory(339,35);
addItemInventory(340,5);
addItemInventory(264,1);
addItemInventory(260,1);
clientMessage("*Coal Room*");
return;
}
if(itemId == 375 && blockId == 64 && getTile(x,y+2,z) == 173 && getTile(x,y-1,z) == 173 && prime == true && Vampire == 2 && Player.getCarriedItemCount()<64)
{
     prime = false;
     addItemInventory(375,-1);
     addItemInventory(473,1);
     preventDefault();
Px = getPlayerX(); 
Py = getPlayerY(); 
Pz = getPlayerZ(); 
setTile (1, 1, 1, 173); 
setTile (1, 1, 2, 173); 
setTile (2, 1, 1, 173); 
setTile (2, 1, 2, 173); 
setTile (3, 1, 1, 173); 
setTile (1, 1, 3, 173); 
setTile (2, 1, 3, 173); 
setTile (3, 1, 2, 173); 
setTile (3, 1, 3, 173); 
setTile (4, 1, 1, 173); 
setTile (1, 1, 4, 173); 
setTile (2, 1, 4, 173); 
setTile (4, 1, 2, 173); 
setTile (3, 1, 4, 173); 
setTile (4, 1, 3, 173); 
setTile (4, 1, 4, 173); 
setTile (5, 1, 1, 173); 
setTile (1, 1, 5, 173); 
setTile (2, 1, 5, 173); 
setTile (5, 1, 2, 173); 
setTile (3, 1, 5, 173); 
setTile (5, 1, 3, 173); 
setTile (4, 1, 5, 173); 
setTile (5, 1, 4, 173); 
setTile (5, 1, 5, 173); 
setTile (7, 1, 7, 173); 
setTile (7, 1, 1, 173); 
setTile (1, 1, 7, 173); 
setTile (7, 1, 2, 173); 
setTile (2, 1, 7, 173); 
setTile (3, 1, 7, 173); 
setTile (7, 1, 3, 173); 
setTile (4, 1, 7, 173); 
setTile (7, 1, 4, 173); 
setTile (5, 1, 7, 173); 
setTile (7, 1, 5, 173); 
setTile (6, 1, 7, 173); 
setTile (7, 1, 6, 173); 
setTile (6, 1, 5, 173); 
setTile (5, 1, 6, 173); 
setTile (4, 1, 6, 173); 
setTile (6, 1, 4, 173); 
setTile (3, 1, 6, 173); 
setTile (6, 1, 3, 173); 
setTile (6, 1, 2, 173); 
setTile (2, 1, 6, 173); 
setTile (1, 1, 6, 173); 
setTile (6, 1, 1, 173); 
setTile (6, 1, 6, 173); 
setTile (1, 2, 1, 173); 
setTile (1, 2, 2, 173); 
setTile (2, 2, 1, 173); 
setTile (2, 2, 2, 0); 
setTile (3, 2, 1, 173); 
setTile (1, 2, 3, 173); 
setTile (2, 2, 3, 0); 
setTile (3, 2, 2, 0); 
setTile (3, 2, 3, 0); 
setTile (4, 2, 1, 173); 
setTile (1, 2, 4, 173); 
setTile (2, 2, 4, 0); 
setTile (3, 2, 4, 0); 
setTile (4, 2, 3, 0); 
setTile (4, 2, 4, 0); 
setTile (5, 2, 1, 173); 
setTile (1, 2, 5, 173); 
setTile (2, 2, 5, 0); 
setTile (5, 2, 2, 0); 
setTile (3, 2, 5, 0); 
setTile (5, 2, 3, 0); 
setTile (4, 2, 5, 0); 
setTile (5, 2, 4, 0); 
setTile (5, 2, 5, 0); 
setTile (7, 2, 7, 173); 
setTile (7, 2, 1, 173); 
setTile (1, 2, 7, 173); 
setTile (7, 2, 2, 173); 
setTile (2, 2, 7, 173); 
setTile (3, 2, 7, 173); 
setTile (7, 2, 3, 173); 
setTile (4, 2, 7, 173); 
setTile (7, 2, 4, 173); 
setTile (5, 2, 7, 173); 
setTile (7, 2, 5, 173); 
setTile (6, 2, 7, 173); 
setTile (7, 2, 6, 173); 
setTile (6, 2, 5, 0); 
setTile (5, 2, 6, 0); 
setTile (4, 2, 6, 0); 
setTile (6, 2, 4, 0); 
setTile (3, 2, 6, 0); 
setTile (6, 2, 3, 0); 
setTile (6, 2, 2, 0); 
setTile (2, 2, 6, 0); 
setTile (1, 2, 6, 173); 
setTile (6, 2, 1, 173); 
setTile (6, 2, 6, 0); 
setTile (1, 3, 1, 173); 
setTile (1, 3, 2, 173); 
setTile (2, 3, 1, 173); 
setTile (2, 3, 2, 0); 
setTile (3, 3, 1, 173); 
setTile (1, 3, 3, 173); 
setTile (2, 3, 3, 0); 
setTile (3, 3, 2, 0); 
setTile (3, 3, 3, 0); 
setTile (4, 3, 1, 173); 
setTile (1, 3, 4, 173); 
setTile (2, 3, 4, 0); 
setTile (4, 3, 2, 0); 
setTile (3, 3, 4, 0); 
setTile (4, 3, 3, 0); 
setTile (4, 3, 4, 0); 
setTile (5, 3, 1, 173); 
setTile (1, 3, 5, 173); 
setTile (2, 3, 5, 0); 
setTile (5, 3, 2, 0); 
setTile (3, 3, 5, 0); 
setTile (5, 3, 3, 0); 
setTile (4, 3, 5, 0); 
setTile (5, 3, 4, 0); 
setTile (5, 3, 5, 0); 
setTile (7, 3, 7, 173); 
setTile (7, 3, 1, 173); 
setTile (1, 3, 7, 173); 
setTile (7, 3, 2, 173); 
setTile (2, 3, 7, 173); 
setTile (3, 3, 7, 173); 
setTile (7, 3, 3, 173); 
setTile (4, 3, 7, 173); 
setTile (7, 3, 4, 173); 
setTile (5, 3, 7, 173); 
setTile (7, 3, 5, 173); 
setTile (6, 3, 7, 173); 
setTile (7, 3, 6, 173); 
setTile (6, 3, 5, 0); 
setTile (5, 3, 6, 0); 
setTile (4, 3, 6, 0); 
setTile (6, 3, 4, 0); 
setTile (3, 3, 6, 0); 
setTile (6, 3, 3, 0); 
setTile (6, 3, 2, 0); 
setTile (2, 3, 6, 0); 
setTile (1, 3, 6, 173); 
setTile (6, 3, 1, 173); 
setTile (6, 3, 6, 0); 
setTile (1, 4, 1, 173); 
setTile (1, 4, 2, 173); 
setTile (2, 4, 1, 173); 
setTile (2, 4, 2, 0); 
setTile (3, 4, 1, 173); 
setTile (1, 4, 3, 173); 
setTile (2, 4, 3, 0); 
setTile (3, 4, 2, 0); 
setTile (3, 4, 3, 0); 
setTile (4, 4, 1, 173); 
setTile (1, 4, 4, 173); 
setTile (2, 4, 4, 0); 
setTile (4, 4, 2, 0); 
setTile (3, 4, 4, 0); 
setTile (4, 4, 3, 0); 
setTile (4, 4, 4, 0); 
setTile (5, 4, 1, 173); 
setTile (1, 4, 5, 173); 
setTile (2, 4, 5, 0); 
setTile (5, 4, 2, 0); 
setTile (3, 4, 5, 0); 
setTile (5, 4, 3, 0); 
setTile (4, 4, 5, 0); 
setTile (5, 4, 4, 0); 
setTile (5, 4, 5, 0); 
setTile (7, 4, 7, 173); 
setTile (7, 4, 1, 173); 
setTile (1, 4, 7, 173); 
setTile (7, 4, 2, 173); 
setTile (2, 4, 7, 173); 
setTile (3, 4, 7, 173); 
setTile (7, 4, 3, 173); 
setTile (4, 4, 7, 173); 
setTile (7, 4, 4, 173); 
setTile (5, 4, 7, 173); 
setTile (7, 4, 5, 173); 
setTile (6, 4, 7, 173); 
setTile (7, 4, 6, 173); 
setTile (6, 4, 5, 0); 
setTile (5, 4, 6, 0); 
setTile (4, 4, 6, 0); 
setTile (6, 4, 4, 0); 
setTile (3, 4, 6, 0); 
setTile (6, 4, 3, 0); 
setTile (6, 4, 2, 0); 
setTile (2, 4, 6, 0); 
setTile (1, 4, 6, 173); 
setTile (6, 4, 1, 173); 
setTile (6, 4, 6, 0); 
setTile (1, 5, 1, 173); 
setTile (1, 5, 2, 173); 
setTile (2, 5, 1, 173); 
setTile (2, 5, 2, 0); 
setTile (3, 5, 1, 173); 
setTile (1, 5, 3, 173); 
setTile (2, 5, 3, 0); 
setTile (3, 5, 2, 0); 
setTile (3, 5, 3, 0); 
setTile (4, 5, 1, 173); 
setTile (1, 5, 4, 173); 
setTile (2, 5, 4, 0); 
setTile (4, 5, 2, 0); 
setTile (3, 5, 4, 0); 
setTile (4, 5, 3, 0); 
setTile (4, 5, 4, 0); 
setTile (5, 5, 1, 173); 
setTile (1, 5, 5, 173); 
setTile (2, 5, 5, 0); 
setTile (5, 5, 2, 0); 
setTile (3, 5, 5, 0); 
setTile (5, 5, 3, 0); 
setTile (4, 5, 5, 0); 
setTile (5, 5, 4, 0); 
setTile (5, 5, 5, 0); 
setTile (7, 5, 7, 173); 
setTile (7, 5, 1, 173); 
setTile (1, 5, 7, 173); 
setTile (7, 5, 2, 173); 
setTile (2, 5, 7, 173); 
setTile (3, 5, 7, 173); 
setTile (7, 5, 3, 173); 
setTile (4, 5, 7, 173); 
setTile (7, 5, 4, 173); 
setTile (5, 5, 7, 173); 
setTile (7, 5, 5, 173); 
setTile (6, 5, 7, 173); 
setTile (7, 5, 6, 173); 
setTile (6, 5, 5, 0); 
setTile (5, 5, 6, 0); 
setTile (4, 5, 6, 0); 
setTile (6, 5, 4, 0); 
setTile (3, 5, 6, 0); 
setTile (6, 5, 3, 0); 
setTile (6, 5, 2, 0); 
setTile (2, 5, 6, 0); 
setTile (1, 5, 6, 173); 
setTile (6, 5, 1, 173); 
setTile (6, 5, 6, 173);
setTile (1, 6, 1, 173); 
setTile (1, 6, 2, 173); 
setTile (2, 6, 1, 173); 
setTile (2, 6, 2, 173); 
setTile (3, 6, 1, 173); 
setTile (1, 6, 3, 173); 
setTile (2, 6, 3, 173); 
setTile (3, 6, 2, 173); 
setTile (3, 6, 3, 173); 
setTile (4, 6, 1, 173); 
setTile (1, 6, 4, 173); 
setTile (2, 6, 4, 173); 
setTile (4, 6, 2, 173); 
setTile (3, 6, 4, 173); 
setTile (4, 6, 3, 173); 
setTile (4, 6, 4, 173); 
setTile (5, 6, 1, 173); 
setTile (1, 6, 5, 173); 
setTile (2, 6, 5, 173); 
setTile (5, 6, 2, 173); 
setTile (3, 6, 5, 173); 
setTile (5, 6, 3, 173); 
setTile (4, 6, 5, 173); 
setTile (5, 6, 4, 173); 
setTile (5, 6, 5, 173); 
setTile (7, 6, 7, 173); 
setTile (7, 6, 1, 173); 
setTile (1, 6, 7, 173); 
setTile (7, 6, 2, 173); 
setTile (2, 6, 7, 173); 
setTile (3, 6, 7, 173); 
setTile (7, 6, 3, 173); 
setTile (4, 6, 7, 173); 
setTile (7, 6, 4, 173); 
setTile (5, 6, 7, 173); 
setTile (7, 6, 5, 173); 
setTile (6, 6, 7, 173); 
setTile (7, 6, 6, 173); 
setTile (6, 6, 5, 173); 
setTile (5, 6, 6, 173); 
setTile (4, 6, 6, 173); 
setTile (6, 6, 4, 173); 
setTile (3, 6, 6, 173); 
setTile (6, 6, 3, 173); 
setTile (6, 6, 2, 173); 
setTile (2, 6, 6, 173); 
setTile (1, 6, 6, 173); 
setTile (6, 6, 1, 173); 
setTile (6, 6, 6, 173); 
setPosition(getPlayerEnt(), 5, 4, 5); 
room = 1; 
setTile(3, 2, 2, 245);
setTile(4, 2, 2, 58);
setTile(5, 2, 2, 47);
setTile(0, 0, 0, 54);
setTile(0, 1, 0, 0);
setTile(1, 0, 0, 0);
setTile(0, 0, 1, 0);
setTile(1, 1, 0, 0);
setTile(0, 1, 1, 0);
addItemInventory(50,4);
addItemInventory(339,35);
addItemInventory(340,5);
addItemInventory(264,1);
addItemInventory(260,1);
clientMessage("*Coal Room*");
return;
}
if(itemId == 340 && blockId == 245 && room == 1)
{
preventDefault();
room = 0;
setPosition(getPlayerEnt(), Px, Py, Pz);
}
if(itemId == 473 && blockId == 245 && room == 1)
{
preventDefault();
room = 0;
setPosition(getPlayerEnt(), Px, Py, Pz);
clientMessage(ChatColor.BLACK + ".. .. .. Akhkharu .. .. ..");
soul--;
}
if(itemId == 276 && blockId == 69 && rsc > 4 && shelf < 1450 && Vampire == 2)
{
preventDefault();
Player.setHealth(feedtab - 1);
rsc = 1;
clientMessage(ChatColor.RED + "Blood -" + rsc);
}
if(itemId == 276 && blockId == 69 && rsc < 4 && shelf < 1450 && Vampire== 2)
{
preventDefault();
Player.setHealth(feedtab - 1);
rsc++;
clientMessage(ChatColor.RED + "Blood -" + rsc);
}
if(itemId == 276 && blockId == 69 && rsc == 4 && shelf < 1450 && Vampire== 2)
{
preventDefault();
rsc = 0;
shelf++;
clientMessage(ChatColor.BLUE + "IQ+:" + shelf);
if(shelf==400)
{
clientMessage("Botany Mastered");
}
if(shelf==500)
{
clientMessage("Obtained Ability : Riding the Wind");
}
if(shelf==600)
{
clientMessage("Learned Observer Platforms and Teleporter Compass");
}
if(shelf==700)
{
clientMessage("Learned Alchemy");
}
if(shelf==800)
{
clientMessage("Obtained Ability : Mind Reader");
}
if(shelf==900)
{
clientMessage(" you opened a rift into another dimension, tap a mob with a glass block to trap them there......");
}
if(shelf==1000)
{
clientMessage("Vampiric Maturity Reached!");
soul--;
}
if(shelf==1100)
{
clientMessage("... you hear snorting from below you . ...  ..  ..");
}
if(shelf==1200)
{
clientMessage("Learned Harden");
}
if(shelf==1300)
{
clientMessage("Learned Necromancy");
}
if(shelf==1400)
{
clientMessage("Learned Focus");
}
}

if(itemId == 295 && blockId == 2 && shelf > 49 && Player.getCarriedItemCount()<64)
{
addItemInventory(295,-1);
setTile(x,y+1,z,31,1);
}
if(itemId == 345 && blockId == 20 && shelf > 599 && Vampire == 2 && Player.getCarriedItemCount()<64)
{
setTile(x, y, z,95);
setTile(x+1, y, z,95);
setTile(x-1, y, z,95);
setTile(x, y, z+1,95);
setTile(x, y, z-1,95);
setTile(x+1, y, z+1,95);
setTile(x+1, y, z-1,95);
setTile(x-1, y, z+1,95);
setTile(x-1, y, z-1,95);
addItemInventory(345,-1);
clientMessage("Observer Initiated");
}
if(blockId ==  20 && shelf > 899)
{
  var Tx = getPlayerX(); 
  var Ty = getPlayerY(); 
  var Tz = getPlayerZ();
  if(trap == 1)
  {
     Level.spawnMob(Tx+1,Ty,Tz,gb1);
     trap = 0;
     gb1 = 0;
  }
  else if(trap == 2)
  {
     Level.spawnMob(Tx+1,Ty,Tz,gb1);
     Level.spawnMob(Tx-1,Ty,Tz,gb2);
     trap = 0;
     gb1 = 0;
     gb2 = 0;
  }
  else if(trap == 3)
  {
     Level.spawnMob(Tx+1,Ty,Tz,gb1);
     Level.spawnMob(Tx-1,Ty,Tz,gb2);
     Level.spawnMob(Tx,Ty,Tz+1,gb3);
     trap = 0;
     gb1 = 0;
     gb2 = 0;
     gb3 = 0;
  }
  else if(trap == 4)
  {
     Level.spawnMob(Tx+1,Ty,Tz,gb1);
     Level.spawnMob(Tx-1,Ty,Tz,gb2);
     Level.spawnMob(Tx,Ty,Tz+1,gb3);
     Level.spawnMob(Tx,Ty,Tz-1,gb4);
     trap = 0;
     gb1 = 0;
     gb2 = 0;
     gb3 = 0;
     gb4 = 0;
  }
  else if(trap == 5)
  {
     Level.spawnMob(Tx+1,Ty,Tz,gb1);
     Level.spawnMob(Tx-1,Ty,Tz,gb2);
     Level.spawnMob(Tx,Ty,Tz+1,gb3);
     Level.spawnMob(Tx,Ty,Tz-1,gb4);
     Level.spawnMob(Tx,Ty,Tz,gb5);
     trap = 0;
     gb1 = 0;
     gb2 = 0;
     gb3 = 0;
     gb4 = 0;
     gb5 = 0;
  }
}
if(itemId == 295 && blockId == 69 && Player.getCarriedItemCount()<64)
{
preventDefault();
clientMessage(ChatColor.GREEN + "Sprouts Started");
addItemInventory(295,-1);
  if(shelf > 99)
  {
     addItemInventory(37,1);
  }
  if(shelf > 199)
  {
     addItemInventory(6,1);
  }
}
if(itemId == 37 && blockId == 4 && shelf > 299 && Player.getCarriedItemCount()<64)
{
   setTile(x,y,z,48);
   addItemInventory(37,-1);
}
if(itemId == 260 && blockId == 48 && shelf > 399 && Player.getCarriedItemCount()<64)
{
   setTile(x,y,z,0);
   addItemInventory(260,-1);
   Level.dropItem(x, y, z, 1, 361, 1, 0);
   Level.dropItem(x, y, z, 1, 361, 1, 0);
   Level.dropItem(x, y, z, 1, 361, 1, 0);
   Level.dropItem(x, y, z, 1, 361, 1, 0);
}
   

if(itemId == 58 && blockId == 47 && Player.getCarriedItemCount()<64)
{
   setTile(x,y,z,0);
   addItemInventory(58,-1);
   addItemInventory(69,1);
} 
   
// Mining Wand® Kioni

if(itemId==280&&blockId==173)//If your item is a Magic Wand, and the block your using it on is Coal Block
        {
                Level.destroyBlock(x, y, z, 173);
        }
if(itemId==280&&blockId==170)//If your item is a Magic Wand, and the block your using it on is Hay Bail
        {
                Level.destroyBlock(x, y, z, 170);
        }
if(itemId==280&&blockId==58)//If your item is a Magic Wand, and the block your using it on is Crafting Table
        {
                Level.destroyBlock(x, y, z, 58);
        }
if(itemId==280&&blockId==245)//If your item is a Magic Wand, and the block your using it on is Stonecutter
        {
                Level.destroyBlock(x, y, z, 245);
        }
if(itemId==280&&blockId==61)//If your item is a Magic Wand, and the block your using it on is a Furnace
        {
                Level.destroyBlock(x, y, z, 61);
        }
if(itemId==280&&blockId==69)//If your item is a Magic Wand, and the block your using it on is a Research Table.
        {
                Level.destroyBlock(x, y, z, 69);
        }
if(itemId==280&&blockId==70)//If your item is a Magic Wand, and the block your using it on is Mort's Shop.
        {
                Level.destroyBlock(x, y, z, 70);
        }
if(itemId==280&&blockId==47)//If your item is a Magic Wand, and the block your using it on is a Bookshelf
        {
                setTile(x,y,z,0);
                clientMessage("**Blessings**");
                addItemInventory(347,1);
                addItemInventory(339,5);
                addItemInventory(340,2);
                addItemInventory(40,5);
                addItemInventory(39,5);
        }
if(itemId==280&&blockId==89)
{  
     if(mine==0)
     { 
         mine = 1;
         clientMessage("Mining Wand Active");
     }
     else if(mine==1)
     {
          mine = 0;
          clientMessage("Mining Wand Off");
     }
}
    if(mine==1)
    {
        if(itemId==280&&blockId==59)
             {
                  setTile(x,y,z,0);
                  setTile(x,y-1,z,60);
                  addItemInventory(296,3);
                  addItemInventory(295,2);
                  addItemInventory(458,2);
             }
        if(itemId==280&&blockId==2)//If your item is a Magic Wand, and the block your using it on is grass
        {
                setTile(x,y,z,0);
        }
        else if(itemId==280&&blockId==3)//If the block we are using is dirt
        {
                setTile(x,y,z,0);
        }
        else if(itemId==280&&blockId==1)//If the block we are using is stone
        {
                setTile(x,y,z,0);
        }
        else if(itemId==280&&blockId==13)//If the block we are using is gravel
        {
                Level.destroyBlock(x, y, z, 318);
        }
        else if(itemId==280&&blockId==16)//If the block we are using is coal ore
        {
                setTile(x,y,z,0);
                addItemInventory(263,3);
        }
        else if(itemId==280&&blockId==15)//If the block we are using is iron ore
        {
                Level.destroyBlock(x, y, z, 15);
                cash++;
        }
        else if(itemId==280&&blockId==21)//If the block we are using is lapis ore
        {
                Level.destroyBlock(x, y, z, 21);
                cash++;
        }
        else if(itemId==280&&blockId==14)//If the block we are using is gold ore
        {
                Level.destroyBlock(x, y, z, 14);
                cash++;
        }
        else if(itemId==280&&blockId==56)//If the block we are using is diamond ore
        {
                Level.destroyBlock(x, y, z, 56);
                cash++;
        }
        else if(itemId==280&&blockId==73)//If the block we are using is redstone ore
        {
                Level.destroyBlock(x, y, z, 73);
                addItemInventory(331,3);
                addItemInventory(246,1);
                cash++;
        }
        else if(itemId==280&&blockId==74)//If the block we are using is redstone ore
        {
                Level.destroyBlock(x, y, z, 73);
                addItemInventory(331,3);
                addItemInventory(246,3);
                cash++;
        }
        if(itemId==280&&blockId==78)//If your item is a Magic Wand, and the block your using it on is snow
        {
                Level.destroyBlock(x, y, z, 332);
        }
        if(itemId==280&&blockId==80)//If your item is a Magic Wand, and the block your using it on is Snow Block
        {
                setTile(x,y,z,79);
        }
        if(itemId==280&&blockId==129)//If your item is a Magic Wand, and the block your using it on is Emerald Ore
        {
                Level.destroyBlock(x, y, z, 129);
        }
        if(itemId==280&&blockId==12)//If your item is a Magic Wand, and the block your using it on is sand
        {
                Level.destroyBlock(x, y, z, 20);
                cash++;
        }
        if(itemId==280&&blockId==20)//If your item is a Magic Wand, and the block your using it on is glass
        {
                Level.destroyBlock(x, y, z, 406);
                cash++;
        }
        if(itemId==280&&blockId==7)//If your item is a Magic Wand, and the block your using it on is bedrock
        {
                addItemInventory(87,1);
        }
        if(itemId==280&&blockId==17)//If your item is a wand
   {
      setTile(x,y,z,0);
      addItemInventory(17,1);
      for(var a = 1; a < 10; a++)
      {
        if(getTile(x,y+a,z) == 17)
        {
          setTile(x,y+a,z,0);
          addItemInventory(17,1);
        }
        else {break;}
      }
      preventDefault();
    }
}

//Kioni's Mixture Craft®

if(itemId == 359 && blockId == 173 && getTile(x,y+1,z) == 51)
{
setTile(x, y, z, 0);
setTile(x, y+1, z, 0);
addItemInventory(385,1);
}
if(itemId==289&&blockId==12&&getTile(x,y+1,z)==9 && Player.getCarriedItemCount()<64)//If your item is gunpowder, and the block your using it on is sand in water
        {
                preventDefault();
                setTile(x,y,z,82);
                addItemInventory(289,-1);
        }
if(itemId==348&&blockId==82&&getTile(x,y+1,z)==9 && Player.getCarriedItemCount()<64)//If your item is glowstone powder, and the block your using it on is clay in water
        {
                preventDefault();
                setTile(x,y,z,0);
                addItemInventory(474,2);
                addItemInventory(348,-1);
        }
if(itemId==318&&blockId==13 && Player.getCarriedItemCount()<64)//If your item is a flint, and the block your using it on is gravel
        {
                setTile(x,y,z,0);
                addItemInventory(318,-1);
                addItemInventory(289,1);
                clientMessage(ChatColor.BLACK + "GP+");
        }
        if(itemId==289&&blockId==245 && Player.getCarriedItemCount()<64)//If your item is a pile of gunpowder, and the block your using it on is a StoneCutter
        {
                preventDefault();
                addItemInventory(348,1);
                addItemInventory(289,-1);
                clientMessage(ChatColor.BLACK + "GS+");
        }
if(itemId==406&&blockId==20&&getTile(x,y-1,z)==51 && Player.getCarriedItemCount()<64)//If your item is a Nether Quartz, and the block your using it on is glass over a fire
        {
                setTile(x,y,z,0);
                addItemInventory(264,1);
                addItemInventory(406,-1);
                clientMessage(ChatColor.BLUE + "Glass Melt- created Diamond**");
        }
if(itemId==288&&blockId==20&&getTile(x,y-1,z)==51)//If your item is a Feather, and the block your using it on is glass over a fire
        {
                setTile(x,y,z,0);
                addItemInventory(471,6);
                clientMessage(ChatColor.BLUE + "Swirled Up Some Vials");
        }
if(itemId==264&&blockId==42&&shelf > 699 && Player.getCarriedItemCount()<64)//If your item is a Diamond, and the block your using it on is iron block
        {
                setTile(x,y,z,0);
                addItemInventory(264,-1);
                addItemInventory(266,8);
                clientMessage(ChatColor.BLUE + "Transmutation Success!!");
        }
if(itemId==385&&blockId==173 && Player.getCarriedItemCount()<64)
        {
                 addItemInventory(385,-1);
                 setTile(x, y, z, 10);
        }
if(itemId==265 && shelf > 1199 && Vampire== 2 && Player.getCarriedItemCount()<64)
{
     preventDefault();
     addItemInventory(265,-1);
     setTile(x, y, z, 7);
}

//End Mixture Craft.

if(itemId==472 && Player.getCarriedItemCount()<64)
{
var feedbot = Entity.getHealth(getPlayerEnt());

     if(Vampire == 2 && feedbot < 40)
     {
         Player.setHealth(feedbot + 10);
         addItemInventory(472, -1);
     }
}

	if(itemId==280)
 {
		if(blockId==42)
		{
			if(rocket == 0)
			{
				grav = 0;
				tp = 0;
				rocket = 1;
				exp = 0;
              	chopper = 0;
				clientMessage("wand power changed to Leviosa");
			}
			else
			if(rocket == 1)
			{
				rocket = 0;
				clientMessage("Enchantment Leviosa removed from wand");
			}
		}
		else
		if(blockId==41)
		{
			if(tp == 0)
			{
				grav = 0;
				rocket = 0;
				tp = 1;
				exp = 0;
              	chopper = 0;
				clientMessage("wand power changed to Fira");
			}
			else
			if(tp == 1)
			{
				tp = 0;
				clientMessage("Enchantment Fira removed from wand");
			}
		}
   		else
		if(blockId==45)
		{
			if(chopper == 0)
			{
				grav = 0;
				rocket = 0;
				tp = 0;
				exp = 0;
              	chopper = 1;
				clientMessage("wand power changed to Loggsman");
			}
			else
			if(chopper == 1)
			{
				chopper = 0;
				clientMessage("Enchantment Loggsman removed from wand");
			}
		}
		else
		if(blockId==246)
		{
			if(grav == 0)
			{
				rocket = 0;
				tp = 0;
				grav = 1;
				exp = 0;
              	chopper = 0;
				clientMessage("wand power changed to Avada Kadava.");
			}
			else
			if(grav == 1)
			{
				grav = 0;
				clientMessage("Enchantment Avada Kadava removed from wand");
			}
		}
		else
		if(blockId==46)
		{
			if(mine == 0 && exp == 0)
			{
				grav = 0;
				rocket = 0;
				tp = 0;
				exp = 1;
              	chopper = 0;
				clientMessage("wand power changed to Incindio");
			}
			else
			if(mine == 0 && exp == 1)
			{
				exp = 0;
				clientMessage("Enchantment Incindio removed from wand");
			}
		}
		else
		if(blockId==53)
		{
			if(mine == 0 && ride == 0 && exp == 0)
			{
				grav = 0;
				rocket = 0;
				tp = 0;
				exp = 0;
				ride = 1;
              	chopper = 0;
				clientMessage("wand power changed to Raido");
			}
			else
			if(mine == 0 && ride == 1 && exp == 0)
			{
				ride = 0;
				clientMessage("Enchantment Raido removed from wand");
			}
		}
 	else
		if(blockId==49)
		{
			grav = 0;
			tp = 0;
			rocket = 0;
			exp = 0;
          	chopper = 0;
          	ride = 0;
           mine = 0;
			clientMessage(ChatColor.YELLOW + "All powers removed from wand"); 
		}
 	else
		if(exp == 1 && ride == 0)
      {
		explode(x,y,z,3.0);
      }
      else
		if(tp== 1)
      {
		setTile(x,y+1,z,51);
      }
  else
    if(chopper ==1 && blockId == 17)
{
setTile(x,y,z,0);
addItemInventory(17,1);
for(var a = 1; a < 10; a++)
{
if(getTile(x,y+a,z) == 17)
{
setTile(x,y+a,z,0);
addItemInventory(17,1);
}
else {break;}
}
preventDefault();
}
}
if (itemId == 260 && blockId == 246 && Player.getCarriedItemCount()<64) 
{ 
preventDefault();
addItemInventory(260,-1);
var apple = Math.floor((Math.random()*6)+1);
if(apple == 3) {
clientMessage(ChatColor.RED + "You Feel Bloody...");
Vampire = 2;
check = 2;
soul--;
}
}

if (blockId == 246 && getTile(x,y+1,z) == 51 && Vampire == 2) 
{ 
preventDefault();
clientMessage(ChatColor.BLUE + "the blood has been cleansed...");
Vampire = 1;
soul--;
if(pig== true)
          {
          Entity.setRenderType(Player.getEntity(), 3);
          Entity.setMobSkin(Player.getEntity(), "mob/char.png");
          pig = false;
          }
}

if (soul == 9000) 
{
clientMessage("Something feels icky...");
cur9 = 1; 
soul--;
}
if (soul == 8000) 
{
clientMessage("I feel worthy....");
cur9 = 0;
cur8 = 1;
soul--;
}
if (soul == 7000) 
{
clientMessage("...");
cur8 = 0;
cur7 = 1;
soul--;
}
if (soul == 6000) 
{
clientMessage("... . .. ");
cur7 = 0;
cur6 = 1;
soul--;
}
if (soul == 5000) 
{
clientMessage(ChatColor.BLUE + " you hear a whisper, ......." + ChatColor.BLACK + "nichtoe" + ChatColor.BLUE + ".... . . .");
cur6 = 0;
cur5 = 1;
soul--;
}
if (soul == 4000) 
{
clientMessage(ChatColor.RED + "AAÀAAAAAAÀÅAAAAaaaaAaaahhhhhhhhghggjhhghhgggg!!!!!");
cur5 = 0;
cur4 = 1;
soul--;
}
if (soul == 3000) 
{
clientMessage(ChatColor.GREEN + " you are really starting to feel messed up...");
cur4 = 0;
cur3 = 1;
soul--;
}
if (soul == 2000) 
{
clientMessage(ChatColor.BLUE + " this is getting aa llot woor sse.... .   . ..");
cur3 = 0;
cur2 = 1;
soul--;
}
if (soul == 1000) 
{
clientMessage(ChatColor.BLACK + " feEl..l  sOo wRonG...  .. .");
cur2 = 0;
cur1 = 1;
soul--;
}
if (soul == 0) 
{
cur1 = 0;
cur0 = 1;
}
if (cur9 == 1)
{
var random9 = Math.floor((Math.random()*6)+1);
if(random9 == 3) {
Px = getPlayerX(); 
Py = getPlayerY(); 
Pz = getPlayerZ();
Level.dropItem(Px+1, Py, Pz, 1, 341, 1, 0);
Level.dropItem(Px-1, Py, Pz, 1, 341, 1, 0);
Level.dropItem(Px, Py, Pz+1, 1, 341, 1, 0);
Level.dropItem(Px, Py, Pz-1, 1, 341, 1, 0);
}
}
if (cur8 == 1)
{
var random8 = Math.floor((Math.random()*6)+1);
if(random8 == 3) {
setTile(x,y,z,41);
}
}
if (cur7 == 1)
{
var random7 = Math.floor((Math.random()*6)+1);
if(random7 == 3) {
setTile(x,y,z,0);
Level.dropItem(x, y, z, 1, 348, 1, 0);
}
}
if (cur6 == 1)
{
var random6 = Math.floor((Math.random()*6)+1);
if(random6 == 3) {
setTile(x,y,z,0);
Level.dropItem(x, y, z, 1, 331, 1, 0);
}
}
if (cur5 == 1)
{
var random5 = Math.floor((Math.random()*6)+1);
if(random5 == 3) {
setTile(x,y,z,0);
Level.dropItem(x, y, z, 1, 289, 1, 0);
}
}
if (cur4 == 1)
{
var random4 = Math.floor((Math.random()*6)+1);
if(random4 == 3) {
Level.spawnMob(x, y+1, z, 32);
}
}
if (cur3 == 1)
{
var random3 = Math.floor((Math.random()*6)+1);
if(random3 == 3) {
Level.spawnMob(x, y+1, z, 32);
Level.spawnMob(x, y+1, z, 32);
}
}
if (cur2 == 1)
{
var random2 = Math.floor((Math.random()*6)+1);
if(random2 == 3) {
Level.spawnMob(x, y+1, z, 35);
Level.spawnMob(x, y+1, z, 35);
Level.spawnMob(x, y+1, z, 35);
}
}
if (cur1 == 1)
{
var random1 = Math.floor((Math.random()*6)+1);
if(random1 == 3) {
Player.setHealth(4);
}
}
if (cur0 == 1)
{
var random0 = Math.floor((Math.random()*3)+1);
if(random0 == 3) {
setPosition(getPlayerEnt(), 0, 0, 0);
}
}
if(Player.getCarriedItemCount()>63)
{
clientMessage("NO FULL STACKS");
}
if(blockId== 69 && itemId== 367 && Player.getCarriedItemCount()<64 && shelf > 1299)
{
flesh++;
addItemInventory(367, -1);
clientMessage(ChatColor.RED + "Flesh Graphed");
}
if(blockId== 69 && Player.getCarriedItemCount()<64 && flesh > 2 && shelf > 1299)
{
if(itemId==289)
{
addItemInventory(289,-1);
Level.spawnMob(x, y+1, z, 33);
flesh = flesh -3;
}
if(itemId==288)
{
addItemInventory(288,-1);
Level.spawnMob(x, y+1, z, 32);
flesh = flesh -3;
}
if(itemId==352)
{
addItemInventory(352,-1);
Level.spawnMob(x, y+1, z, 34);
flesh = flesh -3;
}
if(itemId==375)
{
addItemInventory(375,-1);
Level.spawnMob(x, y+1, z, 35);
flesh = flesh -3;
}
if(itemId==344)
{
addItemInventory(344,-1);
Level.spawnMob(x, y+1, z, 10);
flesh = flesh -3;
}
if(itemId==35)
{
addItemInventory(35,-1);
Level.spawnMob(x, y+1, z, 13);
flesh = flesh -3;
}
if(itemId==319)
{
addItemInventory(319,-1);
Level.spawnMob(x, y+1, z, 12);
flesh = flesh -3;
}
if(itemId==334)
{
addItemInventory(334,-1);
Level.spawnMob(x, y+1, z, 11);
flesh = flesh -3;
}
}
if(itemId==475 && blockId==69 && flesh > 99)
{
possessed = 1;
flesh = flesh - 100;
clientMessage(ChatColor.BLACK + "Necronomicon Has Been Awakened");
}
if(itemId==475 && blockId!=69)
{
ALS = 1;
Pxs = getPlayerX(); 
Pys = getPlayerY(); 
Pzs = getPlayerZ();
Level.dropItem(Pxs+1, Pys, Pzs, 1, 341, 1, 0);
Level.dropItem(Pxs-1, Pys, Pzs, 1, 341, 1, 0);
Level.dropItem(Pxs, Pys, Pzs+1, 1, 341, 1, 0);
Level.dropItem(Pxs, Pys, Pzs-1, 1, 341, 1, 0);
if(possessed==1 && flesh > 1 && blockId!=87)
{
flesh = flesh - 2;
Level.spawnMob(x, y, z, 32);
}
if(possessed==1 && flesh > 199 && blockId==87)
{
var AX = x;
var AY = y;
var AZ = z;

flesh = flesh - 200;
var alice = Level.spawnMob(AX, AY, AZ, 35, "mob/alice.png");
Entity.setHealth(alice, 800);
Entity.setRenderType(alice, 3);
if(Entity.getHealth(getPlayerEnt())==40)
{
clientMessage(ChatColor.BLUE + "*50*");
soul = soul + 50;
}
}
}
if(focus == 1 && shelf > 1399)
{
ModPE.setGameSpeed(20);
focus = 0;
}
if(itemId == 347 && focus == 0 && shelf > 1399)
{
ModPE.setGameSpeed(5);
focus = 1;
}
if(itemId== 345 && blockId!= 20 && blockId == 69 && shelf > 599 && Vampire == 2)
{
TPX = getPlayerX();
TPY = getPlayerY();
TPZ = getPlayerZ();
Tel = 1;
clientMessage(ChatColor.YELLOW + "Home Set");
}
if(itemId== 345 && blockId!= 20 && blockId!= 69 && shelf > 599 && Vampire == 2 && Tel == 1)
{
setPosition(getPlayerEnt(), TPX, TPY, TPZ);
if(dream == 1)
{
dream = 0;
Player.setHealth(20);
setPosition(getPlayerEnt(), Px, Py, Pz);
Level.setTime(29388);
soul--;
clientMessage(ChatColor.RED + "....... . ..  .  ..  .. blood...");
}
}
if(itemId== 473 && blockId == 70 && shelf == 1450 && mistAb < 2 && Vampire == 2)
{
addItemInventory(473, -1);
mistAb = 2;
clientMessage(ChatColor.BLUE + "Mist Acquired");
}

if(itemId== 473 && mistAb == 2 && Vampire == 2 && blockId!= 70 && blockId!= 69 && mistcount== 8)
{
ModPE.saveData("mistX",parseInt(x));
			ModPE.saveData("mistY",parseInt(y));
			ModPE.saveData("mistY1",parseInt(y) - 1);
			ModPE.saveData("mistZ",parseInt(z));
mDoor = Level.getTile(ModPE.readData("mistX"),ModPE.readData("mistY"),ModPE.readData("mistZ"));
mDoor1 = Level.getTile(ModPE.readData("mistX"),ModPE.readData("mistY1"),ModPE.readData("mistZ"));
setTile(x, y, z, 9);
{

Level.destroyBlock(x, y, z, false)
}

setTile(x, y -1, z, 9);
{

Level.destroyBlock(x, y -1, z, false)
}

mist = 2;

var xxm = getPlayerX();
var yym = getPlayerY();
var zzm = getPlayerZ();

setTile(xxm, yym, zzm, 9);
{

Level.destroyBlock(xxm, yym, zzm, false)
}

}
}

function destroyBlock(x, y, z, blockId) 
{
if(getTile(x, y, z)== 30 && getCarriedItem()==276)
{
Level.dropItem(x, y, z, 1, 30, 1, 0);
Level.dropItem(x, y, z, 1, 30, 1, 0);
Level.spawnMob(x, y, z, 35);
}
if(dream == 1)	
{
dream = 0;
Player.setHealth(20);
setPosition(getPlayerEnt(), Px, Py, Pz);
Level.setTime(0);
soul--;
}


if(getCarriedItem()==276 && getTile(x, y, z) == 35 && Vampire == 2)
{
preventDefault();
setTile(x, y, z,0);
Level.dropItem(x, y, z, 1, 30, 1, 0);
Level.dropItem(x, y, z, 1, 30, 1, 0);
Level.dropItem(x, y, z, 1, 30, 1, 0);
Level.dropItem(x, y, z, 1, 30, 1, 0);
}
}

function modTick(x,y,z,blockId,blooddrink)
{

var chck = false;

if(Vampire == 2 && sunclock == 3)
{
for(var sy=Math.floor(Player.getY())+1;sy<=
128;sy++) {
chck=false;
if(sy==128) {
chck=true;
}
if(Level.getTile(Math.floor(Player.getX()),sy,Math.floor(Player.getZ()))!=0||Level.getTile(Math.floor(Player.getX()),Math.floor
(Player.getY())-1,Math.floor(Player.getZ()))==8 ||Level.getTile(Math.floor(Player.getX()),Math.floor(Player.getY())-1,Math.floor(Player.getZ() ))==9||Level.getTile(Math.floor(Player.getX()),Math.floor(Player.getY())-2,Math.floor (Player.getZ()))==8||Level.getTile(Math.floor (Player.getX()),Math.floor(Player.getY())-2,Math.floor(Player.getZ()))==9||pig==true||Level.getTime() >= 10412 && Level.getTime() <= 18843
||Level.getTime() >= 29388 && Level.getTime() <= 37615
||Level.getTime() >= 48569 && Level.getTime() <= 56738
||Level.getTime() >= 67832 && Level.getTime() <= 76109
||Level.getTime() >= 86988 && Level.getTime() <= 95490
||Level.getTime() >= 106057 && Level.getTime() <= 114657
||Level.getTime() >= 125414 && Level.getTime() <= 133638
||Level.getTime() >= 144549 && Level.getTime() <= 152629||sunblock==1) 
break;
else if(chck==true) {
      Entity.setFireTicks(getPlayerEnt(), 7);
      soul--;
  }
 }
}

if(Level.getTime() == 10412)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 29388)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 48569)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 67832)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 86988)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 106057)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 125414)
{
sunblock = 0;
soul--;
}

if(Level.getTime() == 144549)
{
sunblock = 0;
soul--;
}

if(Level.getTile(Math.floor(Player.getX()),Math.floor
(Player.getY())-1,Math.floor(Player.getZ()))==8 ||Level.getTile(Math.floor(Player.getX()),Math.floor(Player.getY())-1,Math.floor(Player.getZ() ))==9||Level.getTile(Math.floor(Player.getX()),Math.floor(Player.getY())-2,Math.floor (Player.getZ()))==8||Level.getTile(Math.floor (Player.getX()),Math.floor(Player.getY())-2,Math.floor(Player.getZ()))==9)
{
sunblock = 0;
}

if(Entity.getHealth(getPlayerEnt()) > 40)
{
Player.setHealth(40);
feedtic = 1;
}

if(regen == 1)
{

var health = Entity.getHealth(getPlayerEnt());
	
	if(health == 40) {
		regen = 0;
	}
	if(regen == 1) {
		countdown--;
	} else if(regen == 0) {
		countdown = 30;
	}
	if(countdown == 0) {
		Player.setHealth(health + 1);
		countdown = 30;
	}
}

if(Vampire == 2)
{

var pain = Entity.getHealth(getPlayerEnt());
	
	if(pain == 40) {
		hung = 0;
	}
   else if(pain < 40) {
		hung = 1;
	}
	if(hung == 1) {
		countdownh--;
	} else if(hung == 0 && shelf > 999) {
		countdownh = 600;
	} else if(hung == 0 && shelf < 1000) {
		 Player.setHealth(pain - 1);
	}
	if(countdownh == 0) {
		Player.setHealth(pain - 1);
		countdownh = 600;
	}
}

if(Vampire == 2)
{
sunclock--;
}

if(sunclock == 0)
{
sunclock = 120;
}

if(shelf > 499 && getCarriedItem() == 276 && Vampire == 2) {
		if(sprintTick == 1) {
			Xpos = Player.getX();
			Zpos = Player.getZ();
			sprintTick++;
		} if(sprintTick == 3) {
			sprintTick = 1;
			Xdiff = Player.getX() - Xpos;
			Zdiff = Player.getZ() - Zpos;
			Entity.setVelX(Player.getEntity(),Xdiff);
			Entity.setVelZ(Player.getEntity(),Zdiff);
			Xdiff = 0;
			Zdiff = 0;
		} if(sprintTick != 1) {
			sprintTick++;
		}
	}
else if(shelf > 499 && getCarriedItem() != 276 && Vampire == 2) {
sprintTick = 1;
}

if(mist == 2)
{
mistcount--;
}
if(mistcount == 0)
{
mistcount = 8;
mist = 1;
Level.setTile(ModPE.readData("mistX"),ModPE.readData("mistY"),ModPE.readData("mistZ"),mDoor);
				Level.setTile(ModPE.readData("mistX"),ModPE.readData("mistY1"),ModPE.readData("mistZ"),mDoor1);
}
}

function procCmd(cmd) {
   var command = cmd.split(" ");
   if(command[0] == "spawn")
   {
     Level.setSpawn(Player.getX(),Player.getY(),Player.getZ());
     clientMessage("Spawn Set");
   }
 	if(command[0] == "home" && dream == 1) {
dream = 0;
Player.setHealth(20);
setPosition(getPlayerEnt(), Px, Py, Pz);
Level.setTime(0);
soul--;
}
   if(command[0] == "nichtoe")
{
          clientMessage(ChatColor.RED + "the blood crys....");
          Vampire = 1;
          check = 1;
          cur9 = 0;
          cur8 = 0;
          cur7 = 0;
          cur6 = 0;
          cur5 = 0;
          cur4 = 0;
          cur3 = 0;
          cur2 = 0;
          cur1 = 0;
          cur0 = 0;
          soul = 9999;
          shelf = 10;
          possessed = 0;
          mistAb = 1;
          if(pig== true)
          {
          Entity.setRenderType(Player.getEntity(), 3);
          Entity.setMobSkin(Player.getEntity(), "mob/char.png");
          pig = false;
          }
}
}

function entityAddedHook(ent)
{

if(Entity.getEntityTypeId(ent)==32)
{
  
var DX = Entity.getX(ent);
var DY = Entity.getY(ent);
var DZ = Entity.getZ(ent);

 var random1 = Math.floor((Math.random()*10)+1);
if(random1 == 5) {
vamp=Level.spawnMob(DX, DY+1, DZ, 32);
spider=Level.spawnMob(DX, DY+1, DZ,35);Entity.setMobSkin(vamp, "mob/vampire.png");
rideAnimal(vamp, spider);

}
}
if(Entity.getEntityTypeId(ent)==34)
{
  
var SX = Entity.getX(ent);
var SY = Entity.getY(ent);
var SZ = Entity.getZ(ent);

 var random2 = Math.floor((Math.random()*10)+1);
if(random2 == 5) {
skelly=Level.spawnMob(SX, SY+1, SZ, 34);
jockey=Level.spawnMob(SX, SY+1, SZ,35);
rideAnimal(skelly, jockey);

}
}
if(Entity.getEntityTypeId(ent)==35)
{
if(ALS == 0)
{
Entity.setHealth(ent, 20);
}
}
}

function mainMenu(){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        try{
            var menuLayout = new android.widget.LinearLayout(ctx);
            var menuScroll = new android.widget.ScrollView(ctx);
            var menuLayout1 = new android.widget.LinearLayout(ctx);
            menuLayout.setOrientation(1);
            menuLayout1.setOrientation(1);

            menuScroll.addView(menuLayout);
            menuLayout1.addView(menuScroll);

            var button1 = new android.widget.Button(ctx);
            button1.setText("Diamond Sword - 20$");
            button1.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 20)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 19)
                    {
                    addItemInventory(276,1);
                    cash = cash - 20;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button1);

            var button2 = new android.widget.Button(ctx);
            button2.setText("Vampire Bottle - 2$");
            button2.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 2)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 1)
                    {
                    addItemInventory(471,1);
                    cash = cash - 2;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button2);

            var button3 = new android.widget.Button(ctx);
            button3.setText("Clock - 5$");
            button3.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 5)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 4)
                    {
                    addItemInventory(347,1);
                    cash = cash - 5;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button3);

            var button4 = new android.widget.Button(ctx);
            button4.setText("Compass - 5$");
            button4.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 5)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 4)
                    {
                    addItemInventory(345,1);
                    cash = cash - 5;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button4);

            var button5 = new android.widget.Button(ctx);
            button5.setText("50 Flesh - 50$");
            button5.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 50)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 49)
                    {
                    addItemInventory(367,50);
                    cash = cash - 50;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button5);

            var button6 = new android.widget.Button(ctx);
            button6.setText("Blood 6 pack - 20$");
            button6.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 20)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 19)
                    {
                    addItemInventory(472,6);
                    cash = cash - 20;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button6);
   
            var button7 = new android.widget.Button(ctx);
            button7.setText("Blood 12 pack - 40$");
            button7.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 40)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 39)
                    {
                    addItemInventory(472,12);
                    cash = cash - 40;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button7);

            var button8 = new android.widget.Button(ctx);
            button8.setText("Redstone - 100 piles - 100$");
            button8.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    if(cash < 100)
                    {
                     clientMessage("Not Enough Cash!!");
                    }
                    if(cash > 99)
                    {
                    addItemInventory(331,100);
                    cash = cash - 100;
                    clientMessage("Purchased");
                    }
                }
            }));
            menuLayout.addView(button8);
            
var button9 = new android.widget.Button(ctx);
            button9.setText("Leave Mort's Shop");
            button9.setOnClickListener(new android.view.View.OnClickListener({
                onClick: function(viewarg){
                    mo = 1;
                    menu.dismiss();
                }
            }));
            menuLayout.addView(button9);

            menu = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
            menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
            menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
        }catch(error){
            print("An error occured: " + error);
        }
    }}));
}

function leaveGame()
{
  
if(pig== true)
          {
          pig = false;
          }

  var activity = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
  activity.runOnUiThread(new java.lang.Runnable({ run: function() {
        if(buttonWindow != null) { 
          buttonWindow.dismiss(); 
          buttonwindow = null;
        }
  }}));

  var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
        if(menu != null){
            menu.dismiss();
            menu = null;
        }
    }}));

ModPE.saveData("rsc", rsc);
ModPE.saveData("shelf", shelf);
ModPE.saveData("gb1", gb1);
ModPE.saveData("gb2", gb2);
ModPE.saveData("gb3", gb3);
ModPE.saveData("gb4", gb4);
ModPE.saveData("gb5", gb5);
ModPE.saveData("trap", trap);
ModPE.saveData("Vampire", Vampire);
ModPE.saveData("soul", soul);
ModPE.saveData("cur9", cur9);
ModPE.saveData("cur8", cur8);
ModPE.saveData("cur7", cur7);
ModPE.saveData("cur6", cur6);
ModPE.saveData("cur5", cur5);
ModPE.saveData("cur4", cur4);
ModPE.saveData("cur3", cur3);
ModPE.saveData("cur2", cur2);
ModPE.saveData("cur1", cur1);
ModPE.saveData("cur0", cur0);
ModPE.saveData("check", check);
ModPE.saveData("flesh", flesh);
ModPE.saveData("possessed", possessed);
ModPE.saveData("Tel", Tel);
ModPE.saveData("TPX", TPX);
ModPE.saveData("TPY", TPY);
ModPE.saveData("TPZ", TPZ);
ModPE.saveData("cash", cash);
ModPE.saveData("mistAb", mistAb);
}

//Magic Wand Compiled by Kioni from scripts made from Kioni and the original creator of the magic wands scripts mrbliss1, Sprint by WhytoFu, Original Dimension by Hexdro. This is a compilation and i don't take credit for everything involved in this script.

//2014 Kioni ®
