var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

/*Wither mod v2.0 by Sin0psysS
//!\\ Do not copy any of this code without my authorisation
Do not put this mod in a modpack without my authorisation

Enjoy & give me feedback!!
Type '/help' in game*/

var credits="§8Wither mod by §5Sin§d0§5psysS\nThanks for playing, be sure to give me feedback!"
var wskeletonRenderer = Renderer.createHumanoidRenderer();
addWskeletonToRenderer(wskeletonRenderer);
var j=1;
var Xpos;
var Zpos;
var Xdiff;
var Zdiff;
var wsX;
var wsY;
var wsZ;
var withereffect=-1;
var poison=-1;
var tile;
var g=1;
var random;
var alea;
var spawned=0;
var unstuck=-1;
var wskeleton;
var wither;
var countdown=-1;
var count=-1;
var fire=-1;
var ball=-1;
var x;
var y;
var z;
var a;
var b;
var c;
var recurrent=19;
var recurrent2=80;
var height=4;
var witherRenderer = Renderer.createHumanoidRenderer();
addWitherToRenderer(witherRenderer);
var ballRenderer = Renderer.createHumanoidRenderer();
addBallToRenderer(ballRenderer);
Block.defineBlock(129, "Soul Sand", [["soul_sand" , 0],
["soul_sand"  , 0],
["soul_sand"  , 0],
["soul_sand"  , 0],
["soul_sand"  , 0],
["soul_sand"  , 0]], 6, true, 0);
Block.setDestroyTime(129, 1.6);
ModPE.setItem(150,"nether_star",0,"Nether Star") ;
Item.addCraftRecipe(129,1,0,[3,9,0]);
ModPE.setItem(401,"skull_wither",0,"Wither skull");
print("Type '/help' in-game");
function addWitherToRenderer(renderer)
{
var model = renderer.getModel();
var body = model.getPart("body").clear().setTextureOffset(32, 16);
body.addBox(-10, 0.5, 1, 19, 2, 4, 0);
body.addBox(-13, -6.5, -1, 7, 6, 6, 0);
body.addBox(6, -6.5, -1, 7, 6, 6, 0);
body.addBox(-2, 0, 2.5, 4, 14, 4, 0);
body.addBox(-6, 4, 2.7, 11, 2.5, 2, 0);
body.addBox(-6, 7, 2.7, 11, 2.5, 2, 0);
body.addBox(-6, 10, 2.7, 11, 2.5, 2, 0);
body.addBox(-2, 10, 4, 3, 6, 3, 0);
body.addBox(-2, 12, 6, 3, 4, 3, 0);
model.getPart("rightArm").clear()
model.getPart("leftArm").clear()
model.getPart("leftLeg").clear()
model.getPart("rightLeg").clear()
}
function addWskeletonToRenderer(renderer)
{
var model3 = renderer.getModel();
var wskeletonHead=model3.getPart("head").clear().setTextureOffset(0,32);
wskeletonHead.addBox(-4, -16, -5, 8, 8, 8, 0);
var wskeletonBody = model3.getPart("body").clear().setTextureOffset(32, 16);
wskeletonBody.addBox(-1, -9, -2, 2, 16, 2, 0);
wskeletonBody.addBox(-6, -7, 0, 12, 4, 2, 0);
wskeletonBody.addBox(-4, -4, -2, 8, 3, 2, 0);
wskeletonBody.addBox(-3, 1, -1, 6, 1, 1, 0);
wskeletonBody.addBox(-3, -3, -1, 1, 4, 1, 0);
wskeletonBody.addBox(2, -3, -1, 1, 4, 1, 0); 
wskeletonBody.addBox(-4, 6, -2, 8, 2, 2, 0);
wskeletonBody.addBox(3.5, -9, 2, 2, 2, -11, 0);
wskeletonBody.addBox(-5.5, -21, -7, 1, 16, 2, 0);
wskeletonBody.addBox(-5.5, -22, -6, 1, 19, 1, 0);
wskeletonBody.addBox(-5.5, -9, 2, 2, 2, -11, 0); model3.getPart("rightArm").clear().setTextureOffset(56, 0);
var wskeletonArms = model3.getPart("leftArm").clear().setTextureOffset(56, 0);
var wskeletonRightLeg = model3.getPart("rightLeg").clear().setTextureOffset(56, 0);
wskeletonRightLeg.addBox(-1, -5, -1, 2, 17, 2, 0);
var wskeletonLeftLeg = model3.getPart("leftLeg").clear().setTextureOffset(56, 0);
wskeletonLeftLeg.addBox(-1, -5, -1, 2, 17, 2, 0);
}
function addBallToRenderer(renderer)
{
var model2 = renderer.getModel();
model2.getPart("body").clear();
model2.getPart("rightArm").clear()
model2.getPart("leftArm").clear()
model2.getPart("leftLeg").clear()
model2.getPart("rightLeg").clear()
}
function spawnWither()
{
countdown=200;
wither = Level.spawnMob(a,b+1,c, 12, "mob/char.png");
Entity.setRenderType(wither, witherRenderer.renderType);
wX=Entity.getX(wither);
wY=Entity.getY(wither);
wZ=Entity.getZ(wither);
clientMessage("§5Withering....");
}
function modTick()
{
if(y-Entity.getY(ball)>=0)
{
setVelY(ball,0.3);
}
else if(y-Entity.getY(ball)<=0)
{
setVelY(ball,-0.25);
}
if(x-Entity.getX(ball)>=0)
{
setVelX(ball,0.32);
}
else if(x-Entity.getX(ball)<=0)
{
setVelX(ball,-0.32);
}
if(z-Entity.getZ(ball)>=0)
{
setVelZ(ball,0.32);
}
else if(z-Entity.getZ(ball)<=0)
{
setVelZ(ball,-0.32);
}
if(countdown==-1)
{
if(getPlayerY()-Entity.getY(wither)<=-10)
{
setVelY(wither,-0.4);
}
if(getPlayerX()-Entity.getX(wither)<=-10)
{
setVelX(wither,-0.4);
}
else if(getPlayerX()-Entity.getX(wither)>=10)
{
setVelX(wither, 0.4);
}
if(getPlayerZ()-Entity.getZ(wither)<=-10)
{
setVelZ(wither,-0.4)
}
else if(getPlayerZ()-Entity.getZ(wither)>=10)
{
setVelZ(wither,0.4)
}
if(getTile(Entity.getX(wither),Entity.getY(wither)-height,Entity.getZ(wither))==0)
{
if(recurrent2>=60)
{
setVelY(wither,-0.1)
}
else
{
setVelY(wither,0)
}
}
else
{
setVelY(wither, 0.4)
}
}
if(fire>=1)
{
fire=fire-1;
}
if(fire==0)
{
fire=70;
if(ball==-1)
{
ball=Level.spawnMob(Entity.getX(wither),Entity.getY(wither)+1,Entity.getZ(wither),12, "mob/char.png");
x=Player.getX();
y=Player.getY()-2;
z=Player.getZ();
count=42;
Entity.setHealth(ball,100);
Entity.setRenderType(ball, ballRenderer.renderType);
}
}
if(count>=1)
{
count=count-1;
}
if(count==0)
{
count=-1;
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3);
Entity.remove(ball);
ball=-1
}
if(countdown>=1)
{
countdown=countdown-1;
setVelX(wither,0);
setVelY(wither,0.01);
setVelZ(wither,0);
Entity.setHealth(wither,10);
}
if(countdown==0)
{
clientMessage("§0Withered.");
countdown=-1;
Entity.setHealth(wither,200);
Level.explode(Entity.getX(wither),Entity.getY(wither),Entity.getZ(wither),6);
Entity.remove(wither);
wither = Level.spawnMob(wX, wY, wZ, 12, "mob/char.png");
Entity.setRenderType(wither, witherRenderer.renderType);
Entity.setHealth(wither,140);
fire=70;
}
if(getTile(Entity.getX(ball),Entity.getY(ball)-1,Entity.getZ(ball))==0)
{
}
else
{
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3);
Entity.remove(ball);
ball=-1;
count=-1;
}
if(recurrent>=1)
{
recurrent=recurrent-1;
}
if(recurrent==0)
{
recurrent=5;
if(getTile(Player.getX(),Player.getY()-2,Player.getZ())==129)
{
setVelX(getPlayerEnt(),0);
setVelZ(getPlayerEnt(),0);
}
}
if(recurrent2>=1)
{
recurrent2=recurrent2-1;
}
if(recurrent2==0)
{
recurrent2=80;
height=Math.floor((Math.random()*3)+1);
height=height+1
}
alea=Math.floor((Math.random()*1000)+1)
var time = Level.getTime()-Math.floor(Level.getTime()/19200)*19200;
if(time<(19200/2))
{
}
else
{
if(spawned==0)
{
if(alea==253)
{
pitch = ((Entity.getPitch(getPlayerEnt()) + 90) * Math.PI)/180;
yaw = ((Entity.getYaw(getPlayerEnt()) + 90) * Math.PI)/180;
dirx = Math.sin(pitch) * Math.cos(yaw);
diry = Math.sin(pitch) * Math.sin(yaw);
wskeleton = Level.spawnMob(getPlayerX()-(20*dirx), getPlayerY(), getPlayerZ()-(20*diry), 32, "mob/char.png");
Entity.setRenderType(wskeleton, wskeletonRenderer.renderType);
j=1;
spawned=1;
unstuck=20;
Entity.setHealth(wskeleton,30);
}
}
}
wsX=Entity.getX(wskeleton);
wsY=Entity.getY(wskeleton);
wsZ=Entity.getZ(wskeleton);
if(j==1)
{
Xpos=Entity.getX(wskeleton);
Zpos=Entity.getZ(wskeleton);
j = j + 1;
}
else if(j==3)
{
j=1;
Xdiff=Entity.getX(wskeleton)-Xpos;
Zdiff=Entity.getZ(wskeleton)-Zpos;
setVelX(wskeleton,Xdiff);
setVelZ(wskeleton,Zdiff);
Xdiff=0;
Zdiff=0;
}
if(j!=1)
{
j = j + 1;
}
if(withereffect>=1)
{
withereffect=withereffect-1;
if(poison>=1)
{
poison=poison-1;
if(poison==3)
{
Entity.setHealth(getPlayerEnt(), Entity.getHealth(getPlayerEnt())-1);
setVelX(getPlayerEnt(),0);
setVelY(getPlayerEnt(),0);
setVelZ(getPlayerEnt(),0);
tile=getTile(Player.getX(),Player.getY()+2,Player.getZ())
setTile(Player.getX(),Player.getY()+2,Player.getZ(),173);
Level.destroyBlock(Player.getX(),Player.getY()+2,Player.getZ());
setTile(Player.getX(),Player.getY()+2,Player.getZ(),tile)
}
}
if(poison==0)
{
poison=13
}
}
if(withereffect==0)
{
withereffect=-1;
poison=-1;
}
if(g>=1)
{
g=g-1;
health1=Entity.getHealth(getPlayerEnt())
}
else if(g==0)
{
g=1;
health2=Entity.getHealth(getPlayerEnt());
if(health1-health2>=1)
{
attackerCheck()
}
}
if(unstuck>=1)
{
unstuck=unstuck-1;
if(getTile(Entity.getX(wskeleton),Entity.getY(wskeleton), Entity.getZ(wskeleton))==0)
{
}
else
{
setPosition(Entity.getX(wskeleton),Entity.getY(wskeleton)+1,Entity.getZ(wskeleton))
}
}
if(unstuck==0)
{
unstuck=-1;
}
}
function useItem(x, y, z, itemId, blockId)
{
a=x;
b=y;
c=z;
if(itemId==401&&Player.getCarriedItemCount()>=3&&getTile(x,y,z)==129&&getTile(x,y-1,z)==129&&getTile(x+1,y,z)==129&&getTile(x-1,y,z)==129)
{
addItemInventory(401,-3);
Level.destroyBlock(x,y,z);
Level.destroyBlock(x,y-1,z);
Level.destroyBlock(x+1,y,z);
Level.destroyBlock(x-1,y,z);
spawnWither()
}
if(itemId==401&&Player.getCarriedItemCount()>=3&&getTile(x,y,z)==129&&getTile(x,y-1,z)==129&&getTile(x,y,z+1)==129&&getTile(x,y,z-1)==129)
{
addItemInventory(401,-3);
Level.destroyBlock(x,y,z);
Level.destroyBlock(x,y-1,z);
Level.destroyBlock(x,y,z+1);
Level.destroyBlock(x,y,z-1);
spawnWither()
}
if(itemId==150)
{
Level.dropItem(Player.getX(), Player.getY(),Player.getZ(),1,264,1,0);
clientMessage(credits);
}
}
function procCmd(cmd)
{
var c = cmd.split(" ");
if(c[0] == "help")
{
clientMessage("> Kill wither skeletons at night.\n> Collect 3 wither skulls.\n> Craft soul sand with 9 dirt.\n> Create a basic golem pattern.\n> Hit the middle top block with the 3 skulls stacked.\n§4> Run.")
}
}
function attackerCheck()
{
if(Player.getX()-Entity.getX(wskeleton)<=2&&Player.getX()-Entity.getX(wskeleton)>=-1&&Player.getZ()-Entity.getZ(wskeleton)<=2&&Player.getZ()-Entity.getZ(wskeleton)>=-1)
{
withereffect=100;
poison=0;
}
}
function entityRemovedHook(entity)
{
if(entity==wither)
{
Level.dropItem(Entity.getX(entity),Entity.getY(entity),Entity.getZ(entity),1,150,1,0);
fire=-1;
}
if(entity==wskeleton)
{
spawned=0;
random= Math.floor((Math.random()*50)+1);
if(random>=1&&random<=40)
{
Level.dropItem(wsX,wsY,wsZ,1, 352, Math.floor((Math.random()*2)+1),0);
}
if(random>=1&&random<=25)
{
Level.dropItem(wsX,wsY,wsZ,1, 263, Math.floor((Math.random()*3)+1),0);
}
if(random>=1&&random<=10)
{
Level.dropItem(wsX,wsY,wsZ,1, 272, 1, Math.floor((Math.random()*40)+1));
}
if(random>=38&&random<=43)
{
Level.dropItem(wsX,wsY,wsZ,1,401,1,0);
}
}
if(Entity.getX(wskeleton)-Player.getX()>=50&&Entity.getX(wskeleton)-Player.getX()<=-50||Entity.getZ(wskeleton)-Player.getZ()>=50&&Entity.getZ(wskeleton)-Player.getZ()<=-50||Entity.getY(wskeleton)-Player.getY()>=50&&Entity.getY(wskeleton)-Player.getY()<=-50 )
{
Entity.remove(wskeleton);
spawned=0;
}
}

}
/*
     FILE ARCHIVED ON 16:53:33 Jun 06, 2015 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 06:52:22 Mar 21, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 138.98
  exclusion.robots: 0.09
  exclusion.robots.policy: 0.08
  cdx.remote: 0.068
  esindex: 0.024
  LoadShardBlock: 96.791 (3)
  PetaboxLoader3.datanode: 123.006 (4)
  load_resource: 91.911
  PetaboxLoader3.resolve: 37.185
*/