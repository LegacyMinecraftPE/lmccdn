var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

/*You are the wither boss mod by Sin0psysS
//!\\ Do not copy any of this code without my authorisation
Do not put this mod in a modpack without my authorisation

Feel free to make reviews of this mod!
Enjoy & give me feedback!!
Type '/help' in game*/

var ball;
var poison=-1;
var withereffect=-1;
var count=-1;
var fire=-1;
var yaw;
var pitch;
var dirx;
var diry;
var dirz;
var fly=0;
var layout;
var button;
var fall;
var height=4;
var toset=0;
var recurrent2=80;
var ctx;
var j=1;
var GUI=null;
var pwither=0;
var witherRenderer = Renderer.createHumanoidRenderer();
addWitherToRenderer(witherRenderer);
var ballRenderer = Renderer.createHumanoidRenderer();
addBallToRenderer(ballRenderer);
print("Type '/help' in-game");
function addWitherToRenderer(renderer)
{
var model = renderer.getModel();
var body = model.getPart("body").clear().setTextureOffset(32, 16);
body.addBox(-10, 0.5, 1, 19, 2, 4, 0);
body.addBox(-13, -6.5, -1, 7, 6, 6, 0);
body.addBox(6, -6.5, -1, 7, 6, 6, 0);
body.addBox(-2, 0, 2.5, 4, 14, 4, 0);
body.addBox(-6, 4, 2.7, 11, 2.5, 2, 0);
body.addBox(-6, 7, 2.7, 11, 2.5, 2, 0);
body.addBox(-6, 10, 2.7, 11, 2.5, 2, 0);
body.addBox(-2, 10, 4, 3, 6, 3, 0);
body.addBox(-2, 12, 6, 3, 4, 3, 0);
model.getPart("rightArm").clear()
model.getPart("leftArm").clear()
model.getPart("leftLeg").clear()
model.getPart("rightLeg").clear()
}
function addBallToRenderer(renderer)
{
var model2 = renderer.getModel();
model2.getPart("body").clear();
model2.getPart("rightArm").clear()
model2.getPart("leftArm").clear()
model2.getPart("leftLeg").clear()
model2.getPart("rightLeg").clear()
}

function flyButton()
{
ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
ctx.runOnUiThread(new java.lang.Runnable(
{
run: function()
{
if(GUI != null)
{
GUI.dismiss();
GUI = null;
}
try
{
layout = new android.widget.LinearLayout(ctx); layout.setOrientation(1);
fbutton= new android.widget.Button(ctx);
fbutton.setText("Fire skulls");
fbutton.setOnClickListener(new android.view.View.OnClickListener(
{
onClick: function(viewarg)
{
if(ball==-1)
{
pitch = ((Entity.getPitch(getPlayerEnt()) + 90) * Math.PI)/180;
yaw = ((Entity.getYaw(getPlayerEnt()) + 90) * Math.PI)/180;
dirx = Math.sin(pitch) * Math.cos(yaw);
diry = Math.sin(pitch) * Math.sin(yaw);
dirz = Math.cos(pitch);
ball=Level.spawnMob(Player.getX()+dirx,Player.getY()+dirz,Player.getZ()+diry,12, "mob/char.png");
count=42;
Entity.setHealth(ball,100);
Entity.setRenderType(ball, ballRenderer.renderType);
setVelX(ball,0.8*dirx); 
setVelY(ball,0.8*dirz); 
setVelZ(ball,0.8*diry);
}
}
}));
layout.addView(fbutton);
button = new android.widget.Button(ctx);
if(fly==1)
{
button.setText("Fly ON");
}
if(fly==0)
{
button.setText("Fly OFF");
}
button.setOnClickListener(new android.view.View.OnClickListener(
{
onClick: function(viewarg)
{
if(fly==1)
{
fly=0;
button.setText("Fly OFF");
fall=Level.spawnMob(Player.getX(),Player.getY()-1,Player.getZ(),10);
rideAnimal(getPlayerEnt(),fall);
Entity.setRenderType(fall,1);
}
else if(fly==0)
{
fly=1;
button.setText("Fly ON");
}
}
}));
layout.addView(button);
GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)); GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 0, 0);
}
catch(err)
{
print("An error occured: " + err);
}
}
}));
}

function modTick()
{
if(pwither==1)
{
if(count>=1)
{
count=count-1;
}
if(count==0)
{
count=-1;
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3);
Entity.remove(ball);
ball=-1
}
if(getTile(Entity.getX(ball),Entity.getY(ball)-1,Entity.getZ(ball))==0&&getTile(Entity.getX(ball),Entity.getY(ball)+1,Entity.getZ(ball))==0)
{
}
else
{
Level.explode(Entity.getX(ball),Entity.getY(ball),Entity.getZ(ball),3);
Entity.remove(ball);
ball=-1;
count=-1;
}
if(fly==1)
{
if(getTile(Entity.getX(getPlayerEnt()),Entity.getY(getPlayerEnt())-height,Entity.getZ(getPlayerEnt()))==0)
{
if(recurrent2>=60)
{
setVelY(getPlayerEnt(),-0.1)
}
else
{
setVelY(getPlayerEnt(),0)
}
}
else
{
setVelY(getPlayerEnt(), 0.1)
}
}
}
if(recurrent2>=1)
{
recurrent2=recurrent2-1;
}
if(recurrent2==0)
{
recurrent2=80;
height=Math.floor((Math.random()*3)+1);
height=height+3
}
if(withereffect>=1)
{
withereffect=withereffect-1;
if(poison>=1)
{
poison=poison-1;
if(poison==3)
{
Entity.setHealth(withered, Entity.getHealth(withered)-1);
setVelX(withered,0);
setVelY(withered,0);
setVelZ(withered,0);
tile=getTile(Entity.getX(withered),Entity.getY(withered)+2,Entity.getZ(withered))
setTile(Entity.getX(withered),Entity.getY(withered)+2,Entity.getZ(withered), 173);
Level.destroyBlock(Entity.getX(withered),Entity.getY(withered)+2,Entity.getZ(withered));
setTile(Entity.getX(withered),Entity.getY(withered)+2,Entity.getZ(withered), tile)
}
}
if(poison==0)
{
poison=13
}
}
if(withereffect==0)
{
withereffect=-1;
poison=-1;
}
if(pwither==1)
{
if(j==1)
{
Xpos=getPlayerX();
Zpos=getPlayerZ();
j = j + 1;
}
else if(j==3)
{
j=1;
Xdiff=getPlayerX()-Xpos;
Zdiff=getPlayerZ()-Zpos;
setVelX(getPlayerEnt(),Xdiff);
setVelZ(getPlayerEnt(),Zdiff);
Xdiff=0;
Zdiff=0;
}
if(j!=1)
{
j = j + 1;
}
}
if(getTile(Entity.getX(fall),Entity.getY(fall)-1,Entity.getZ(fall))==0)
{
}
else
{
Entity.remove(fall);
}
if(toset==1)
{
toset=0;
flyButton()
}
setVelX(ball,0.7*dirx); 
setVelY(ball,0.7*dirz); 
setVelZ(ball,0.7*diry);
Entity.setHealth(fall,10);
if(Entity.getVelY(ball)<=-1)
{
setVelY(ball,-0.05)
}
}
function leaveGame()
{
ctx=com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
ctx.runOnUiThread(new java.lang.Runnable(
{
run: function()
{
if(GUI != null)
{
GUI.dismiss();
GUI = null;
}
}
}));
}
function procCmd(cmd)
{
var c = cmd.split(" ");
if(c[0] == "help")
{
clientMessage("> §8You are the wither boss mod by §5Sin§d0§5psysS\n> Use §4/wither §fto turn into the wither boss!\n> Thanks for playing, be sure to give me feedback!")
}
if(c[0]=="wither")
{
if(pwither==0)
{
Entity.setRenderType(getPlayerEnt(), witherRenderer.renderType);
pwither=1;
toset=1;
j=1;
clientMessage("§0Withered.");
print("Leave game to come back to normal") ;
}
}
}

}
/*
     FILE ARCHIVED ON 01:59:51 Jun 07, 2015 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 06:57:40 Mar 21, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 129.652
  exclusion.robots: 0.088
  exclusion.robots.policy: 0.077
  cdx.remote: 0.063
  esindex: 0.008
  LoadShardBlock: 101.246 (3)
  PetaboxLoader3.datanode: 78.692 (4)
  load_resource: 106.201
  PetaboxLoader3.resolve: 53.925
*/