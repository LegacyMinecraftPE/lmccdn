<?php
/*
__PocketMine Plugin__
name=Achivement
version=1.0.1
author=onebone
apiversion=10,11
class=Achivement
*/
/*
===== Read me ======
Editing the plugin is allowed but can't be shared by everyone except onebone. This software can be shared just in MCPE KOREA. If sharing this plugin in other community or somewhere, I won't care about your disadvantage.
All CopyRight reserved at naver café MCPE KOREA  resisdent onebone.
If you find an error, please send e-mail at 'jyc0410@naver.com' and log.

이 플러그인을 수정하는 것은 허용하나, 공유하는 것은 MCPE KOREA 회원 '원본' 외엔 금지 합니다. 이 플러그인은 오직 MCPE KOREA에서만 공유될 수 있으며, 다른 커뮤니티나 타 사이트에서 공유 적발 시 발생 하는 불이익은 책임지지 읺습니다.
해당 자료의 모든 저직권은 네이버 카페 MCPE KOREA의 회원인 '원본'에게 있습니다
오류 발견 시 이메일 'jyc0410@naver.com'으로 오류 화면 및 로그를 보내주십시오.

=====CHANGE LOG======
v1.0.0 BETA: First Release
v1.0.1 : Compatible with API 11

======For plugin developers======
절대로 플러그인을 폰으로 만들려고 시도하지 마세요
줄 찾기도 힘들고 정렬하려고 스페이스바 연타 하는거 힘듭니다(경험담)

player.achivement.get 핸들러 사용 가능

*/

class Achivement implements Plugin {
	private $api,
	$block,
	$player,
	$ex;
	public function __construct(ServerAPI $api, $server = false) {
		$this->api = $api;
	}
	public function init() {
		$this->ex = false;
		foreach($this->api->plugin->getList() as $p) {
			if ($p["name"] == "EconomyAPI") {
				$this->ex = true;
				break;
			}
		}
		$this->path = $this->api->plugin->configPath($this);
		$this->api->addHandler("console.command", array($this, "handle"));
		$this->api->addHandler("achivement.handle", array($this, "handle"));
		$this->api->addHandler("player.block.touch", array($this, "handle"));
		$this->api->addHandler("player.join", array($this, "handle"));
		$this->api->event("server.close", array($this, "handle"));
		if (!is_file($this->path."Blocks.yml")) {
			$default["17"][]["message"] = "[Achivement] You have been reached \"First Tree\"";;
			foreach($default["17"]as $key => $value) {
				$default["17"][$key]["count"] = 1;
				$default["17"][$key]["name"] = "First Tree";
			}
			$default["17"][++$key]["count"] = 64;
			$default["17"][$key]["name"] = "Set of Tree";
			$default["17"][$key]["message"] = "[Achivement] You have been reached \"Set of Tree\"";
			$this->blockdata = new Config($this->path."Blocks.yml", CONFIG_YAML, $default);
		} else {
			$this->blockdata = new Config($this->path."Blocks.yml", CONFIG_YAML);
		}
		if (!is_file($this->path."Help.txt")) {
			file_put_contents($this->path."Help.txt", "English\n\nInstructions for 'Blocks.yml'. \nUse Blocks.yml like this : \n(Write your BlockID):\n  -\n	 count:(count you want)\n	 message: '(Message when player got achivement)'\n	 name: (name of the achivement)\n\nBeside of the message need ''. \n\nThis is all of the instruction of Blocks.yml and this plugin. Example at 'plugins/Achivement/Blocks.yml'. You have to write '' beside of the message. If one of the setting are not supported, could make an error. For question or else, send email at jyc0410@naver.com\nHave fun!\n\n\n한국어\n\n플러그인의 설정 파일인 Blocks.yml 파일에 대하여 설명하겠습니다. 이 파일은 Achivement 폴더 안에 있습니다.\nBlocks.yml 으로 도전과제를 설정하는 방법입니다: \n(원하시는 아이템 코드):\n	-\n	   count: (도전과제를 달성하기 위해 필요한 아이템 개수를 쓰면 됩니다)\n	   message: '(도전과제를 달성 했을 시 나오는 메세지를 하시면 됩니다)'\n	   name: (도전과제의 이름을 넣으시면 됩니다)\nmessage에는 양옆에 ''이 붙어야 하니 주의하시기 바랍니다.\n이것이 Blocks.yml 의 모든 사용법이며, 이 플러그인의 사용법입니다. 예시는 'plugins/Achivement/Blocks.yml' 파일에 있습니다. message 를 적을 때는 양 끝에 ''를 붙이고 해야하니 주의하시기 바랍니다. 세팅이 하나라도 안되있다면 오류가 발생할 것입니다. 궁금한 점 및 기타 사항이 있으시다면 jyc0410@naver.com 으로 메일을 주시기 바랍니다. 즐거운 하루 되세요!\n\nMade by MCPE KOREA resisdent onebone(jyc0410)");
			console("\x1b[32m[Achivement] Please read Help.txt at '/plugins/Achivement' for help.", true, false);
		}
		$this->path = $this->api->plugin->createConfig($this, array("show-loading-process" => true,));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
		$this->playerdata = new Config($this->path."Player.yml", CONFIG_YAML);
		$data = $this->api->plugin->readYAML($this->path."Blocks.yml");
		$data2 = $this->api->plugin->readYAML($this->path."Player.yml");
		$cnt = 1;
		$count = 0;
		foreach($data as $a) {
			foreach($a as $b) {
				$count++;
			}
		}
		$count2 = count($data2);
		$rcount = $count + $count2;
		if (!empty($data)) {

			foreach($data as $a => $b) {
				foreach($b as $key => $value) {
					$this->block[$a][$key]["count"] = $value["count"];
					$this->block[$a][$key]["message"] = $value["message"];
					$this->block[$a][$key]["name"] = $value["name"];
					if ($this->config["show-loading-process"] == true) {
						console("[Achivement] Loading data...(".(int)(($cnt / $rcount) * 100)."%)", true, false);
					}
					$cnt++;
				}
			}
		}
		if (!empty($data2)) {
			foreach($data2 as $key => $value) { //플레이어
				foreach($value as $k => $v) { //아이템들 분류
					if (isset($value["Achivements"]) and $value["Achivements"] !== null and isset($k) and $k !== null and isset($v["count"])) {
						$this->player[$key][$k]["count"] = $v["count"];
						$this->player[$key][$k]["Achivements"] = $value["Achivements"];
					}
					elseif(!isset($value["Achivements"])) {
						console("[ERROR] Invalid data of 'Player.yml'");
					}
					elseif(!isset($k) and $value["Achivements"] !== null) {
						$this->player[$key]["Achivements"] = $value["Achivements"];
					}
					elseif(!isset($k)) {
						$this->player[$key]["Achivements"] = array();
					}
					elseif(isset($v["count"])) {
						$this->player[$key]["count"] = $v["count"];
						$this->player[$key]["Achivements"] = array();
					} else {
						$this->player[$key]["Achivements"] = array();
					}
				}
				if ($this->config["show-loading-process"] == true) {
					console("[Achivement] Loading data...(".(int)(($cnt / $rcount) * 100)."%)", true, false);
				}
				$cnt++;
			}
		}
		console("[Achivement] Loading data done");
	}
	public function __destruct() {}
	public function handle(&$data, $event) {
		switch ($event) {
		case "player.block.touch":
			switch ($data["type"]) {
			case "break":
				$t = $data["target"];
				if (!isset($this->player[$data["player"]->username][(int) $t->getID()]["count"])) { // 플레이어가 이전에 이 아이템을 얻었는지 확인
					$this->player[$data["player"]->username][(int) $t->getID()]["count"] = 0;
				}

				$plcnt =& $this->player[$data["player"]->username][(int) $t->getID()]["count"];
				$plcnt += 1;
				if ($this->block == null) {
					break 2;
				}
				foreach($this->block as $a => $b) {
					foreach($this->block[$a]as $key => $value) {
						if ($a == (int) $t->getID() and $value["count"] <= $plcnt and empty($this->player[$data["player"]->username]["Achivements"]) or $a == (int) $t->getID() and !in_array($value["name"], $this->player[$data["player"]->username]["Achivements"]) and $value["count"] <= $plcnt) {
							$data["player"]->sendChat($value["message"]);
							$this->api->dhandle("player.achivement.get", array("block" => $t->getID(), "issuer" => $data["player"]->username, "count" => $value["count"]));
							if ($this->ex == true) {
								$this->api->economy->takeMoney($data["player"]->username, 1);
							}
							$this->player[$data["player"]->username]["Achivements"][] = $value["name"];
							break 3;
						}
						/*elseif($a !== $t->getID()){echo "continue 2\n"; continue 2;}elseif(in_array($value["name"], $this->player[$data["player"]->username]["Achivements"]) !== false){
 echo "continue\n";
 continue;
 }*/
					}
				}
				break;
			}
			break;
		case "player.join":
			if (empty($this->player) or !array_key_exists($data->__get("username"), $this->player)) {
				$this->player[$data->username] = array("Achivements" => array(),);
			}
			break;
		case "server.close":
			$this->playerdata->setAll($this->player);
			$this->playerdata->save();
			break;
		}
	}
}