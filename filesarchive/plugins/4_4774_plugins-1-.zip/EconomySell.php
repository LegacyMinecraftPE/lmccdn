<?php
/*
__PocketMine Plugin__
name=EconomySell
description=Plugin of sell center supports EconomyAPI
version=1.1.10
author=onebone
class=EconomySell
apiversion=10,11
*/
/*

CHANGE LOG

V1.0.0 : BETA RELEASE

V 1.0.1 : MINOR BUG FIX

V 1.0.2 : BUG FIX

V 1.0.3 : KOREAN NOW AVALIBLE

V 1.0.4 : KOREAN INVALID ERROR FIX

V 1.0.5 : AMOUNT LOAD BUG FIX

V 1.0.6 : SELL BUG FIX

V 1.0.7 : Added something

V1.1.0 : Item name & item code support

V1.1.1 : Added API, function editSell()

V1.1.2 : Fixed the bug about block place/break not avaliable

V1.1.3 : Fixed bug about cannot break sign

V1.1.4 : Texts changes immediately

V1.1.5 : Now works at DroidPocketMine

V1.1.6 : You have to tap twice to sell item.

V1.1.7 : Minor bug fix

V1.1.8 : Added creating handler

V1.1.9 : Compatible with API 11

V1.1.10 : Compatible with PocketMoney (Configurable)

===Read me===
This plugin copyright to onebone of MCPE KOREA(Republic of Korea community). Sharing this plugin is allowed, however editing author will be punished by copyright law.
When sharing this plugin, please show origin.

이 플러그인의 저작권은 MCPE KOREA(대한민국 MCPE 커뮤니티). 이 플러그인 공유하는 것은 허용하나, 저작자를 수정하는 것은 저작권법에 의해 처벌받을 수 있습니다.
이 플러그인을 공유 할시, 출처를 밝혀주십시오.
*/

class EconomySell implements Plugin {
	private $api, $items, $tap;
	public $sell;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->sell = array();
		$this->tap = array();
	}

	public function init(){
		$this->createConfig();
		foreach($this->api->plugin->getList() as $p){
			if($p["name"] == "EconomyAPI" and $this->config["compatible-to-economyapi"] or $p["name"] == "PocketMoney" and !$this->config["compatible-to-economyapi"]){
				$exist = true;
				break;
			}

		}
		if(!isset($exist)){
			console("[ERROR] ".($this->config["compatible-to-economyapi"] ? "EconomyAPI" : "PocketMoney")." does not exist");
			$this->api->console->defaultCommands("stop", array(), "plugin", false);
			return;
		}

		$this->loadItems();
		$path = $this->api->plugin->configPath($this);
		EconomySellAPI::set($this);
		$this->api->event("server.close", array($this, "handler"));
		//  $this->api->addHandler("player.block.break", array($this, "handler"));
		$this->api->addHandler("player.block.touch", array($this, "handler"));
		$this->api->event("tile.update", array($this, "handler"));
		$this->centers = new Config($path."SellCenter.yml", CONFIG_YAML);
		$centerd = $this->api->plugin->readYAML($path."SellCenter.yml");
		foreach($centerd as $c){
			$this->sell[] = array("x" => $c["x"], "y" => $c["y"], "z" => $c["z"], "item" => $c["item"], "amount" => $c["amount"], "cost" => $c["cost"], "level" => $c["level"], "meta" => $c["meta"]);
		}
		$this->api->economy->EconomySRegister("EconomySell");
	}

	public function __destruct(){}
	
	public function createConfig(){
		$this->config = $this->api->plugin->readYAML($this->api->plugin->createConfig($this, array(
			"compatible-to-economyapi" => true
		))."config.yml");
	}
	
	public function editSell($data){
		foreach($this->sell as $k => $s){
			$level = $this->api->level->get($data["level"]);
			if($level == false) 
				return false;
			$t = $this->api->tile->get(new Position($data["x"], $data["y"], $data["z"], $level));
			if($t !== false and $s["x"] == $data["x"]and $data["y"] == $s["y"]and $s["z"] == $data["z"]and $data["level"] == $s["level"]){
				$this->sell[$k] = array("x" => $data["x"], "y" => $data["y"], "z" => $data["z"], "level" => $data["level"], "cost" => $data["cost"], "amount" => $data["amount"], "item" => $s["item"], "meta" => $s["meta"],);
				$t->setText($t->data["Text1"], $data["cost"]."$", $t->data["Text3"], $t->data["Text4"]);
				return true;
			}
		}
		return false;
	}
	public function handler( &$data, $event){
		$output = "";
		switch ($event){
		case "tile.update":
			if($data->class === TILE_SIGN){
				if($data->data["Text1"] == "sell" or $data->data["Text1"] == "노점상"){
					$lang = $data->data["Text1"] == "sell" ? "english" : "korean";
					$player = $this->api->player->get($data->data["creator"], false);
					if($this->api->ban->isOp($this->api->player->get($data->data["creator"], false)->username) == false){
						if($lang == "english"){
							$this->api->player->get($data->data["creator"], false)->sendChat("You don't have permission to create sell center");
						}else{
							$this->api->player->get($data->data["creator"], false)->sendChat("당신은 노점상을 생성할 권한이 없습니다");
						}
						break;
					}
					if($data->data["Text2"] == "" or $data->data["Text3"] == "" or $data->data["Text4"] == ""){
						if($lang == "english"){
							$output .= "Incorrect sell center data";

						}else{
							$output .= "노점상의 데이터가 올바르지 않습니다.";
						}
						$player->sendChat($output);
						break;
					}else{
						if(strpos($data->data["Text3"], ":") !== false){
							$e = explode(":", $data->data["Text3"]);
						}else{
							$e = explode(":", $data->data["Text3"]);
							$e[1] = isset($e[1]) ? $e[1] : 0;
							if(is_numeric($e[0]) and is_numeric($e[1])){
								$e[0] = $data->data["Text3"];
								$e[1] = 0;
							}else{
								$e = explode(":", $data->data["Text3"]);
								$e[1] = isset($e[1]) ? $e[1] : 0;
							}
						}
						if(is_numeric($e[0]) and is_numeric($e[1])){
							$name = $this->getItem($e[0].":".$e[1]);
							if($name == false){
								$player->sendChat($lang == "english" ? "Item ".$data->data["Text3"]." does not support at EconomySell" : "아이템 ".$data->data["Text3"]."는 EconomySell 에서 지원하지 않습니다");
								break;
							}
						}else{
							$id = $this->getItem($data->data["Text3"]);
							if($id == false){
								$player->sendChat($lang == "english" ? "Item ".$data->data["Text3"]." does not support at EconomySell" : "아이템 ".$data->data["Text3"]."는 EconomySell 에서 지원하지 않습니다");
								break;
							}
							$e = explode(":", $id);
							$e[1] = isset($e[1]) ? $e[1] : 0;
						}
						if($this->api->dhandle("economysell.sellcenter.create", array("x" => $data->x, "y" => $data->y, "z" => $data->z, "item" => $e[0], "meta" => $e[1], "cost" => str_replace("$", "", $data->data["Text2"]), "amount" => $data->data["Text4"], "level" => $data->level->getName())) !== false){
							$this->createSellCenter(array("meta" => $e[1], "x" => $data->data["x"], "y" => $data->data["y"], "z" => $data->data["z"], "item" => $e[0], "cost" => str_replace("$", "", $data->data["Text2"]), "amount" => $data->data["Text4"], "level" => $data->level->getName()));
							if($lang == "english"){
								$data->setText("[SELL]", $data->data["Text2"]."$", isset($name) ? $name : $data->data["Text3"], "Amount : ".$data->data["Text4"]);
								$output .= "Sell center created";
							}else{
								$data->setText("[노점상]", $data->data["Text2"]."$", isset($name) ? $name : $data->data["Text3"], "수량 : ".$data->data["Text4"]);
								$output .= "노점상이 생성되었습니다.";
							}
						}else{
							$output .= "Failed to create sell center due to unknown error.";
						}
					}
					$player->sendChat($output);
				}
			}

			break;
		case "player.block.touch":
			if($data["type"] == "break"){
				if($data["target"]->getID() == 323 or $data["target"]->getID() === 68 or $data["target"]->getID() == 63){
					if($this->sell == null){
						break;
					}
					foreach($this->sell as $s){
						if($s["x"] == $data["target"]->x and $s["y"] == $data["target"]->y and $data["target"]->z == $s["z"]){
							foreach($this->sell as $key => $value){
								if($value["x"] == $data["target"]->x and $value["y"] == $data["target"]->y and $value["z"] == $data["target"]->z and $value["level"] == $data["target"]->level->getName()){
									if($this->api->ban->isOp($data["player"]) == false){
										$data["player"]->close("tried to destroy sell center");
										return false;

									}
									unset($this->sell[$key]);
								}
							}
						}
					}
				}
				break; /// here ///
			}
			if($data["target"]->getID() == 323 or $data["target"]->getID() == 68 or $data["target"]->getID() == 63){
				if(!is_array($this->sell)){
					break;
				}
				foreach($this->sell as $s){
					if($s["x"] == $data["target"]->x and $s["y"] == $data["target"]->y and $data["target"]->z == $s["z"]and $s["level"] == $data["target"]->level->getName()){
						$can = false;
						if($data["player"]->gamemode == CREATIVE){
							$data["player"]->sendChat("You are in creative mode");
							return false;
						}
						if(!isset($this->tap[$data["player"]->username])){
							$this->tap[$data["player"]->username] = array("x" => $s["x"], "y" => $s["y"], "z" => $s["z"]);
							$this->api->schedule(20, array($this, "removeTap"), $data["player"]->username);
							$data["player"]->sendChat("Are you sure to sell this? Tap again to confirm.");
							break;
						}
						if(!($s["x"] == $this->tap[$data["player"]->username]["x"]and $s["y"] == $this->tap[$data["player"]->username]["y"]and $s["z"] == $this->tap[$data["player"]->username]["z"])){
							$data["player"]->sendChat("Are you sure to sell this? Tap again to confirm.");
							$this->tap[$data["player"]->username] = array("x" => $s["x"], "y" => $s["y"], "z" => $s["z"]);
							$this->api->schedule(20, array($this, "removeTap"), $data["player"]->username);
							$this->cancel[$data["player"]->username] = true;
							break;
						}
						$cnnt = 0;
						$ss = null;
						foreach($data["player"]->inventory as $slot => $item){
							if($s["item"] == $item->getID() and $item->getMetadata() == $s["meta"]){
								$iii = $item;
								$cnnt += $item->count;
								if($cnnt >= $s["amount"]){
									$can = true;
								}else{
									//  $cnnt += $item->count;
									$ss[] = array("sl" => $slot, "count" => $item->count);
								}
							}
						}
						if($can == false){
							$data["player"]->sendChat("You don't have the item to sell");
							return false;
						}
						if($ss !== null){
							foreach($ss as $slots){
								extract($slots);
								$s["amount"] -= $count;
								$data["player"]->setSlot($sl, BlockAPI::getItem(AIR, 0, 0));
							}
						}
						$data["player"]->removeItem($iii->getID(), $iii->getMetadata(), $s["amount"]);
						if($this->config["compatible-to-economyapi"]){
							$this->api->economy->takeMoney($data["player"], $s["cost"]);
						}else{
							$this->api->dhandle("money.handle", array(
								"username" => $data["player"]->username,
								"method" => "grant",
								"amount" => $s["cost"],
								"issuer" => "EconomySell" // Disappeared?
							));
						}
						unset($this->tap[$data["player"]->username]);
						$data["player"]->sendChat("You have been sold your item");
						return false;
					}
				}
			}
			break;
		case "server.close":
			$this->centers->setAll($this->sell);
			$this->centers->save();
			break;
		}
	}
	public function removeTap($username){
		if(isset($this->cancel[$username])){
			unset($this->cancel[$username]);
			return false;
		}
		if(isset($this->tap[$username])) 
			unset($this->tap[$username]);
		}
	public function createSellCenter($c){
		$this->sell[] = array("x" => $c["x"], "y" => $c["y"], "z" => $c["z"], "item" => $c["item"], "cost" => $c["cost"], "amount" => $c["amount"], "level" => $c["level"], "meta" => $c["meta"]);
	}
	public function getItem($item){ // gets ItemID and ItemName
		$e = explode(":", $item);
		if(count($e) > 1){
			if(is_numeric($e[0])){
				foreach($this->items as $k => $i){
					$item = explode(":", $i);
					$e[1] = isset($e[1]) ? $e[1] : 0;
					$item[1] = isset($item[1]) ? $item[1] : 0;
					if($e[0] == $item[0]and $e[1] == $item[1]){
						return $k;
					}
				}
				return false;
			}
		}else{
			if(isset($this->items[$item])){
				return $this->items[$item];
			}else{
				return false;
			}
		}
	}
	public function loadItems(){
		$items = new Config($this->api->plugin->configPath($this)."items.properties", CONFIG_PROPERTIES, array(
		"air" => 0,
		"stone" => 1,
		"grass block" => 2,
		"dirt" => 3,
		"cobble stone" => 4,
		"wooden plank" => 5,
		"tree sapling" => 6,
		"fir sapling" => "6:1",
		"birch sapling" => "6:2",
		"bedrock" => 7,
		"water" => 8,
		"stationary water" => 9,
		"lava" => 10,
		"stationary lava" => 11,
		"sand" => 12,
		"gravel" => 13,
		"gold ore" => 14,
		"iron ore" => 15,
		"coal ore" => 16,
		"tree" => 17,
		"oak wood" => "17:1",
		"birch wood" => "17:2",
		"tree leaf" => "18",
		"oak tree leaf" => "18:1",
		"birch tree leaf" => "18:2",
		"glass" => 20,
		"lapis ore" => 21,
		"lapis block" => 22,
		"sand stone" => 24,
		"sand stone2" => "24:1",
		"sand stone3" => "24:2",
		"bed" => 26,
		"cobweb" => 30,
		"bush" => 31,
		"white wool" => 35,
		"orange wool" => "35:1",
		"magenta wool" => "35:2",
		"sky wool" => "35:3",
		"yellow wool" => "35:4",
		"green wool" => "35:5",
		"pink wool" => "35:6",
		"grey wool" => "35:7",
		"grey wool2" => "35:8",
		"bluish wool" => "35:9",
		"purple wool" => "35:10",
		"blue wool" => "35:11",
		"brown wool" => "35:12",
		"green wool2" => "35:13",
		"red wool" => "35:14",
		"black wool" => "35:15",
		"yellow flower" => 37,
		"blue flower" => 38,
		"brown mushroom" => 39,
		"red mushroom" => 40,
		"gold block" => 41,
		"iron block" => 42,
		"stone foothold" => 43,
		"sand foothold" => "43:1",
		"wood foothold" => "43:2",
		"cobble foothold" => "43:3",
		"brick foothold" => "43:4",
		"stone foothold2" => "43:6",
		"half stone" => 44,
		"half sand" => "44:1",
		"half wood" => "44:2",
		"half cobble" => "44:3",
		"half brick" => "44:4",
		"half stone2" => "44:6",
		"brick" => 45,
		"TNT" => 46,
		"bookshelf" => 47,
		"moss stone" => 48,
		"obsidian" => 49,
		"torch" => 50,
		"fire" => 51,
		"wood stair" => 53,
		"chest" => 54,
		"diamond ore" => 56,
		"diamond block" => 57,
		"crafting table" => 58,
		"crop" => 59,
		"farmland" => 60,
		"furnace" => 61,
		"sign block" => 63,
		"burning furnace" => 62,
		"wooden door" => 64,
		"ladder" => 65,
		"cobble stair" => 67,
		"wall sign" => 68,
		"iron door" => 71,
		"redstone ore" => 73,
		"glow redstone" => 74,
		"snow" => 78,
		"ice" => 79,
		"snow block" => 80,
		"cactus" => 81,
		"clay block" => 82,
		"sugar cane" => 83,
		"fence" => 85,
		"nether rack" => 87,
		"glowing stone" => 89,
		"cake" => 92,
		"invisible bedrock" => 95,
		"trap door" => 96,
		"stone brick" => 98,
		"moss brick" => "98:1",
		"cracked brick" => "98:2",
		"flat glass" => 102,
		"watermelon" => 103,
		"fence gate" => 107,
		"brick stair" => 108,
		"stone stair" => 109,
		"nether brick" => 112,
		"nether brick stair" => 114,
		"sand stair" => 128,
		"quartz block" => 155,
		"soft quartz" => "155:1",
		"pilliar quartz" => "155:2",
		"quartz stair" => 156,
		"stonecutter" => 245,
		"glowing obsidian" => 246,
		"nether core" => 247,
		"update block 1" => 248,
		"update block 2" => 249,
		"error grass" => 253,
		"error leaves" => 254,
		"error stone" => 255,
		"iron shovel" => 256,
		"iron pickaxe" => 257,
		"iron axe" => 258,
		"flint and steel" => 259,
		"apple" => 260,
		"bow" => 261,
		"arrow" => 262,
		"coal" => 263,
		"charcoal" => "263:1",
		"diamond" => 264,
		"iron ingot" => 265,
		"gold ingot"=> 266,
		"iron sword" => 267,
		"wood sword" => 268,
		"wood shovel" => 269,
		"wood pickaxe" => 270,
		"wood axe" => 271,
		"stone sword" => 272,
		"stone shovel" => 273,
		"stone pickaxe" => 274,
		"stone axe" => 275,
		"diamond sword" => 276,
		"diamond shovel" => 277,
		"diamond pickaxe" => 278,
		"diamond axe" => 279,
		"stick" => 280,
		"bowl" => 281,
		"mushroom stew" => 282,
		"gold sword" => 283,
		"gold shovel" => 284,
		"gold pickaxe" => 285,
		"gold axe" => 286,
		"web" => 287,
		"feather" => 288,
		"gunpowder" => 289,
		"wood hoe" => 290,
		"stone hoe" => 291,
		"iron hoe" => 292,
		"diamond hoe" => 293,
		"gold hoe" => 294,
		"seed" => 295,
		"wheat" => 296,
		"bread" => 297,
		"leather hat" => 298,
		"leather armor" => 299,
		"leather pants" => 300,
		"leather boots" => 301,
		"chain hat" => 302,
		"chain chestplate" => 303,
		"chain leggings" => 304,
		"chain boots" => 305,
		"iron helmet" => 306,
		"iron chestplate" => 307,
		"iron leggings"=> 308,
		"iron boots" => 309,
		"diamond helmet" => 310,
		"diamond chestplate" => 311,
		"diamond leggings" => 312,
		"diamond boots" => 313,
		"gold helmet" => 314,
		"gold chestplate" => 315,
		"gold leggings" => 316,
		"gold boots" => 317,
		"flint" => 318,
		"raw pork" => 319,
		"pork" => 320,
		"paint" => 321,
		"sign" => 323,
		"door" => 324,
		"bucket" => 325,
		"water bucket" => 326,
		"iron door" => 330,
		"snowball" => 332,
		"leather" => 334,
		"clay brick" => 336,
		"clay" => 337,
		"sugarcane" => 338,
		"paper" => 339,
		"book" => 340,
		"slime ball" => 341,
		"egg" => 344,
		"compass" => 345,
		"clock" => 347,
		"glow stone" => 348,
		"ink" => 351,
		"red rose" => "351:1",
		"green cactus" => "351:2",
		"cocoa bean" => "351:3",
		"lapis lazuli" => "351:4",
		"cotton" => "351:5",
		"bluish" => "351:6",
		"light grey" => "351:7",
		"grey" => "351:8",
		"pink" => "351:9",
		"light green" => "351:10",
		"yellow" => "351:11",
		"sky" => "351:12",
		"magenta"=> "351:13",
		"orange" => "351:14",
		"bone meal" => "351:15",
		"bone" => 352,
		"sugar" => 353,
		"cake" => 354,
		"bed" => 355,
		"scissors" => 259,
		"melon" => 360,
		"melon seed" => 362,
		"raw beef" => 363,
		"stake" => 364,
		"raw chicken" => 365,
		"chicken" => 366,
		"nether brick" => 405,
		"hell quartz" => 406,
		"camera" => 456,
		));
		$this->items = $items->getAll();
	}
}
class EconomySellAPI { // Use this API to control EconomySell!
	public static $d;
	public static function set(EconomySell $e){
		if(EconomySellAPI::$d instanceof EconomySell) 
			return false;
		EconomySellAPI::$d = $e;
		return true;
	}
	public static function getSells(){
		return EconomySellAPI::$d->sell;
	}
	public static function editSell($data){
		return EconomySellAPI::$d->editSell($data);
	}
}