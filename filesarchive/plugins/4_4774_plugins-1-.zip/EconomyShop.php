<?php
/*
__PocketMine Plugin__
name=EconomyShop
version=1.1.5
author=onebone
apiversion=10,11
class=EconomyShop
*/
/*
CHNAGE LOG
==================
V 1.0.0 : Initial Release

V 1.0.1 : Korean now avaliable

V 1.0.2 : Korean error fix

V 1.0.3 : Added meta

V 1.0.4 : Added something

V1.0.5 : Fixed about the sign has been disappeared

V1.0.6 : Fixed about the block break/place not avaliable

V1.0.7 : Fixed bug which cannot break sign

V1.0.8 : Now texts changes immediately

V1.0.9 : Now works at DroidPocketMine

V1.1.0 : Supports item name
V1.1.1 : To buy, you need to tap twice

V1.1.2 : Minor bug fixed

V1.1.3 : Added creating handler

V1.1.4 : Compatible with API 11

V1.1.5 : Compatible with PocketMoney. (Configurable)
===Read me===
This plugin copyright to onebone of MCPE KOREA(Republic of Korea community). Sharing this plugin is allowed, however editing author will be punished by copyright law.
When sharing this plugin, please show origin.

이 플러그인의 저작권은 MCPE KOREA(대한민국 MCPE 커뮤니티). 이 플러그인 공유하는 것은 허용하나, 저작자를 수정하는 것은 저작권법에 의해 처벌받을 수 있습니다.
이 플러그인을 공유 할시, 출처를 밝혀주십시오.

*/
class EconomyShop implements Plugin {
	private $api, $path, $tap, $shop;
	public $config;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->shop = array();
		$this->tap = array();
	}
	public function init(){
		$this->createConfig();
		foreach($this->api->plugin->getList() as $p){
			if($p["name"] == "EconomyAPI" and $this->config["compatible-to-economyapi"] or $p["name"] == "PocketMoney" and !$this->config["compatible-to-economyapi"]){
				$exist = true;
			}
		}
		if(!isset($exist)){
			console("[ERROR] ".($this->config["compatible-to-economyapi"] ? "EconomyAPI" : "PocketMoney")." does not exist");
			$this->api->console->defaultCommands("stop", "", "EconomyPlugin", false);
			return;
		}
		$this->path = $this->api->plugin->configPath($this);
		$this->loadItems();
		$this->api->addHandler("player.block.touch", array($this, "handler"));
		$this->api->event("tile.update", array($this, "handler"));
		//$this->api->addHandler("player.block.break", array($this, "handler"));
		$this->api->event("server.close", array($this, "handler"));
		$this->shopdata = new Config($this->path."Shops.yml", CONFIG_YAML);
		$shops = $this->api->plugin->readYAML($this->path."Shops.yml");
		foreach($shops as $s){
			$this->shop[] = array("x" => $s["x"], "y" => $s["y"], "z" => $s["z"], "item" => $s["item"], "amount" => $s["amount"], "price" => $s["price"], "level" => $s["level"], "meta" => $s["meta"]);
		}
		$this->api->economy->EconomySRegister("EconomyShop");
		EconomyShopAPI::set($this);
	}
	public function __destruct(){}
	
	public function createConfig(){
		$this->config = $this->api->plugin->readYAML($this->api->plugin->createConfig($this, array(
			"compatible-to-economyapi" => true
		))."config.yml");
	}
	public function editShop($x, $y, $z, $level, $price, $item, $amount, $meta){
		//	This function is now preparing

		if(is_array($this->shop)){
			foreach($this->shop as $k => $s){
				//  console($s["price"]);
				if($s["x"] == $x and $s["y"] == $y and $s["z"] == $z and $s["level"] == $level){
					$this->shop[$k] = array("level" => $level, "x" => $x, "y" => $y, "z" => $z, "price" => $price, "item" => $item, "amount" => $amount, "meta" => $meta);
					return true;
				}
			}
		}
		return false;
	}
	public function handler( &$data, $event){
		$output = "";
		switch ($event){
		case "tile.update":
			if($data->class === TILE_SIGN){
				//   console($this->shop[0]["x"]);
				$issuer = $this->api->player->get($data->data["creator"], false);
				if($issuer == false) 
					return;
				if($data->data["Text1"] == "shop" or $data->data["Text1"] == "상점"){
					$lang = $data->data["Text1"] == "shop" ? "english" : "korean";
					if($this->api->ban->isOp($issuer->username) == false){
						if($lang == "english"){
							$output .= "You don't have permission to construct shop";
						}else{
							$output .= "당신은 상점을 지을 수 있는 권한이 없습니다.";
						}
						break;
					}
					if($data->data["Text2"] == "" or $data->data["Text2"] == "" or $data->data["Text3"] == "" or $data->data["Text4"] == ""){
						if($lang == "english"){
							$output .= "Shop data is incorrect";
						}else{
							$output .= "상점의 정보가 올바르지 않습니다.";
						}
						$this->api->player->get($data->data["creator"])->sendChat($output);
					}else{
						$e = explode(":", $data->data["Text3"]);
						if(count($e) == 1){
							$e[1] = 0;
						}
						if($lang == "english"){
							if(strpos($data->data["Text3"], ":") !== false){
								$e = explode(":", $data->data["Text3"]);
							}else{
								$e = explode(":", $data->data["Text3"]);
								$e[1] = isset($e[1]) ? $e[1] : 0;
								if(is_numeric($e[0]) and is_numeric($e[1])){
									$e[0] = $data->data["Text3"];
									$e[1] = 0;
								}else{
									$e = explode(":", $data->data["Text3"]);
									$e[1] = isset($e[1]) ? $e[1] : 0;
								}
							}
							if(is_numeric($e[0]) and is_numeric($e[1])){
								$name = $this->getItem($e[0].":".$e[1]);
								if($name == false){
									$this->api->player->get($data->data["creator"])->sendChat($lang == "english" ? "Item ".$data->data["Text3"]." does not support at EconomyShop" : "아이템 ".$data->data["Text3"]."는 EconomyShop 에서 지원하지 않습니다");
									break;
								}
							}else{
								$id = $this->getItem($data->data["Text3"]);
								if($id == false){
									$this->api->player->get($data->data["creator"])->sendChat($lang == "english" ? "Item ".$data->data["Text3"]." does not support at EconomyShop" : "아이템 ".$data->data["Text3"]."는 EconomyShop 에서 지원하지 않습니다");
									break;
								}
								$e = explode(":", $id);
								$e[1] = isset($e[1]) ? $e[1] : 0;
							}
							if($this->api->dhandle("economyshop.shop.create", array("player" => $issuer, "x" => $data->x, "y" => $data->y, "z" => $data->z, "level" => $data->level->getName(), "item" => $e[0], "meta" => $e[1], "price" => str_replace("\$", "", $data->data["Text2"]), "amount" => str_replace(array("Amount", "수량"), "", $data->data["Text4"]))) !== false){
								$data->setText("[SHOP]", $data->data["Text2"]."$", isset($name) ? $name : $data->data["Text3"], "Amount : ".$data->data["Text4"]);
								$this->createShop(array("x" => $data->data["x"], "y" => $data->data["y"], "z" => $data->data["z"], "item" => $e[0], "price" => str_replace("\$", "", $data->data["Text2"]), "amount" => str_replace("Amount : ", "", $data->data["Text4"]), "level" => $data->level->getName(), "meta" => $e[1]));
								$output .= "Shop created";
							}else{
								$output .= "Failed creating sell center due to unknown error.";
							}
						}else{
							if(strpos($data->data["Text3"], ":") !== false){
								$e = explode(":", $data->data["Text3"]);
							}else{
								$e = explode(":", $data->data["Text3"]);
								$e[1] = isset($e[1]) ? $e[1] : 0;
								if(is_numeric($e[0]) and is_numeric($e[1])){
									$e[0] = $data->data["Text3"];
									$e[1] = 0;
								}else{
									$e = explode(":", $data->data["Text3"]);
									$e[1] = isset($e[1]) ? $e[1] : 0;
								}
							}
							if(is_numeric($e[0]) and is_numeric($e[1])){
								$name = $this->getItem($e[0].":".$e[1]);
								if($name == false){
									$issuer->sendChat($lang == "english" ? "Item ".$data->data["Text3"]." does not support at EconomyShop" : "아이템 ".$data->data["Text3"]."는 EconomyShop 에서 지원하지 않습니다");
									break;
								}
							}else{
								$id = $this->getItem($data->data["Text3"]);
								if($id == false){
									$issuer->sendChat($lang == "english" ? "Item ".$data->data["Text3"]." does not support at EconomyShop" : "아이템 ".$data->data["Text3"]."는 EconomyShop 에서 지원하지 않습니다");
									break;
								}
								$e = explode(":", $id);
								$e[1] = isset($e[1]) ? $e[1] : 0;
							}
							if($this->api->dhandle("economyshop.shop.create", array("player" => $issuer, "x" => $data->x, "y" => $data->y, "z" => $data->z, "level" => $data->level->getName(), "item" => $e[0], "meta" => $e[1], "price" => str_replace("\$", "", $data->data["Text2"]), "amount" => str_replace(array("Amount", "수량"), "", $data->data["Text4"]))) !== false){
								$data->setText("[상점]", $data->data["Text2"]."$", isset($name) ? $name : $data->data["Text3"], "수량 : ".$data->data["Text4"]);
								$this->createShop(array("x" => $data->data["x"], "y" => $data->data["y"], "z" => $data->data["z"], "item" => $e[0], "price" => str_replace("\$", "", $data->data["Text2"]), "amount" => str_replace(array("Amount : ", "수량 : "), "", $data->data["Text4"]), "level" => $data->level->getName(), "meta" => $e[1]));
								$output .= "상점이 생성되었습니다.";
							}else{
								$output .= "Failed creating sell center due to unknown error.";
							}
						}
					}
				}
				//   if($issuer !== false){
				$issuer->sendChat($output);
				//	}
			}
			break;
		case "player.block.touch":
			if($data["type"] == "break"){
				if($data["target"]->getID() == 323 or $data["target"]->getID() == 68 or $data["target"]->getID() == 63){
					if(!is_array($this->shop)){
						break;
					}
					//   console($data["target"]->x.":".$data["target"]->y.":".$data["target"]->z);
					foreach($this->shop as $key => $s){
						if($s["x"] == $data["target"]->x and $s["y"] == $data["target"]->y and $s["z"] == $data["target"]->z and $data["target"]->level->getName() == $s["level"]){
							if($this->api->ban->isOp($data["player"]->username) == false){
								$data["player"]->close("tried to destroy shop");
								return false;
							}
							unset($this->shop[$key]);
						}
					}
				}
				break;
			} /// here ///
			$target = $data["target"]->getID();
			//	$issuer = $data["player"];
			if($target == 323 or $target == 63 or $target == 68){
				if(!is_array($this->shop)){
					break;
				}
				//	console($data["target"]->x.":".$data["target"]->y.":".$data["target"]->y.":".$data["target"]->z);
				foreach($this->shop as $k => $s){
					if($s["x"] == $data["target"]->x and $s["y"] == $data["target"]->y and $data["target"]->z == $s["z"] and $data["target"]->level->getName() == $s["level"]){
						if($data["player"]->gamemode == CREATIVE){
							$data["player"]->sendChat("You are in creative mode");
							return false;
						}
						$level = $this->api->level->get($s["level"]);
						if($level !== false){
							$t = $this->api->tile->get(new Position($s["x"], $s["y"], $s["z"], $level));
							if($t == false or $t->data["Text1"] != "[상점]" and $t->data["Text1"] != "[SHOP]"){
								unset($this->shop[$k]);
								break 2;
							}
						}else{
							unset($this->shop[$k]);
							break 2;
						}
						if(!isset($this->tap[$data["player"]->username])){
							$this->tap[$data["player"]->username] = array("x" => $s["x"], "y" => $s["y"], "z" => $s["z"]);
							$this->api->schedule(20, array($this, "removeTap"), $data["player"]->username);
							$data["player"]->sendChat("Are you sure to buy this? Tap again to confirm.");
							break;
						}
						if(!($s["x"] == $this->tap[$data["player"]->username]["x"] and $s["y"] == $this->tap[$data["player"]->username]["y"] and $s["z"] == $this->tap[$data["player"]->username]["z"])){
							$data["player"]->sendChat("Are you sure to buy this? Tap again to confirm.");
							$this->tap[$data["player"]->username] = array("x" => $s["x"], "y" => $s["y"], "z" => $s["z"]);
							$this->api->schedule(20, array($this, "removeTap"), $data["player"]->username);
							$this->cancel[$data["player"]->username] = true;
							break;
						}
						$can = false;
						if($this->config["compatible-to-economyapi"]){
							$can = $this->api->economy->useMoney($data["player"], $s["price"]);
						}else{
							$can = $this->api->dhandle("money.handle", array(
								"username" => $data["player"]->username,
								"method" => "grant",
								"amount" => -$s["price"],
								 "issuer" => "EconomyShop" // Disappeared?
							));
						}
						if($can == false){
							$data["player"]->sendChat("You don't have money to buy this.");
							return false;
						}
						$data["player"]->addItem((int)$s["item"], (int)$s["meta"], (int)$s["amount"]);
						$output .= "You have been bought ".$s["item"].":".$s["meta"]." for ".$s["price"]."\$.";
						if(isset($this->tap[$data["player"]->username])){
							unset($this->tap[$data["player"]->username]);
						}
						$data["player"]->sendChat($output);
						return false;
					}
				}
			}
			break;
		case "server.close":
			$this->shopdata->setAll($this->shop);
			$this->shopdata->save();
			break;
		}
	}
	public function removeTap($username){
		if(isset($this->cancel[$username])){
			unset($this->cancel[$username]);
			return false;
		}
		if(isset($this->tap[$username])) 
			unset($this->tap[$username]);
		}
	public function createShop($shopdata){
		$this->shop[] = array("x" => $shopdata["x"], "y" => $shopdata["y"], "z" => $shopdata["z"], "item" => $shopdata["item"], "amount" => $shopdata["amount"], "price" => $shopdata["price"], "level" => $shopdata["level"], "meta" => $shopdata["meta"]);
	}
	
	public function getItem($item){ // gets ItemID and ItemName
		$e = explode(":", $item);
		if(count($e) > 1){
			if(is_numeric($e[0])){
				foreach($this->items as $k => $i){
					$item = explode(":", $i);
					$e[1] = isset($e[1]) ? $e[1] : 0;
					$item[1] = isset($item[1]) ? $item[1] : 0;
					if($e[0] == $item[0]and $e[1] == $item[1]){
						return $k;
					}
				}
				return false;
			}
		}else{
			if(isset($this->items[$item])){
				return $this->items[$item];
			}else{
				return false;
			}
		}
	}
  public function loadItems(){
	$items = new Config($this->path."items.properties", CONFIG_PROPERTIES, array(
		"air" => 0,
		"stone" => 1,
		"grass block" => 2,
		"dirt" => 3,
		"cobble stone" => 4,
		"wooden plank" => 5,
		"tree sapling" => 6,
		"fir sapling" => "6:1",
		"birch sapling" => "6:2",
		"bedrock" => 7,
		"water" => 8,
		"stationary water" => 9,
		"lava" => 10,
		"stationary lava" => 11,
		"sand" => 12,
		"gravel" => 13,
		"gold ore" => 14,
		"iron ore" => 15,
		"coal ore" => 16,
		"tree" => 17,
		"oak wood" => "17:1",
		"birch wood" => "17:2",
		"tree leaf" => "18",
		"oak tree leaf" => "18:1",
		"birch tree leaf" => "18:2",
		"glass" => 20,
		"lapis ore" => 21,
		"lapis block" => 22,
		"sand stone" => 24,
		"sand stone2" => "24:1",
		"sand stone3" => "24:2",
		"bed" => 26,
		"cobweb" => 30,
		"bush" => 31,
		"white wool" => 35,
		"orange wool" => "35:1",
		"magenta wool" => "35:2",
		"sky wool" => "35:3",
		"yellow wool" => "35:4",
		"green wool" => "35:5",
		"pink wool" => "35:6",
		"grey wool" => "35:7",
		"grey wool2" => "35:8",
		"bluish wool" => "35:9",
		"purple wool" => "35:10",
		"blue wool" => "35:11",
		"brown wool" => "35:12",
		"green wool2" => "35:13",
		"red wool" => "35:14",
		"black wool" => "35:15",
		"yellow flower" => 37,
		"blue flower" => 38,
		"brown mushroom" => 39,
		"red mushroom" => 40,
		"gold block" => 41,
		"iron block" => 42,
		"stone foothold" => 43,
		"sand foothold" => "43:1",
		"wood foothold" => "43:2",
		"cobble foothold" => "43:3",
		"brick foothold" => "43:4",
		"stone foothold2" => "43:6",
		"half stone" => 44,
		"half sand" => "44:1",
		"half wood" => "44:2",
		"half cobble" => "44:3",
		"half brick" => "44:4",
		"half stone2" => "44:6",
		"brick" => 45,
		"TNT" => 46,
		"bookshelf" => 47,
		"moss stone" => 48,
		"obsidian" => 49,
		"torch" => 50,
		"fire" => 51,
		"wood stair" => 53,
		"chest" => 54,
		"diamond ore" => 56,
		"diamond block" => 57,
		"crafting table" => 58,
		"crop" => 59,
		"farmland" => 60,
		"furnace" => 61,
		"sign block" => 63,
		"burning furnace" => 62,
		"wooden door" => 64,
		"ladder" => 65,
		"cobble stair" => 67,
		"wall sign" => 68,
		"iron door" => 71,
		"redstone ore" => 73,
		"glow redstone" => 74,
		"snow" => 78,
		"ice" => 79,
		"snow block" => 80,
		"cactus" => 81,
		"clay block" => 82,
		"sugar cane" => 83,
		"fence" => 85,
		"nether rack" => 87,
		"glowing stone" => 89,
		"cake" => 92,
		"invisible bedrock" => 95,
		"trap door" => 96,
		"stone brick" => 98,
		"moss brick" => "98:1",
		"cracked brick" => "98:2",
		"flat glass" => 102,
		"watermelon" => 103,
		"fence gate" => 107,
		"brick stair" => 108,
		"stone stair" => 109,
		"nether brick" => 112,
		"nether brick stair" => 114,
		"sand stair" => 128,
		"quartz block" => 155,
		"soft quartz" => "155:1",
		"pilliar quartz" => "155:2",
		"quartz stair" => 156,
		"stonecutter" => 245,
		"glowing obsidian" => 246,
		"nether core" => 247,
		"update block 1" => 248,
		"update block 2" => 249,
		"error grass" => 253,
		"error leaves" => 254,
		"error stone" => 255,
		"iron shovel" => 256,
		"iron pickaxe" => 257,
		"iron axe" => 258,
		"flint and steel" => 259,
		"apple" => 260,
		"bow" => 261,
		"arrow" => 262,
		"coal" => 263,
		"charcoal" => "263:1",
		"diamond" => 264,
		"iron ingot" => 265,
		"gold ingot"=> 266,
		"iron sword" => 267,
		"wood sword" => 268,
		"wood shovel" => 269,
		"wood pickaxe" => 270,
		"wood axe" => 271,
		"stone sword" => 272,
		"stone shovel" => 273,
		"stone pickaxe" => 274,
		"stone axe" => 275,
		"diamond sword" => 276,
		"diamond shovel" => 277,
		"diamond pickaxe" => 278,
		"diamond axe" => 279,
		"stick" => 280,
		"bowl" => 281,
		"mushroom stew" => 282,
		"gold sword" => 283,
		"gold shovel" => 284,
		"gold pickaxe" => 285,
		"gold axe" => 286,
		"web" => 287,
		"feather" => 288,
		"gunpowder" => 289,
		"wood hoe" => 290,
		"stone hoe" => 291,
		"iron hoe" => 292,
		"diamond hoe" => 293,
		"gold hoe" => 294,
		"seed" => 295,
		"wheat" => 296,
		"bread" => 297,
		"leather hat" => 298,
		"leather armor" => 299,
		"leather pants" => 300,
		"leather boots" => 301,
		"chain hat" => 302,
		"chain chestplate" => 303,
		"chain leggings" => 304,
		"chain boots" => 305,
		"iron helmet" => 306,
		"iron chestplate" => 307,
		"iron leggings"=> 308,
		"iron boots" => 309,
		"diamond helmet" => 310,
		"diamond chestplate" => 311,
		"diamond leggings" => 312,
		"diamond boots" => 313,
		"gold helmet" => 314,
		"gold chestplate" => 315,
		"gold leggings" => 316,
		"gold boots" => 317,
		"flint" => 318,
		"raw pork" => 319,
		"pork" => 320,
		"paint" => 321,
		"sign" => 323,
		"door" => 324,
		"bucket" => 325,
		"water bucket" => 326,
		"iron door" => 330,
		"snowball" => 332,
		"leather" => 334,
		"clay brick" => 336,
		"clay" => 337,
		"sugarcane" => 338,
		"paper" => 339,
		"book" => 340,
		"slime ball" => 341,
		"egg" => 344,
		"compass" => 345,
		"clock" => 347,
		"glow stone" => 348,
		"ink" => 351,
		"red rose" => "351:1",
		"green cactus" => "351:2",
		"cocoa bean" => "351:3",
		"lapis lazuli" => "351:4",
		"cotton" => "351:5",
		"bluish" => "351:6",
		"light grey" => "351:7",
		"grey" => "351:8",
		"pink" => "351:9",
		"light green" => "351:10",
		"yellow" => "351:11",
		"sky" => "351:12",
		"magenta"=> "351:13",
		"orange" => "351:14",
		"bone meal" => "351:15",
		"bone" => 352,
		"sugar" => 353,
		"cake" => 354,
		"bed" => 355,
		"scissors" => 259,
		"melon" => 360,
		"melon seed" => 362,
		"raw beef" => 363,
		"stake" => 364,
		"raw chicken" => 365,
		"chicken" => 366,
		"nether brick" => 405,
		"hell quartz" => 406,
		"camera" => 456,
		));
		$this->items = $items->getAll();
	}
}
class EconomyShopAPI { // Use this for EconomyShop!
	public static $p;
	public static function set(EconomyShop $e){
		if(EconomyShopAPI::$p instanceof EconomyShop){
			return false;
		}
		EconomyShopAPI::$p = $e;
		return true;
	}
	public static function getShops(){
		return EconomyShopAPI::$p->shop;
	}
	public static function editShop($data){
		return EconomyShopAPI::$p->editShop($data["x"], $data["y"], $data["z"], $data["level"], $data["price"], $data["item"], $data["amount"], $data["meta"]);
	}
}