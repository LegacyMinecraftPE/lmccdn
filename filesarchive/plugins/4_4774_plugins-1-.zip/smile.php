<?php

/*
__PocketMine Plugin__
name=PocketSmile
version=0.1
author=oleg007
class=Smile
apiversion=7,8,9,10,11
*/


class Smile implements Plugin{
	private $api;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
}

	public function init(){
$this->api->addHandler("player.join", array($this, "handler"), 5);
		$this->api->console->register("love", "= ♥", array($this, "Pref"));
$this->api->console->register("dollar", "= $", array($this, "Pref"));
$this->api->console->register("n", "= π ", array($this, "Pref"));
console("Смайлы загружены");
}
	
	public function __destruct() {}

public function Pref($cmd, $args, $params){
		$output = "";
		switch ($cmd){
		case "love":
$player = $args[0];

 $output .="lol";	
console("♥ игрок ".$player.".");
break;
case "dollar":
$player = $args[0];

$output .="$ подорожал на ".$player."'а";
console("$ подорожал на ".$player."'а")
;
break;
case "n":
$output .="π";
console("π");
break;
}
}
}