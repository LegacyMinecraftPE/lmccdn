<?php
namespace net\skidcode\gh\adc2;
use Plugin;
use ServerAPI;
class  ADC2 implements Plugin
{
	public static $threads = array();
	public $api;
	public function __construct(ServerAPI $api, $server = false)
	{
		$this->api = $api;
	}
	
	public function init()
	{
		$path = $this->api->plugin->configPath($this)."ADC2.yml";
		$cfg = new \Config($path, CONFIG_YAML, [
			"discord_channel_id" => "-1",
			"discord_bot_token" => "NONE"
		]); //TODO config
		$token = $cfg->get("discord_bot_token");
		$channelID = $cfg->get("discord_channel_id");
		if($channelID === -1 || $token === "NONE"){
			ADCLogger::n("ADC Bot cannot be setup: make sure the channelID and token in $path are correct");
			return;
		}
		Magik::init($token, $channelID);
		
		
		$this->api->schedule(5, function(){ //i hate pthreads dev who made it for 5.5. thread is SOMEHOW removing itself from array in class after it started.
			global $thread;
			$thread->synchronized(function($t){
				$msgs = json_decode($t->msgs, true);
				if(is_array($msgs)){
					foreach($msgs as $msg){ //we cant pass object array, so we are passing *um wut?*
						$this->api->chat->send(false, "[Discord] {$msg[0]}: {$msg[1]}");
					}
				}
				$t->notify();
			}, $thread);
		}, [], true);
		
		
	}
	public function tHandler(){
		
	}
	public function __destruct(){
		global $thread;
		$thread->notstopped = false;
	}

}

