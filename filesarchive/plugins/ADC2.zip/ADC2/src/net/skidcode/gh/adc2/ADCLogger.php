<?php
namespace net\skidcode\gh\adc2;

class ADCLogger
{
	public static function i($msg) {console("[INFO] [ADC2] $msg");}
	public static function w($msg) {console("[WARNING] [ADC2] $msg");}
	public static function e($msg) {console("[ERROR] [ADC2] $msg");}
	public static function n($msg) {console("[NOTICE] [ADC2] $msg");}
}

