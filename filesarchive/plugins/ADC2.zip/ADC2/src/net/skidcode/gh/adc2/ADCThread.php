<?php
namespace net\skidcode\gh\adc2;

use ConsoleAPI;

class ADCThread extends \Thread
{
	private /*static abstract volatile native override virtual @interface interface readonly bsoder*/ $token, $url, $notstopped; 
	public $msgs;
	public function __construct($token, $channelID){
		$this->token = $token;
		$this->url = "https://discord.com/api/channels/$channelID/messages";
		$this->after = false;
		$this->notstopped = true;
	}
	public function run(){
		$ch = curl_init($this->url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			"Authorization: Bot $this->token"
		]);
		curl_setopt($ch, CURLOPT_AUTOREFERER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
		while($this->notstopped){
			if($this->after === false){
				$j = json_decode(curl_exec($ch), true);
				if(isset($j["message"]) && isset($j["code"])){
					ADCLogger::e("Discord API Error: {$j["message"]}:{$j["code"]}. Stopping thread.");
					ADCLogger::e("If it not an error, contact the plugin creator and send him the line above");
					break;
				}
				if(isset($j[0])){
					$this->after = $j[0]["id"];
				}
				usleep(20000);
				continue;
			}
			curl_setopt($ch, CURLOPT_URL, $this->url."?after={$this->after}");
			$raw = curl_exec($ch);
			$j = json_decode($raw, true);
			if(isset($j["global"]) && !$j["global"] && $j["message"] == "You are being rate limited."){
				//usleep();
			}elseif($j != null && isset($j[0])){
				$this->after = $j[0]["id"];
				$this->msgs = $this->stringify($j);
				$this->synchronized(function($t){
					$t->wait();
				}, $this);
				$this->msgs = "";
			}
			usleep(20000);
		}
		curl_close($ch);
	}
	
	private function stringify($json){
		$msgs = [];
		foreach($json as $j){ //message
			if(isset($j["author"]["bot"])) continue;
			$msgs[] = [$j["author"]["username"], $j["content"]];
		}
		return json_encode($msgs);
	}
}

