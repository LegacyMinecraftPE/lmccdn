<?php
namespace net\skidcode\gh\adc2;

class ClassLoader
{
	public function loadAll($pharPath)
	{
		$src = $pharPath."/src/";
		include($src."/net/skidcode/gh/adc2/ADCThread.php");
		include($src."/net/skidcode/gh/adc2/Magik.php");
		include($src."/net/skidcode/gh/adc2/ADCLogger.php");
	}

}

