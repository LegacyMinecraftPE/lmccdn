<?php
namespace net\skidcode\gh\adc2;

$thread = null;


class Magik
{
	private static $threads = [];
	
	public static function init($t, $cid){ //Ihatephpihatephpihatephpwhy
		global $thread;
		$thread = new ADCThread($t, $cid);
		$thread->start();
		return $thread;
	}
	
}

