MCPE-Survival-Games
===================

MCPE-Survival-Games: A PM plugin which is full-automated, making the server a survival games server!
