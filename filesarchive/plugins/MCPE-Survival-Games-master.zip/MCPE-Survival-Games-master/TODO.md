TO DO
=====

Config:
-------

| Type Of Data | Contains | Percentage Finished |
| :---: | :---: | :---: |
| Arena Data | Chest(If any), Player Datas, arena ID, game location, spectate location, Enabled/Disabled | 0% |
| Lobby Data | Spawn Location | 0% |
| Kits Data | Multiple classes of kits | 0% |


Map Reset:
------------

How to make it work:  
...1) When the map is fully built, '/setMap Complete' (Save map as a new world, like a backup)       
...2) When '/setMap reset' is called, log all players off the server
...3) Delete current map, copy and paste the backup with the same level name as the deleted one then load it again!
  
Commands:
---------

To be done soon!

OVERALL PROGRESS:
=================

Config -> 0%
Map Reset -> 0%
Commands -> 0%
Planning -> 50%
