<?php
namespace net\skidcode\gh\npcs\ai;

use EntityAI;
use RotateHeadPacket;
/**
 * A small example of npc ai.
 *
 */
class AsyncPlayerLook extends \TaskBase
{
	public function onStart(EntityAI $ai)
	{
		$this->selfCounter = 1;
	}

	public function onEnd(EntityAI $ai)
	{
		
	}

	public function onUpdate(EntityAI $ai)
	{
		foreach($ai->entity->level->players as $p){
			$x = $p->entity->x - $ai->entity->x;
			$y = $p->entity->y - $ai->entity->y;
			$z = $p->entity->z - $ai->entity->z;
			$tan = $z == 0 ? ($x < 0 ? 180 : 0) : (90 - rad2deg(atan($x / $z))); /*arctan(infinity) = pi/2 = (90deg) - 90 = 0*/
			$thetaOffset = $z < 0 ? 90 : 270;
			$calcYaw = $tan + $thetaOffset;
			$diff = sqrt($x * $x + $z * $z);
			$calcPitch = $diff == 0 ? ($y < 0 ? -90 : 90) : rad2deg(atan($y / $diff));
			$pk = new RotateHeadPacket();
			$pk->eid = $ai->entity->eid;
			$pk->yaw = $calcYaw;
			$p->dataPacket($pk);
			$pk = new \MoveEntityPacket_PosRot();
			$pk->eid = $ai->entity->eid;
			$pk->x = $ai->entity->x;
			$pk->y = $ai->entity->y;
			$pk->z = $ai->entity->z;
			$pk->yaw = $calcYaw;
			$pk->pitch = -$calcPitch;
			$p->dataPacket($pk);
		}
	}

	public function canBeExecuted(EntityAI $ai)
	{
		return true;
	}

}

