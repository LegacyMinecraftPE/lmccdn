# PocketGuild

You can ally yourself with other players.

# Installation
1.  Drop it into your /plugins folder.
2.  Restart your server.

# Chat commands

You can use /g instead of /guild

| Command | Parameter | Description |
| :-----: | :-------: | :---------: |
| /guild | `None` | Show your guild |
| /guild organize /guild org | `guildname` | Organize your guild |
| /guild join | `guildname` | Join selected guild |
| /guild leave | `None` | Leave your guild |
| /guild chat /guild c | `message` | Guild chat |
