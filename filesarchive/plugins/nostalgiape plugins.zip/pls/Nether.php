<?php
/*
__PocketMine Plugin__
name=nether
description=nether
version=0.8.1
author=Tema1d&GameHerobrine
class=Nether
apiversion=12,12.1
*/

class Nether implements Plugin
{
	private $api;
	private $levelReflectionClass, $reflectionStartTime, $reflectionTime;
	const HIGH_PRIORITY = 40;
	private static $allowedNames = [ //add more nicknames
	    "tema1d",
		"sliver4649",
		"gameherobrine",
        "preaton",
        "zanz",
        "dartminer43",
        //"arkquark",
        "qqway"
		//add more if you need them
		
	];
	public function __construct(ServerAPI $api, $server = false)
	{
		$this->api = $api;
	}
	public function init() {
		$this->api->console->register("nether", "Nether", array($this, "command"));
		$this->api->addHandler("time.change", array($this, "eventHandler"), Nether::HIGH_PRIORITY);
		$this->api->ban->cmdWhitelist("nether");
		$this->levelReflectionClass = new ReflectionClass('Level');
		$this->reflectionStartTime = $this->levelReflectionClass->getProperty('startTime'); //When ObjectWeb ASM port for PHP
		$this->reflectionTime = $this->levelReflectionClass->getProperty('time');
		$this->reflectionStartTime->setAccessible(true);
		$this->reflectionTime->setAccessible(true);
	}
	
	public function eventHandler($data, $event)
	{
		switch($event){
			case "time.change":
				if($data['level']->getName() === "nether"){
					$this->reflectionStartTime->setValue($data['level'], 17000); //Dark magic i have used in MetaClickChanger plugin
					$this->reflectionTime->setValue($data['level'], 17000);
					$pk = new SetTimePacket;
					$pk->time = 17000;
					$pk->started = false;
					return false;
				}
				return true;
		}
	}
	  
	public function command($cmd, $params, $issuer, $alias) {
		switch ($cmd) {
			case "nether": 
				if ($issuer !== "console") {
					$level = $this->api->level->get("nether");
					$username = $issuer->username;
					if($level === false){
						return "Незер не загружен.";
					}
					if ($this->api->ban->isOP($username) || in_array(strtolower($username), Nether::$allowedNames)) {
						$issuer->teleport($level->getSafeSpawn());
						unset($this->queue[$username]);
						return "Вы были телепортированы в nether мир.";
					}else{
						return "Ты сможешь почувствовать ту силу, которой владеют\nвладельцы этим миром.\nВСЕГО ЗА 1 BEDROCK!";
					}
				}
				return "Only players can go to the nether...";
		}
	}
	public function __destruct() {
		
	}
}
