<?php

/*
__PocketMine Plugin__
name=GetMyLoc
description=Get your location!
version=1.3
author=DreamWork Studio
class=GetMyLoc
apiversion=11,12
*/

class GetMyLoc implements Plugin{
	
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	
	public function init(){
		$this->api->console->register("loc", "Get your location!", array($this, "command"));
		$this->api->ban->cmdWhitelist("loc");
	}
	
	public function command($cmd, $params, $issuer, $alias){
		$output = "";
	 	switch($cmd){
			case "loc":
				if(!($issuer instanceof Player)){
					$output .= "[GetMyLoc] Please run this command in-game.";
					break;
				}
				$output .= "XYZ: x: ".round($issuer->entity->x, 1, PHP_ROUND_HALF_UP).", y: ".round($issuer->entity->y, 1, PHP_ROUND_HALF_UP).", z: ".round($issuer->entity->z, 1, PHP_ROUND_HALF_UP).", world: ".$issuer->entity->level->getName().".";
				break;
		}
		return $output;
	}
	
	public function __destruct(){}
	
}
