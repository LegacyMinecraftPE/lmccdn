<?php
 
/*
__PocketMine Plugin__
name=ItemBlock
description=
version=1.0
apiversion=11
author=ExtremeCraft
class=BanItem
*/
 
define("PLUGIN_VERSION", 1.0);

class BanItem implements Plugin{
    private $api, $config;
 
    public function __construct(ServerAPI $api, $server = false){
        $this->api  = $api;
    }
    
    public function init()
    {
    	$this->api->addHandler("player.equipment.change", array($this, 'handler'), 15);
    	$this->api->console->register("item", " Управление предметами сервера .", array($this, 'commands'));
    	
        $this->config = new Config($this->api->plugin->configPath($this) . "config.yml", CONFIG_YAML, array(
    		"banned-item-list" 			=> array(),
    		"plugin-version"			=> PLUGIN_VERSION,
    		"msg-on-equipment-change" 	=> " Данный предмет заблокирован на сервере !",
    		"msg-on-ban-item"			=> " Блокировка предмета #@name прошла успешно !",
    		"msg-on-unban-item"			=> " Разблокировка предмета #@name прошла успешно !"
    	));

    	if($this->config->get('plugin-version') != PLUGIN_VERSION)
    	{
    		unlink($this->api->plugin->configPath($this) . "config.yml");
    		$this->config = new Config($this->api->plugin->configPath($this) . "config.yml", CONFIG_YAML, array(
				"banned-item-list" 			=> array(),
				"plugin-version"			=> PLUGIN_VERSION,
       "msg-on-equipment-change" 	=> " Данный предмет заблокирован на сервере !",
    		"msg-on-ban-item"			=> " Блокировка предмета #@name прошла успешно !",
    		"msg-on-unban-item"			=> " Разблокировка предмета #@name прошла успешно !"
    		));
    	}
    }

    public function handler(&$data, $event)
    {
    	if($event === "player.equipment.change")
    	{
            $list = $this->config->get('banned-item-list');

    		if(in_array($data['item']->getID(), $list))
    		{
    			$msg = str_replace('@name', $data['item']->getName(), $this->config->get('msg-on-equipment-change'));
    			$data['player']->sendChat($msg);
    			return false;
    		}
            elseif(in_array($data["item"]->getName(), $list))
            {
                $msg = str_replace('@name', $data['item']->getName(), $this->config->get('msg-on-equipment-change'));
                $data['player']->sendChat($msg);
                return false;
            }
    	}
    }

    public function commands($cmd, $params)
    {
    	if($cmd == 'item')
    	{
            $c = $this->config->getAll();
            $list = $c["banned-item-list"];
    		switch (strtolower(array_shift($params))) 
            {
    			case 'b':
    				$id = array_shift($params);
                    if(empty($id) || (is_int($id) && $id <= 0) || $id === NULL)
                    {
                        console("Usage: \item <ban|unban> <id|name>");
                        return;
                    }

    				if(!in_array($id, $list))
    				{
                        if(!is_array($list))
                            $list = array($id);
                        else
                            $list[] = $id;

    					$msg = str_replace('@name', $id, $this->config->get('msg-on-ban-item'));
    					$this->api->chat->broadcast($msg);
    				}
                    else
                    {
                        console("[BanItem] The item is alraedy banned.");
                    }

                    $c["banned-item-list"] = $list;
                    $this->config->setAll($c);
                    $this->config->save();
    			break;
    			
    			case 'ub':
    				$id = array_shift($params);
                    if(empty($id) || (is_int($id) && $id <= 0) || $id === NULL)
                    {
                        console("Usage: \item <ban|unban> <id|name>");
                        return;
                    }

    				if(in_array($id, $list))
    				{
				        $key = array_search($id, $list);
				        unset($list[$key]);

    					$msg = str_replace('@name', $id, $this->config->get('msg-on-unban-item'));
    					$this->api->chat->broadcast($msg);
    				}
                    else
                    {
                        console("[BanItem] The item is not banned.");
                    }

                    $c["banned-item-list"] = $list;
                    $this->config->setAll($c);
                    $this->config->save();
    			break;
    		}
    	}
    }

    public function __destruct(){}
}