<?php
/*
__PocketMine Plugin__
name=EconomyAirport
version=1.0.11
author=onebone
apiversion=11,12
class=EconomyAirport
*/
/*
CHANGE LOG
================

V 1.0.0
Initial Release

V 1.0.1
Added config

V 1.0.2
Korean now avaliable

V 1.0.3
Korean invalid bug fixed

V 1.0.4
No OP can create airport bug fix
Multi World now avaliable

V 1.0.5
Code edit

V1.0.6
Many bugs patch

V1.0.7
Added accident

V1.0.8
Texts changes immediately

V1.0.9
Now works at DroidPocketMine

V1.0.10
Compatible with API 11

V1.0.11
Compatible with API 12 (Amai Beetroot)

===Read me===
This plugin copyright to onebone of MCPE KOREA(Republic of Korea community). Sharing this plugin is allowed, however editing author will be punished by copyright law.
When sharing this plugin, please show provenance.

이 플러그인의 저작권은 MCPE KOREA(대한민국 MCPE 커뮤니티). 이 플러그인 공유하는 것은 허용하나, 저작자를 수정하는 것은 저작권법에 의해 처벌받을 수 있습니다.
이 플러그인을 공유 할시, 출처를 밝혀주십시오.
*/
class EconomyAirport implements Plugin {
	private $api, $arrival,	$departure;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
	}
	public function init(){
		$this->isFirst = true;
		foreach($this->api->plugin->getList() as $p){
			if ($p["name"] == "EconomyAPI"){
				$exist = true;
				break;
			}
		}
		if (!isset($exist)){
			console("[ERROR] EconomyAPI not found");
			$this->api->console->defaultCommands("stop", "", "EconomyAirport", false);
			return;
		}
		$this->path = $this->api->plugin->configPath($this);
		$this->api->event("tile.update", array($this, "handler"));
		$this->api->event("server.close", array($this, "handler"));
		$this->api->addHandler("player.block.touch", array($this, "handler"));
		$this->config = new Config($this->path."configuration.yml", CONFIG_YAML, array("Plane-name" => "EA Airlines", "enable-accident" => true, "accident-percent" => 1));
		$this->departuredata = new Config($this->path."Departure.yml", CONFIG_YAML);
		$this->arrivaldata = new Config($this->path."Arrival.yml", CONFIG_YAML);
		$this->api->economy->EconomySRegister("EconomyAirport");
		$this->refreshAirport();
	}
	public function __destruct(){}

	public function refreshAirport(){
		if ($this->isFirst == true){
			$arrival = $this->api->plugin->readYAML($this->path."Arrival.yml");
			if ($arrival != null){
				foreach($arrival as $a){
					$this->arrival[] = array("x" => $a["x"], "y" => $a["y"], "z" => $a["z"], "name" => $a["name"], "level" => $a["level"]);
				}
			}
			$departure = $this->api->plugin->readYAML($this->path."Departure.yml");
			if ($departure != null){
				foreach($departure as $d){
					$this->departure[] = array("x" => $d["x"], "y" => $d["y"], "z" => $d["z"], "cost" => $d["cost"], "arrival" => $d["arrival"], "level" => $d["level"]);
				}
			}
		}
		$this->isFirst = false;
	}
	public function handler(&$data, $event){
		$output = "";
		switch ($event){
		case "tile.update":
			if ($data->class === TILE_SIGN){
				if ($data->data["Text1"] == "airport" or $data->data["Text1"] == "공항"){
					$player = $this->api->player->get($data->data["creator"]);
					if ($this->api->ban->isOp($player->username) == false){
						if ($data->data["Text1"] == "airport" or $data->data["Text1"] == "공항"){
							$player->sendChat("You don't have permission to create airport");
							break;
						} else {
							$player->sendChat("당신은 공항을 생성할 권한이 없습니다");
							break;
						}
					}

					if ($data->data["Text2"] == "arrival" or $data->data["Text2"] == "도착" or $data->data["Text2"] == ""){
						if ($data->data["Text3"] == "" and $data->data["Text1"] == "airport"){
							$player->sendChat("Airport data is incorrect");
							break;
						}
						elseif($data->data["Text1"] == "공항" and $data->data["Text3"] == ""){
							$player->sendChat("공항의 데이터가 올바르지 않습니다.");
							break;
						}
						$lang = $data->data["Text1"] == "공항" ? "korean" : "english";
						if (is_array($this->arrival)){
							foreach($this->arrival as $a){
								if ($a["name"] == $data->data["Text3"]){
									if ($lang == "english"){
										$player->sendChat("Same airport name of Airport exists");
										break 2;
									} else {
										$player->sendChat("같은 이름의 공항이 이미 존재합니다.");
										break 2;
									}
								}
							}
						} // delete here if error
						if ($lang == "english"){
							/*	 $data->data["Text1"] = "[AIRPORT]";
 $data->data["Text2"] = "ARRIVAL";
 $data->data["Text4"] = "Airport"*/
							$data->setText("[AIRPORT]", "ARRIVAL", $data->data["Text3"], "Airport");
							$this->createArrival(array("x" => $data->data["x"], "y" => $data->data["y"], "z" => $data->data["z"], "name" => $data->data["Text3"], "level" => $data->level->getName()));
							$output .= $data->data["Text3"]." airport created";
						} else {
							/*  $data->data["Text1"] = "[공항]";
 $data->data["Text2"] = "도착";
 $data->data["Text4"] = "공항";*/
							$data->setText("[공항]", "도착", $data->data["Text3"], "공항");
							$this->createArrival(array("x" => $data->data["x"], "y" => $data->data["y"], "z" => $data->data["z"], "name" => $data->data["Text3"], "level" => $data->level->getName()));
							$output .= $data->data["Text3"]."공항이 생성되었습니다.";
						}
						$player->sendChat($output);
						break;
					}
					// now in here
					elseif($data->data["Text2"] == "departure" or $data->data["Text2"] == "출발"){
						$lang = $data->data["Text2"] == "출발" ? "korean" : "english";
						if ($data->data["Text3"] == "" or $data->data["Text4"] == ""){
							if ($lang == "english"){
								$output .= "Incorrect airport data";
							} else {
								$output .= "공항의 데이터가 올바르지 않습니다.";
							}
							$player->sendChat($output);
							break;
						}

						$this->createDeparture(array("x" => $data->data["x"], "y" => $data->data["y"], "z" => $data->data["z"], "arrival" => $data->data["Text4"], "cost" => $data->data["Text3"], "level" => $data->level->getName()));
						if ($lang == "english"){
							/*	 $data->data["Text1"] = "[AIRPORT]"; $data->data["Text2"] = "DEPARTURE";
 $data->data["Text3"] = $data->data["Text3"]."\$";
 $data->data["Text4"] = "To ". $data->data["Text4"];*/
							$data->setText("[AIRPORT]", "DEPARTURE", $data->data["Text3"]."$", "To ".$data->data["Text4"]);
							$output .= "Departure created";
						} else {
							/*			$data->data["Text1"] = "[공항]"; $data->data["Text2"] = "출발";
 $data->data["Text3"] = $data->data["Text3"]."\$";
 $data->data["Text4"] = $data->data["Text4"]. " 행";*/
							$data->setText("[공항]", "출발", $data->data["Text3"]."$", "To ".$data->data["Text4"]);
							$output .= "공항이 생성되었습니다";
						}
						$player->sendChat($output);
					} else {
						if ($data->data["Text1"] == "airport"){
							$output .= "Incorrect airport data";
							break;
						} else {
							$output .= "공항의 데이터가 올바르지 않습니다.";
							break;
						}
						$this->api->player->get($data->data["creator"])->sendChat($output);
					}
				}
			}

			break;
		case "player.block.touch":
			$player = $this->api->player->get($data["player"]);
			switch ($data["type"]){
			case "break":
				if ($data["target"]->getID() == 323 or $data["target"]->getID() == 63 or $data["target"]->getID() == 68){
					if ($this->arrival == null){
						break;
					}
					foreach($this->arrival as $a){
						if ($a["x"] == $data["target"]->x and $a["y"] == $data["target"]->y and $a["z"] == $data["target"]->z and $a["level"] == $data["target"]->level->getName()){
							if ($this->api->ban->isOp($data["player"]->username) === false){
								$output .= "You don't have permission to destroy airport";
								$player->sendChat($output);
								$this->api->ban->kick("kick", array($player->username, "tried to destroy airport"), "EconomyAirport", false);
								return false;
							}
							foreach($this->arrival as $key => $a){
								if ($data["target"]->x == $a["x"]and $data["target"]->y === $a["y"]and $data["target"]->z == $a["z"]and $a["level"] == $data["target"]->level->getName()){
									unset($this->arrival[$key]);
									break;
								}
							}
						}
					}
					if ($this->departure == null){
						break;
					}
					foreach($this->departure as $key => $value){
						if ($value["x"] == $data["target"]->x and $value["y"] == $data["target"]->y and $value["z"] == $data["target"]->z and $value["level"]){
							if ($this->api->ban->isOp($data["player"]->username) == false){
								$output .= "You don't have permission to destroy airport";
								return false;
							}
							unset($this->departure[$key]);
						}
					}

				}
				break;
			}
			if ($this->departure == null or $this->arrival == null){
				break;
			}
			foreach($this->departure as $d){
				if ($data["target"]->x == $d["x"]and $data["target"]->y == $d["y"]and $data["target"]->z == $d["z"]and $d["level"] == $data["target"]->level->getName()){

					foreach($this->arrival as $v){
						if ($v["name"] == $d["arrival"]){
							if ($this->config->get("enable-accident") and $this->config->get("accident-percent") > 0){
								$r = rand(0, 100 - $this->config->get("accident-percent"));
							}
							if (isset($r)){
								if ($r == 1){}
							}
							$user = $player->username;
							$can = $this->api->economy->useMoney($player, $d["cost"]);
							if ($can !== false){
								$this->api->player->tppos($user, $v["x"], $v["y"], $v["z"]);
								$player->sendChat("Thank you for flying with ".$this->config->get("Plane-name").". We arrived at ".$v["name"]." airport.");
							} else {
								$player->sendChat("You don't have money to ride plane.");
							}
							break 2;
						}
					}
				}
			}
			break;
		case "server.close":
			$this->arrivaldata->setAll($this->arrival);
			$this->departuredata->setAll($this->departure);
			$this->arrivaldata->save();
			$this->departuredata->save();
			break;
		}
	}
	public function createArrival($data){
		$this->arrival[] = $data;
		//	  $this->refreshAirport();
	}
	public function createDeparture($data){
		$this->departure[] = $data;
		//		$this->refreshAirport();
	}
}