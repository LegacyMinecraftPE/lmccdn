<?php
/*
__PocketMine Plugin__
name=EconomyLand
version=1.3.7
author=onebone
apiversion=11,12
class=EconomyLand
*/
/*
===== Read me ======
This plugin copyright to onebone of MCPE KOREA(Republic of Korea community). Sharing this plugin is allowed, however editing author will be punished by copyright law.
When sharing this plugin, please show origin.

이 플러그인의 저작권은 MCPE KOREA(대한민국 MCPE 커뮤니티). 이 플러그인 공유하는 것은 허용하나, 저작자를 수정하는 것은 저작권법에 의해 처벌받을 수 있습니다.
이 플러그인을 공유 할시, 출처를 밝혀주십시오.

=====CHANGE LOG======
V1.0.0 : First release

V1.0.1 : Multi World support

V1.0.2 : Bug fix

V1.1.0 :
- Multi World Error Fix
- Rotation command add
- Added handler
- Added EconomyLandAPI
- More

V1.1.1: OPs can edit the land

V1.2.0 : 
- Changed the selection of land( Sign → Command )
- Reduced saving data

V1.2.1 : Fixed about space calculating error

V1.2.2 : Fixed small bug and edited function editLand()

V1.2.3 : Added configuration to add Korean command

V1.2.4 : Now works at DroidPocketMine

V1.2.5 : Added "move" sub command for command "/land"

V1.3.0 : Added invite system with command /land <invite | invitee>

V1.3.1 :
- Increased handler priority
- Error fix

V1.3.2 : Added command '/land give'

V1.3.3 : Compatible with API 11

V1.3.4 : Fixed editLand() to compatible with current version

V1.3.5 :
- Fixed the bug that cannot remove invitee
- Changed method of buying land

V1.3.6 : Fixed major bug

V1.3.7 : Compatible with API 12 (Amai Beetroot)

*/
// 땅 겹치는거 확인하는거 어려웠습니다 ㅜㅠ

class EconomyLand implements Plugin {
	private $api, $land, $start, $end;
	public function __construct(ServerAPI $api, $server = false){
		$this->api = $api;
		$this->land = array();
	}
	public function init(){
		foreach($this->api->plugin->getList() as $p){
			if($p["name"] == "EconomyAPI"){
				$ex = true;
			}
		}
		if(!isset($ex)){
			console(FORMAT_RED."[EconomyLand] EconomyAPI not exist");
			$this->api->console->defaultCommands("stop", "", "plugin", false);
			return;
		}
		$this->path = $this->api->plugin->configPath($this);
		$this->api->plugin->createConfig($this, array("enable-korean" => true));
		$this->config = $this->api->plugin->readYAML($this->path."config.yml");
		$this->createData();
		$suc = EconomyLandAPI::set($this);
		if($suc == false){
			console(FORMAT_RED."[EconomyLand] Unknown error has been found.");
			return;
		}
		$wcmd = array("myrotation", "startp", "endp", "land", "landsell");
		$kwcmd = array("내방향", "시작점", "끝점", "땅", "땅팔기");
		foreach($wcmd as $c){
			$this->api->ban->cmdWhitelist($c);
		}
		$this->cmd = array("myrotation" => "", "startp" => "", "endp" => "", "land" => "<list | here | move | invite | invitee | give | buy> [page | land number] [(r:)player]", "landsell" => "<here | land number>");
		$kcmd = array("내방향" => "", "시작점" => "", "끝점" => "", "땅" => "<목록 | 위치 | 이동 | 초대 | 초청객 | 주기> [페이지 | 땅 번호] [(r:)플레이어]", "땅팔기" => "<여기 | 땅 번호>");
		if($this->config["enable-korean"]){
			foreach($kwcmd as $c){
				$this->api->ban->cmdWhitelist($c);
			}
			foreach($kcmd as $c => $h){
				$this->api->console->register($c, $h, array($this, "commandHandler"));
			}
		}
		foreach($this->cmd as $c => $h){
			$this->api->console->register($c, $h, array($this, "commandHandler"));
		}
		foreach($wcmd as $c){
			$this->api->ban->cmdWhitelist($c);
		}
		$this->api->event("server.close", array($this, "handle"));
		$this->api->addHandler("player.spawn", array($this, "handle"));
		$this->api->addHandler("player.block.touch", array($this, "permissions"), 10);
		$this->api->economy->EconomySRegister("EconomyLand");
	}
	public function commandHandler($cmd, $param, $issuer, $alias){
		$output = "";
		if(!$issuer instanceof Player){
			return "Please run this command in-game.\n";
		}
		$lang = preg_match("#[a-zA-Z]#", $cmd) == 0 ? "korean" : "english";
		switch ($cmd){
		case "landsell":
		case "땅팔기":
			switch ($param[0]){
			case "here":
			case "여기":
				$x = $issuer->entity->x;
				$z = $issuer->entity->z;
				foreach($this->land as $k => $l){
					if($l["startX"] < $x and $l["x"] > $x and $l["startZ"] < $z and $l["z"] > $z and $l["level"] == $issuer->level->getName()){
						if($issuer->username === $l["owner"] or $this->api->ban->isOp($issuer->username)){
							unset($this->land[$k]);
							$this->api->economy->takeMoney($issuer, $l["price"] / 2);
							$output .= "Has been sold the land for $".($l["price"] / 2).".";
							break 2;
						}else{
							$output .= "This is not your land.";
							break 2;
						}
					}
				}
				$output .= "Anyone doesn't has this land.";
				break;
			default:
				$p = $param[0];
				if(is_numeric($p)){
					if(isset($this->land[$p])){
						if($this->land[$p]["owner"] == $issuer->username or $this->api->ban->isOp($issuer->username)){
							$this->api->economy->takeMoney($issuer, $this->land[$p]["price"] / 2);
							$output .= "Has been sold your land for $".($this->land[$p]["price"] / 2).".";
							unset($this->land[$p]);
						}else{
							$output .= "Land number $p is not your land";
						}
					}else{
						$output .= "There are no land numbered $p";
					}
				}else{
					$output .= "Usage : /landsell <here | land number>";
				}
			}
			break;
		case "myrotation":
		case "내방향":
			$lang = $cmd == "myrotation" ? "english" : "korean";
			$r = $issuer->entity->getDirection();
			$output .= "Direction no.$r\n";
			switch ($r){
			case 0:
				$output .= "↑ X Bound . Z Bound →";
				break;
			case 1:
				$output .= "← X Bound . ↑ Z Bound";
				break;
			case 2:
				$output .= "← Z Bound . ↓ X Bound";
				break;
			case 3:
				$output .= "↓ Z Bound . X Bound →";
				break;
			default:
				$output .= "Unknown Error found";
			}
		case "land":
		case "땅":
			$p = array_shift($param);
			if($p == "move" or $p == "이동"){
				$num = array_shift($param);
				if(trim($num) == ""){
					$output .= "Usage: /land move <land num>";
					break;
				}
				if(isset($this->land[$num])){
					$l = $this->land[$num];
					if($this->api->level->get($l["level"]) == false){
						$output .= "Land number $num is corrupted.";
						break;
					}
					$x = (int) $l["startX"] + (($l["x"] - $l["startX"]) / 2);
					$z = (int) $l["startZ"] + (($l["z"] - $l["startZ"]) / 2);
					$cnt = 0;
					for ($y = 1;; $y++){
						if($this->api->level->get($l["level"])->getBlock(new Vector3($x, $y, $z))->getID() == AIR){
							break;
						}
						if($cnt == 5) 
							break;
						if($y > 255){
							$x++;
							$z--;
							$y = 1;
							$cnt++;
							continue;
						}
					}
					if($cnt >= 5){
						$output .= "Failed moving to land.";
						break;
					}
					$u = $issuer->username;
					if($issuer->level->getName() !== $l["level"]){
						$issuer->teleport($this->api->level->get($l["level"])->getSpawn());
					}
					$this->api->player->tppos($u, $x, ++$y, $z);
					$output .= "Moved to the land.";
				}else{
					$output .= "There are no land numbered $num";
				}
			}elseif($p == "list" or $p == "목록"){
				$page = isset($param[0]) ? (int) $param[0] : 1;
				$max = ceil(count($this->land) / 5);
				$pro = 1;
				$output .= "Land List : ($page / $max)\n";
				$current = 1;
				foreach($this->land as $k => $l){
					$cur = (int) ceil($current / 5);
					if($cur > $page) 
						continue;
					if($pro == 6) 
						break;
					if($page == $cur){
						$output .= "[".$k++."] Weith : ".($l["x"] - $l["startX"]) * ($l["z"] - $l["startZ"])." m^2 | Owner : ".$l["owner"]."\n";
						$pro++;
					}
					$current++;
				}
			}elseif($p == "here" or $p == "위치"){
				$x = $issuer->entity->x;
				$z = $issuer->entity->z;
				foreach($this->land as $l){
					if($l["startX"] < $x and $l["x"] > $x and $l["startZ"] < $z and $l["z"] > $z and $issuer->level->getName() == $l["level"]){
						$output .= "Here is ".$l["owner"]."'s land.";
						break 2;
					}
				}
				$output .= "No one has this land.";
			}elseif($p == "invite" or $p == "초대"){
				$landnum = array_shift($param);
				$player = array_shift($param);
				if(trim($player) == "" or trim($landnum) == ""){
					$output .= "Usage : /land <invite> [land number] [(r:)player]";
					break;
				}
				if(!isset($this->land[$landnum])){
					$output .= "Land number $landnum does not exist.";
					break;
				}
				elseif(!is_numeric($landnum)){
					$output .= "Land number must be number.";
					break;
				}
				elseif($this->land[$landnum]["owner"] != $issuer->username){
					$output .= "Land number $landnum is not your land!";
				}elseif(substr($player, 0, 2) == "r:"){
					$player = substr($player, 2);
					if(!in_array($player, $this->land[$landnum]["invitee"])){
						$output .= "You didn't invite $player";
						break;
					}
					foreach($this->land[$landnum]["invitee"] as $k => $l){
						if($player == $l){
							unset($this->land[$landnum]["invitee"][$k]);
							break;
						}
					}
					if(!is_array($this->land[$landnum]["invitee"])){
						$this->land[$landnum]["invitee"] = array();
					}
					$output .= "Removed $player to the invite list.";
				}else{
					if(in_array($player, $this->land[$landnum]["invitee"])){
						$output .= "Player $player is already in the list.";
						break;
					}
					$this->land[$landnum]["invitee"][] = $player;
					$output .= "Invited $player to your land.";
				}
			}elseif($p == "invitee" or $p == "초청객"){
				$landnum = array_shift($param);
				if(trim($landnum) == "" or !is_numeric($landnum)){
					$output .= "Usage: /land invitee <land number>";
					break;
				}elseif(!isset($this->land[$landnum])){
					$output .= "Land number $landnum does not exists";
					break;
				}
				$output .= "Invitee list: \n";

				foreach($this->land[$landnum]["invitee"]as $i){
					$output .= $i.", ";
				}
				$output = substr($output, 0, -2);
			}elseif($p == "give" or $p == "주기"){
				$player = array_shift($param);
				$landnum = array_shift($param);
				if(trim($player) == "" or trim($landnum) == "" or !is_numeric($landnum)){
					$output .= "Usage: /$cmd give <player> <land number>";
					break;
				}
				$player = $this->api->player->get($player, false);
				if($player == false){
					$output .= "Player {$player->username} is not connected.";
				}else{
					if(!isset($this->land[$landnum])){
						$output .= "Land number $landnum does not exists.";
					}else{
						if($this->land[$landnum]["owner"] !== $issuer->username and !$this->api->ban->isOp($issuer->username)){
							$output .= "Land number $landnum is not your land.";
						}else{
							if($issuer->username === $player->username){
								$output .= "You cannot give the land yourself.";
							}else{
								$this->land[$landnum]["owner"] = $player->username;
								$output .= "Has been gave land number $landnum to {$player->username}.";
								$player->sendChat("[EconomyLand] {$issuer->username} gave you a land numbered $landnum.");
							}
						}
					}
				}
			}elseif($p == "buy"){
				if(!isset($this->start[$issuer->username])){
					$output .= $lang == "english" ? "Please set first position." : "첫번째 위치를 지정해주십시오.";
					break;
				}elseif(!isset($this->end[$issuer->username])){
					$output .= $lang == "english" ? "Please set end position" : "두번째 위치를 지정해주십시오.";
					break;
				}
				$l = $this->start[$issuer->username];
				$endp = $this->end[$issuer->username];
				$startX = (int) $l["x"];
				$endX = (int) $endp["x"];
				$startZ = (int) $l["z"];
				$endZ = (int) $endp["z"];
				if($startX > $endX){ // startX 가 endX 보다 클 경우 둘이 바꿔치기
					$backup = $startX;
					$startX = $endX;
					$endX = $backup;
				}
				if($startZ > $endZ){ // startZ 가 endZ 보다 클 경우 둘이 바꿔치기
					$backup = $startZ;
					$startZ = $endZ;
					$endZ = $backup;
				};
				$startX--;
				$endX++;
				$startZ--;
				$endZ++;
				foreach($this->land as $k => $v){
					for ($x = $v["startX"]; $x < $endX; $x++){
						for ($z = $v["startZ"]; $z < $endZ; $z++){
							if($v["startX"] <= $endX and $v["x"] >= $endX and $v["startZ"] <= $endZ and $v["z"] >= $endZ and $issuer->level->getName() == $v["level"]and $issuer->username != $v["owner"]){
								$output .= $lang == "english" ? "There are ".$v["owner"]."'s land around here." : "이 주변에 ".$v["owner"]."의 땅이 있습니다.";
								break 4;
							}
						}
					}
				}
				$price = (($endX - $startX) - 1) * (($endZ - $startZ) - 1) * 100;
				if($this->api->economy->useMoney($issuer, $price) == false){
					$output .= $lang == "english" ? "You don't have money to buy this land." : "당신은 이 땅을 살 돈이 없습니다.";
					break;
				}
				$this->land[] = array(
					"startX" => $startX,
					"x" => $endX,
					"startZ" => $startZ,
					"z" => $endZ,
					"owner" => $issuer->username,
					"level" => $this->start[$issuer->username]["level"],
					"price" => $price,
					"invitee" => array()
				);
				unset($this->start[$issuer->username]);
				unset($this->end[$issuer->username]);
				$output .= $lang == "english" ? "Has been bought land for $price\$" : "$price\$에 땅을 구입하였습니다";
			}else{
				$output .= "Usage: /land ".$this->cmd["land"];
			}
			break;
		case "startp":
		case "시작점":
			$x = (int) $issuer->entity->x;
			$z = (int) $issuer->entity->z;
			$level = $issuer->level->getName();
			$this->start[$issuer->username] = array("x" => $x, "z" => $z, "level" => $level);
			$output .= $lang == "english" ? "First position saved." : "첫번째 위치가 저장됬습니다.";
			break;
		case "endp":
		case "끝점":
			if(!isset($this->start[$issuer->username])){
				$output .= $lang == "english" ? "Please set first position." : "첫번째 위치를 지정해주십시오.";
				break;
			}
			if($issuer->level->getName() !== $this->start[$issuer->username]["level"]){
				$output .= $lang == "english" ? "You must not move over level" : "월드를 사이에 두고 땅을 설정할수 없습니다.";
				break;
			}
			$this->end[$issuer->username] = null;
			unset($this->end[$issuer->username]);
			$startX = $this->start[$issuer->username]["x"];
			$startZ = $this->start[$issuer->username]["z"];
			$endX = (int) $issuer->entity->x;
			$endZ = (int) $issuer->entity->z;
			$this->end[$issuer->username] = array(
				"x" => $endX,
				"z" => $endZ
			);
			if($startX > $endX){
				$temp = $endX;
				$endX = $startX;
				$startX = $temp;
			}
			if($startZ > $endZ){
				$temp = $endZ;
				$endZ = $startZ;
				$startZ = $temp;
			}
			$startX--;
			$endX++;
			$startZ--;
			$endZ++;
			$price = (($endX - $startX) - 1) * (($endZ - $startZ) - 1) * 100;
			$output .= $lang == "english" ? "Land price : $price\nBuy land with /land buy" : "땅 가격 : $$price\n명령어 /land buy 로 땅을 사세요";
			break;
		}
		return $output."\n";
	}
	public function handle( &$data, $event){
		switch ($event){
		case "server.close":
			$this->landdata->setAll($this->land);
			$this->landdata->save();
			break;
		case "player.spawn":

			break;
		}
	}
	public function permissions( &$data, $event){
		switch ($event){
		case "player.block.touch":
			foreach($this->land as $k => $l){
				//  console("foreach");
				//   console($l["startX"].", ".$l["startZ"].", ". $l["x"].", ". $l["z"].", ". $data["target"]->x.", ".$data["target"]->z);
				if($l["level"] == $data["target"]->level->getName() and $l["x"] > $data["target"]->x and $l["z"] > $data["target"]->z and $l["startX"] < $data["target"]->x and $l["startZ"] < $data["target"]->z){ // startZ 는 만진 곳 보다 커야하고, z는 만진 곳보다 작아야한다
					if($l["owner"] !== $data["player"]->username and !$this->api->ban->isOp($data["player"]->username) and !in_array($data["player"]->username, $l["invitee"])){
						$data["player"]->sendChat("You don't have permission to edit this land. Owner : $l[owner]");
						return false;
					}
				}
			}
			break;
		}
	}
	public function createData(){
		$this->landdata = new Config($this->path."LandData.yml", CONFIG_YAML, array());
		$this->land = $this->api->plugin->readYAML($this->path."LandData.yml");
		foreach($this->land as $k => $l){
			if(!isset($l["invite"])){
				$this->land[$k]["invite"] = array();
			}
		}
	}
	public function editLand($data){
		foreach($this->land as &$l){
			if($l["startX"] == $data["x"] and $l["startZ"] == $data["z"]){
				$l["price"] = isset($data["price"]) ? $data["price"] : $l["price"];
				$l["owner"] = isset($data["owner"]) ? $data["owner"] : $l["owner"];
				$l["startX"] = isset($data["startX"]) ? $data["startX"] : $l["startX"];
				$l["x"] = isset($data["endX"]) ? $data["endX"] : $l["x"];
				$l["startZ"] = isset($data["startZ"]) ? $data["startZ"] : $l["startZ"];
				$l["z"] = isset($data["endZ"]) ? $data["endZ"] : $l["z"];
				return true;
			}
		}
		return false;
	}
	
	public function addLand($data){
		$this->land[] = array(
			"price" => $data["price"],
			"owner" => $data["owner"],
			"x" => $data["endX"],
			"z" => $data["endZ"],
			"startX" => $data["startX"],
			"startZ" => $data["startZ"],
			"level" => $data["level"]
		);
	}
	public function __destruct(){}
}
class EconomyLandAPI {
	public static $a;
	public static function set(EconomyLand $l){
		if(EconomyLandAPI::$a instanceof EconomyLand){
			return false;
		}
		EconomyLandAPI::$a = $l;
		return true;
	}
	public static function getLands(){
		return EconomyLandAPI::$a->land;
	}
	public static function myLand($owner){
		$ret = array();
		foreach(EconomyLandAPI::$a->land as $k => $l){
			if($l["owner"] == $owner){
				$ret[] = EconomyLandAPI::$a->land[$k];
			}
		}
		return $ret;
	}
	public static function editLand($data){
		if(is_array($data)){
			return EconomyLandAPI::$a->editLand($data);
		}
		return false;
	}
}