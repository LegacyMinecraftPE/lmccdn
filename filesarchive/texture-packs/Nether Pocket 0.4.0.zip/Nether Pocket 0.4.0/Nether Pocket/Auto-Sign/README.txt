Auto-sign Created By Dave Da illest 1
Edited to be easier to use with APK files by mixpix405

REQUIREMENTS:
I admit that I really don't know all the details, but I think you MUST have the JDK installed
- http://java.sun.com/javase/downloads/index.jsp
I also have the SDK, but I don't think it's necessary for this tool...

To use:
Put the APK you want to sign into this folder (doesn't matter what it's named, just make sure it is the ONLY .apk in the folder) and run "sign.bat"
It will output a signed version of the APK that will be named "your_app_signed.apk"

Simple enough, right?